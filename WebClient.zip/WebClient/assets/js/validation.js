function validation() {
    $('#defaultForm').validator({
        custom: {
            pattern: function ($el) {
                var pattern = new RegExp($el.data('pattern'), "i")
                return  !pattern.test($el.val());// new RegExp(pattern,"i").test($el.val())
            }
        },
        errors: {
            //pattern: "Illegal characters"
        }
    }).on('submit', function (e) {
        e.isDefaultPrevented();
        e.preventDefault();
    });

}
