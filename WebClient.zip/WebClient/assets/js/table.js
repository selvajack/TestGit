function iconFormatter(value, row, index) {
    var returnVal = "";
    if (value === "on" || value === 1 || value === "true") {
        returnVal = '<div class=\'icon-ok\'>&nbsp;</div>';
    } else if (value === "off" || value === 0 || value === "false") {
        returnVal = '<div class=\'icon-no\'>&nbsp;</div>';
    }
    return returnVal;
}

function changeCheckBoxValue(event) {
    event.value = event.checked ? 1 : 0;
}

function checkBoxFormatter(value, row, index) {
    var returnVal = "";
    if (value === "on" || value === 1 || value === "true" || value === "Enabled") {
        returnVal = '<input type="checkbox" checked="true" value="1" onchange="changeCheckBoxValue(this);">';
    } else if (value === "off" || value === 0 || value === "false" || value === "Disabled") {
        returnVal = '<input type="checkbox" value="0" onchange="changeCheckBoxValue(this);">';
    }
    return returnVal;
}

function reachableAndNotReachableFormatter(value, row, index) {
    var returnVal = "";
    if (Number(value) === 1 || value === "Reachable") {
        returnVal = '<div class=\'connected\'>Reachable</div>';
    } else if (Number(value) === 0 || value === "Not Reachable") {
        returnVal = '<div class=\'notconnected\'>Not Reachable</div>';
    }
    return returnVal;
}

function runningAndNotRunningFormatter(value, row, index) {
    var returnVal = "";
    if (Number(value) === 1 || value === "Running") {
        returnVal = '<div class=\'connected\'>Running</div>';
    } else if (Number(value) === 0 || value === "Not Running" || value === "Stopped") {
        returnVal = '<div class=\'notconnected\'>Not Running</div>';
    }
    return returnVal;
}

function backupTakenAndNotFormatter(value, row, index) {
    var returnVal = "";
    if (Number(value) === 1 || value === "Backup Done") {
        returnVal = '<div class=\'connected\'>Backup Done</div>';
    } else if (Number(value) === 0 || value === "Backup Not Taken") {
        returnVal = '<div class=\'notconnected\'>Backup Not Taken</div>';
    }
    return returnVal;
}

var userProfileUpdate = {
    type: 'combobox',
    options: {
        required: false,
        multiple: false,
        editable: false,
        cache: false,
        selectOnNavigation: true,
        valueField: 'profilename',
        textField: 'profilename',
        onChange: function (newValue, oldValue) {
            if (oldValue !== null && oldValue !== undefined && oldValue !== '' && oldValue !== "null") {
                if (newValue) {
                    $('#seluserprofilename').val(newValue);
                }
            }
        }
    }
};

function numericSort(a, b) {
    return b - a;
}

function addData(datagridId, formId) {
    var row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        $('#' + formId).form('load', row);
    }
}

function updateData(datagridId, formId) {
    var row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        $('#' + formId).form('load', row);
    } else {
        $.messager.alert(infoLabel, editRowMessage, 'info');
    }
}

function passwordValidation(row, label) {
    $('#popUpDialogForm').eq(1);
    $("#userdetpassword").validatebox({
        required: true
    });
    $("#userdetconfirmpassword").validatebox({
        required: true,
        validType: "equals['#userdetpassword']"
    });
    if (label !== "Add") {
        if (row) {
            $('#popUpDialogForm').form('load', row);
            $("#userdetconfirmpassword").val($("#userdetpassword").val());
        }

    }
}


function addDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            message = parentRowMessage.replace('<table>', parentTableActionLabel);
            $.messager.alert(infoLabel, message, 'info');
            return;
        }
    }
    requestParams += "&operationDoneBy=" + $.jStorage.get("loginUserName");
    var parameters = $.deserialize(requestParams);
    var columnFields = data.column;
    dialogContent = '<form id="popUpDialogForm" class="popUpDialogForm" method="post" autocomplete="off">' +
            '<table>';
    var editableCount = 0;
    for (var i = 0; i < columnFields.length; i++) {
        $.each(columnFields[i], function (index, data) {
            if (data.editable) {
                editableCount++;
            }
        });
    }
    if (editableCount > 8) {
        colSpanCnt = 0;
    }
    for (var i = 0; i < columnFields.length; i++) {
        $.each(columnFields[i], function (index, data) {
            if (data.editable) {
                if (editableCount > 8) {
                    if (colSpanCnt % 2 === 0) {
                        dialogContent += '<tr>';
                    }
                } else {
                    dialogContent += '<tr>';
                }
                dialogContent += '<th>' + data.title + '</th>' + '<td>';
                dialogContent += generateElementBasedOnType(data, disabledKey, clearChildTables);
                dialogContent += '</td>';
                if (editableCount > 8) {
                    if (colSpanCnt % 2 === 1) {
                        dialogContent += '</tr>';
                    }
                    colSpanCnt++;
                } else {
                    dialogContent += '</tr>';
                }
            }
        });
    }
    dialogContent += '</table></form>';
    $("#popUpDialog").empty().append(dialogContent);
    var row = $('#' + datagridId).datagrid('getSelected');
    if (label === "Update") {
        if (row) {
            $('#popUpDialogForm').form('load', row);
        }
    }
    var widthLimit = 400;
    if (editableCount > 8) {
        widthLimit = 600;
    }
    $('#popUpDialog').dialog({
        cache: false,
        model: true,
        width: widthLimit,
        height: 'auto',
        title: title,
        resizable: false,
        buttons: [{
                text: label,
                iconCls: iconClass,
                handler: function () {
                    okBtn = $(this);
                    $('#popUpDialogForm').form('submit', {
                        url: URL,
                        onSubmit: function (param) {
                            var isValid = $('#popUpDialogForm').form('validate');
                            if (isValid) {
                                $(okBtn).linkbutton('disable');
                                if (parameters) {
                                    $.each(parameters, function (key, value) {
                                        param[key] = value;
                                    });
                                }
                                $("#popUpDialogForm input:checkbox").each(function () {
                                    if ($(this).prop('checked') === true) {
                                        $(this).val('1');
                                        param[$(this).attr('id')] = 1;
                                    } else {
                                        $(this).val('0');
                                        param[$(this).attr('id')] = 0;
                                    }
                                });
                                $("#popUpDialogForm input:disabled").each(function () {
                                    param[$(this).attr('id')] = $(this).val();
                                });
                                if (disabledParam !== null && disabledParam !== undefined && disabledParam !== '' && disabledParam !== "null") {
                                    $.each(disabledParam.split(","), function (index, item) {
                                        param[item] = $("#" + item).val();
                                    });
                                }
                                if (label === "Update") {
                                    if (duplicateParam !== null && duplicateParam !== undefined && duplicateParam !== '' && duplicateParam !== "null") {
                                        $.each(duplicateParam.split(","), function (index, item) {
                                            if (row) {
                                                param["old" + item] = row[item];
                                            }
                                        });
                                    }
                                }
                            }
                            return isValid;
                        },
                        success: function (data) {
                            if (refreshParams["subRequestType"] === "refreshAgent") {
                                var pager = $('#' + parentTableId).datagrid('getPager');
                                pager.pagination('options').onBeforeRefresh();
                            } else {
                                reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                            }
                            $('#popUpDialog').dialog('close');
                            replyFormat = eval('(' + data + ')');
                            updateStatusMessage(replyFormat);
                            //reloadTree();
                        },
                        onLoadError: function () {
                            $('#popUpDialog').dialog('close');
                        }
                    });
                }
            }, {
                text: 'Close',
                iconCls: 'icon-cancel',
                handler: function () {
                    $('#popUpDialog').dialog('close');
                }
            }]
    });
    $('#popUpDialog').dialog('open');
    $('#popUpDialog').dialog('center');
    if (label === "Update") {
        if (disabledParam !== null && disabledParam !== undefined && disabledParam !== '' && disabledParam !== "null") {
            $.each(disabledParam.split(","), function (index, item) {
                $("#" + item).attr("disabled", "disabled");
            });
        }
    }
    $('#popUpDialogForm').find('input, textarea').each(function (i, field) {
        if (!$('#' + field.id).prop('disabled') === true) {
            if ($('#' + field.id).hasClass("easyui-numberbox")) {
                $('#' + field.id).numberbox();
            } else if ($('#' + field.id).hasClass("easyui-datebox")) {
                $('#' + field.id).datebox();
            } else if ($('#' + field.id).hasClass("easyui-datetimebox")) {
                $('#' + field.id).datetimebox();
            } else if ($('#' + field.id).hasClass("easyui-timespinner")) {
                $('#' + field.id).timespinner();
            } else if ($('#' + field.id).hasClass("easyui-numberspinner")) {
                $('#' + field.id).numberspinner();
            } else if ($('#' + field.id).hasClass("spinner")) {
                $('#' + field.id).spinner();
            } else if ($('#' + field.id).hasClass("easyui-textbox")) {
                $('#' + field.id).textbox();
            }
            $('#' + field.id).validatebox($('#' + field.id).data());
            $('#' + field.id).validatebox({
                tipOptions: {// the options to create tooltip
                    showEvent: 'mouseenter',
                    hideEvent: 'mouseleave',
                    showDelay: 0,
                    hideDelay: 0,
                    zIndex: '',
                    onShow: function () {
                        if (!$(this).hasClass('validatebox-invalid')) {
                            if ($(this).tooltip('options').prompt) {
                                $(this).tooltip('update', $(this).tooltip('options').prompt);
                            } else {
                                $(this).tooltip('tip').hide();
                            }
                        } else {
                            $(this).tooltip('tip').css({
                                color: '#000',
                                borderColor: '#CC9933',
                                backgroundColor: '#FFFFCC'
                            });
                        }
                    },
                    onHide: function () {
                        if (!$(this).tooltip('options').prompt) {
                            $(this).tooltip('destroy');
                        }
                    }
                }
            }).tooltip({
                position: 'right',
                content: function () {
                    var opts = $(this).validatebox('options');
                    return opts.prompt;
                },
                onShow: function () {
                    $(this).tooltip('tip').css({
                        color: '#000',
                        borderColor: '#CC9933',
                        backgroundColor: '#FFFFCC'
                    });
                }
            });
        }
    });

    if ($('#userdetpassword').length) {
        passwordValidation(row, label);
    }

    if (label === "Add") {
        if ($('#nbiusradminstate').length) {
            $('#nbiusradminstate').attr("checked", true);
        }
    }
    $('#popUpDialog form:not(.filter) :input:visible:first').focus();
}

function updateDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            message = parentRowMessage.replace('<table>', parentTableActionLabel);
            $.messager.alert(infoLabel, message, 'info');
            return;
        }
    }
    var row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        addDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
    } else {
        $.messager.alert(infoLabel, editRowMessage, 'info');
    }
}

function deleteDataFromServer(parentId, datagridId, refreshURL, refreshParams, URL, requestParams, deleteType, title, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            message = parentRowMessage.replace('<table>', parentTableActionLabel);
            $.messager.alert(infoLabel, message, 'info');
            return;
        }
    }
    requestParams += "&operationDoneBy=" + $.jStorage.get("loginUserName");
    var row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        $.messager.confirm(confirmLabel, deleteMessage + " " + deleteType, function (r) {
            if (r) {
                var parameters = requestParams + "&" + $.param(row);
                replyFormat = getDataFromServer("POST", URL, parameters, "text");
                delStatus = eval('(' + replyFormat + ')');
                if (refreshParams["subRequestType"] === "refreshAgent") {
                    var pager = $('#' + parentTableId).datagrid('getPager');
                    pager.pagination('options').onBeforeRefresh();
                } else {
                    reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                }
                updateStatusMessage(delStatus);
                //reloadTree();
            }
        });
    } else {
        $.messager.alert(infoLabel, deleteRowMessage, 'info');
    }
}

function reloadDataFromServer(parentId, datagridId, URL, requestParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title) {
    $('#' + datagridId).datagrid('clearChecked');
    var emptyData = {};
    emptyData["total"] = 0;
    emptyData['rows'] = [];
    if (clearChildTables !== '' && clearChildTables !== null && clearChildTables !== undefined && clearChildTables !== "null") {
        $.each(clearChildTables.split(","), function (index, item) {
            try {
                $('#' + item).datagrid('loadData', emptyData);
                $('#' + item).datagrid('clearSelections');
                $('#' + item).datagrid('clearChecked');
            } catch (err) {
                try {
                    $('#' + item).form('clear');
                } catch (err) {
                    //Do Nothing
                }
            }
        });
    }
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            message = parentRowMessage.replace('<table>', parentTableActionLabel);
            $.messager.alert(infoLabel, message, 'info');
            return;
        }
    }
    if ($.trim(additionalReqParams) !== null && $.trim(additionalReqParams) !== "null" && $.trim(additionalReqParams) !== undefined && $.trim(additionalReqParams) !== '') {
        parameters = $.deserialize(additionalReqParams);
        for (var key in parameters) {
            if (parameters.hasOwnProperty(key)) {
                var paramStr = parameters[key];
                if (paramStr.indexOf(",") > -1) {
                    var conditionStr = "";
                    $.each(paramStr.split(","), function (index, item) {
                        if (item !== "" && item !== '' && item !== null && item !== undefined && item !== "null") {
                            var itemValue = $("#" + item).val() || $("[name='" + item + "']").val();
                            if (itemValue !== "" && itemValue !== '' && itemValue !== null && itemValue !== undefined && itemValue !== "null" && itemValue !== "All") {
                                if (itemValue.indexOf(",") > -1) {
                                    itemValues = "";
                                    $.each(paramStr.split(","), function (index1, item1) {
                                        if (index1 === 0) {
                                            itemValues = "'" + item1 + "'";
                                        } else {
                                            itemValues = ", '" + item1 + "'";
                                        }
                                    });
                                    conditionStr += " AND " + item + " IN (" + itemValues + ")";
                                } else {
                                    conditionStr += " AND " + item + " = '" + itemValue + "'";
                                }
                            }
                        }
                    });
                    requestParams[key] = conditionStr;
                } else {
                    requestParams[key] = $("#" + paramStr).val() || $("[name='" + paramStr + "']").val();
                }
            }
        }
    }
    parameters = $.param(requestParams);
    var jsonData = getDataFromServer("POST", URL, parameters, "text");
    jsonData = $.trim(jsonData).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var data = eval('(' + jsonData + ')');
    var rowWithTotal = {};
    rowWithTotal["total"] = data.total;
    rowWithTotal['rows'] = data.rows;
    var selected = $('#' + datagridId).datagrid('getSelected');
    var selectedRowIndex = -1;
    if (selected) {
        selectedRowIndex = $('#' + datagridId).datagrid('getRowIndex', selected);
    }
    rowCount = $('#' + datagridId).datagrid('getRows').length;
    $('#' + datagridId).datagrid('loadData', rowWithTotal);
    if (Number(data.total) > 0 && Number(rowCount) <= 0) {
        reloadWithFilter(parentId, datagridId, true, data);
    }
    if (Number(data.total) <= 0) {
        $('#' + datagridId).datagrid('clearSelections');
        reloadWithFilter(parentId, datagridId, true, data);
    }
    if (selected && selectedRowIndex > -1 && Number(data.total) > 0 && Number(rowCount) > 0) {
        if (title === "Delete") {
            $('#' + datagridId).datagrid('clearSelections');
        } else if (title === "Add" || title === "Update") {
            $('#' + datagridId).datagrid('selectRow', selectedRowIndex);
            $('#' + datagridId).datagrid('highlightRow', selectedRowIndex);
        }
    }
    if (title === "Delete") {
        if (Number(rowCount) === 1) {
            $('#' + datagridId).datagrid('clearSelections');
            $('#' + datagridId).datagrid('getPager').pagination('select');
        }
    }
    updateStatusMessage(data);
    setOtherDataGridOptions(datagridId);
    setOtherDataGridOptions1(datagridId);
}

function saveDataAtServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            message = parentRowMessage.replace('<table>', parentTableActionLabel);
            $.messager.alert(infoLabel, message, 'info');
            return;
        }
    }
    var parameters = $.deserialize(requestParams);
    if (datagridId === "userProfileList") {
        parameters["oldprofilename"] = "None";
        var row = $('#' + datagridId).datagrid('getSelected');
        if (row) {
            defaultProfileName = row.profilename;
            selectedProfileName = $("#seluserprofilename").val();
            if (defaultProfileName !== selectedProfileName) {
                parameters["oldprofilename"] = defaultProfileName;
                parameters["userdetloginname"] = $("#seluserdetloginname").val();
                parameters["profilename"] = selectedProfileName;
                parameters["userName"] = $.jStorage.get("loginUserName");
                var data = getDataFromServer("POST", URL, parameters, "text");
                reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                replyFormat = eval('(' + data + ')');
                updateStatusMessage(replyFormat);
            } else {
                $.messager.alert(infoLabel, modifyMsg, 'info');
                return;
            }
        } else {
            $.messager.alert(infoLabel, modifyMsg, 'info');
            return;
        }
    } else if (datagridId === "profileAppsList") {
        var appsinprofreadaccess = new Array();
        var appsinprofwriteaccess = new Array();
        var appfunctionid = new Array();
        var rows = $('#' + datagridId).datagrid('getChecked');
        if (rows.length > 0) {
            for (var i = 0; i < rows.length; i++) {
                row = rows[i];
                rowIndex = $('#' + datagridId).datagrid('getRowIndex', row);
                appsinprofreadaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=appsinprofreadaccess] input:checkbox").val());
                appsinprofwriteaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=appsinprofwriteaccess] input:checkbox").val());
                appfunctionid.push(row.appfunctionid);
            }
            parameters["appsinprofreadaccess"] = appsinprofreadaccess.toString();
            parameters["appsinprofwriteaccess"] = appsinprofwriteaccess.toString();
            parameters["appfunctionid"] = appfunctionid.toString();
            parameters["userName"] = $.jStorage.get("loginUserName");
            parameters["profilename"] = $("#selprofilename").val();
            var data = getDataFromServer("POST", URL, parameters, "text");
            reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
            replyFormat = eval('(' + data + ')');
            updateStatusMessage(replyFormat);
        } else {
            $.messager.alert(infoLabel, checkMsg, 'info');
            return;
        }
    }
}

function doSearch(value, name) {
    var selectedSearchBox = $(this);
    var searchBoxInput = $(this).parent().find('.textbox-text');
    var parentId = $(selectedSearchBox).closest('.datagrid').parent().attr("id");
    var matches = false;
    var searchText = value;
    if (searchText === "Search Text") {
        searchText = "";
    }
    if (searchText.length > 0) {
        $("#" + parentId + " .datagrid-btable tbody tr td:containsNC(" + searchText + ")").each(function () {
            $(this).addClass("highlight-ok");
            matches = true;
        });
        $("#" + parentId + " .datagrid-btable tbody tr td:not(:containsNC(" + searchText + "))").each(function () {
            $(this).removeClass("highlight-ok");
        });
        if (matches) {
            $(searchBoxInput).removeClass('highlight-nok');
            $(searchBoxInput).addClass('highlight-ok');
        } else {
            $(searchBoxInput).removeClass('highlight-ok');
            $(searchBoxInput).addClass('highlight-nok');
        }
    } else {
        $("#" + parentId + " .datagrid-btable tbody tr td").each(function () {
            $(this).removeClass("highlight-ok");
            $(searchBoxInput).removeClass('highlight-ok');
            $(searchBoxInput).removeClass('highlight-nok');
        });
    }
}

function exportAdditionParameters(requestParams, additionalReqParams) {
    if ($.trim(additionalReqParams) !== null && $.trim(additionalReqParams) !== "null" && $.trim(additionalReqParams) !== undefined && $.trim(additionalReqParams) !== '') {
        parameters = $.deserialize(additionalReqParams);
        for (var key in parameters) {
            if (parameters.hasOwnProperty(key)) {
                var paramStr = parameters[key];
                if (paramStr.indexOf(",") > -1) {
                    var conditionStr = "";
                    $.each(paramStr.split(","), function (index, item) {
                        var itemValue = $("#" + item).val() || $("[name='" + item + "']").val();
                        if (itemValue !== "" && itemValue !== '' && itemValue !== null && itemValue !== undefined && itemValue !== "null" && itemValue !== "All") {
                            conditionStr += " and " + item + " = '" + itemValue + "'";
                        }
                    });
                    requestParams[key] = conditionStr;
                } else {
                    requestParams[key] = $("#" + paramStr).val() || $("[name='" + paramStr + "']").val();
                }
            }
        }
    }
    return requestParams;
}

function exportAsCSV(URL, requestParams, additionalReqParams) {
    parameters = exportAdditionParameters(requestParams, additionalReqParams);
    parameters["userName"] = $.jStorage.get("loginUserName");
    URL = serverURL + "/ExportAsCSV";
    $.fileDownload(URL, {
        httpMethod: "POST",
        data: parameters
    });
}

function exportAsExcel(URL, requestParams, additionalReqParams) {
    parameters = exportAdditionParameters(requestParams, additionalReqParams);
    parameters["userName"] = $.jStorage.get("loginUserName");
    URL = serverURL + "/ExportAsExcel";
    $.fileDownload(URL, {
        httpMethod: "POST",
        data: parameters
    });
}

function exportAsPDF(URL, requestParams, additionalReqParams) {
    parameters = exportAdditionParameters(requestParams, additionalReqParams);
    parameters["userName"] = $.jStorage.get("loginUserName");
    URL = serverURL + "/ExportAsPDF";
    $.fileDownload(URL, {
        httpMethod: "POST",
        data: parameters
    });
}

//function exportAsXML(URL, requestParams, additionalReqParams) {
//    parameters = exportAdditionParameters(requestParams, additionalReqParams);
//    parameters["userName"] = $.jStorage.get("loginUserName");
//    URL = serverURL + "/ExportAsXML";
//    $.fileDownload(URL, {
//        httpMethod: "POST",
//        data: parameters
//    });
//}

function addExportIcons(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams);
                }
            }]// {
//                iconCls: 'icon-xml',
//                handler: function () {
//                    exportAsXML(URL, parameters, additionalReqParams);
//                }
//            }]
    });
}

function addRefreshIconAlone(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        }
    });
}

function addActionsIcons(parentId, tableId, data, URL, parameters, addURL, addParameters, editURL, editParameters, delURL, delParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-add',
                handler: function () {
                    addDataToServer(parentId, tableId, data, URL, parameters, addURL, addParameters, "Add " + actionLabel, "Add", "icon-add", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-', {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams);
                }
//            }, {
//                iconCls: 'icon-xml',
//                handler: function () {
//                    exportAsXML(URL, parameters, additionalReqParams);
//                }
            }]
    });
}

function addEditActionIcon(parentId, tableId, data, URL, parameters, editURL, editParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-', {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams);
                }
//            }, {
//                iconCls: 'icon-xml',
//                handler: function () {
//                    exportAsXML(URL, parameters, additionalReqParams);
//                }
            }]
    });
}

function addDelActionIcon(parentId, tableId, data, URL, parameters, editURL, editParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-', {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams);
                }
//            }, {
//                iconCls: 'icon-xml',
//                handler: function () {
//                    exportAsXML(URL, parameters, additionalReqParams);
//                }
            }]
    });
}

function addBothActionAndExportIcons(parentId, tableId, data, URL, parameters, addURL, addParameters, editURL, editParameters, delURL, delParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-add',
                handler: function () {
                    addDataToServer(parentId, tableId, data, URL, parameters, addURL, addParameters, "Add " + actionLabel, "Add", "icon-add", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-', {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams);
                }
//            }, {
//                iconCls: 'icon-xml',
//                handler: function () {
//                    exportAsXML(URL, parameters, additionalReqParams);
//                }
            }]
    });
}

function addSaveAndExportIcons(parentId, tableId, data, URL, parameters, addURL, addParameters, editURL, editParameters, delURL, delParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-save',
                handler: function () {
                    saveDataAtServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Update " + actionLabel, "Update", "icon-save", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-', {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams);
                }
//            }, {
//                iconCls: 'icon-xml',
//                handler: function () {
//                    exportAsXML(URL, parameters, additionalReqParams);
//                }
            }]
    });
}

function pagerFilter(data) {
    if (typeof data.length === 'number' && typeof data.splice === 'function') {
        data = {
            total: data.length,
            rows: data
        };
    }
    var dg = $(this);
    var opts = dg.datagrid('options');
    var pager = dg.datagrid('getPager');
    parentId = $(dg).parent().parent().parent().parent().attr('id');
    datagridId = $(dg).attr('id');
    pager.pagination({
        onSelectPage: function (pageNum, pageSize) {
            opts.pageNumber = pageNum;
            opts.pageSize = pageSize;
            pager.pagination('refresh', {
                pageNumber: pageNum,
                pageSize: pageSize
            });
            dg.datagrid('loadData', data);
            setOtherDataGridOptions(datagridId);
            setOtherDataGridOptions1(datagridId);
        }
    });
    if (!data.originalRows) {
        data.originalRows = (data.rows);
    }
    var start = (opts.pageNumber - 1) * parseInt(opts.pageSize);
    var end = start + parseInt(opts.pageSize);
    data.rows = (data.originalRows.slice(start, end));
    return data;
}

function setOtherDataGridOptions(tableId) {
    var cells = $("#" + tableId).datagrid('getPanel').find('div.datagrid-body td[field] div.datagrid-cell');
    cells.tooltip('destroy');
    cells.tooltip({
        content: function () {
            var tp = $(this).html();
            return tp;
        }
    });
    $('.easyui-searchbox').searchbox();
}

function setOtherDataGridOptions1(tableId) {
    var cells = $("#" + tableId).datagrid('getPanel').find('div.datagrid-header td[field] div.datagrid-cell');
    cells.tooltip('destroy');
    cells.tooltip({
        content: function () {
           var tp = $(this).html();
            return tp;
        }
    });
    $('.easyui-searchbox').searchbox();
}

function setColumnFilter(parentId, tableId, fitColumns, data) {
    if (Number(data.total) > 0) {
        setOtherDataGridOptions(tableId);
        setOtherDataGridOptions1(tableId);
    }
}

function reloadWithFilter(parentId, tableId, fitColumns, data) {
    var rowWithTotal = {};
    rowWithTotal["total"] = data.total;
    rowWithTotal['rows'] = data.rows;
    $('#' + tableId).datagrid('loadData', rowWithTotal);
    if (Number(data.total) > 0) {
        setColumnFilter(parentId, tableId, fitColumns, data);
    }
}


if ($('#statecountryid').length) {
    console.log("inside country combobox map");
        countryList();
    }


function countryList() {
    console.log("inside country list");
    var URL = serverURL + "/FormMgrWithList";
    var parameters = "requestType=CountryManager&subRequestType=refreshCountry&QueryNum=554&key=COUNTRY";
    replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    data = eval('(' + replyFormat + ')');
    updateStatusMessage(data);
    var countryNames = data.rows;
    $('#statecountryid').combobox({
        data: countryNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false
    });
}

