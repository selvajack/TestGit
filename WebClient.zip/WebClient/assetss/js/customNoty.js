function generateNoty(layout, timeout, type, response) {
    var n = noty({
        layout: layout,
        type: type,
        text: response, // can be html or string
        dismissQueue: true, // If you want to use queue feature set this true
        timeout: timeout, // delay for closing event. Set false for sticky notifications
        maxVisible: 1, // you can set max visible notification for dismissQueue true option,
        killer: true
                // for close all notifications before show
    });
}