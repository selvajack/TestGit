var Login = function() {
	
	$("#login-btn").click(function() {
		loginCheck();
	});
	$("#forget-btn").click(function() {
		forgetPasswordCheck();
	});
	$("#reset-btn").click(function() {
		resetPasswordCheck();
	});
	jQuery('#forget-password').click(function() {
		jQuery('.login-form').hide();
		jQuery('.forget-form').show();
	});

	jQuery('#back-btn').click(function() {
		jQuery('.login-form').show();
		jQuery('.forget-form').hide();
	});
	
	//$("#username, #email").blur(function(){
		//   if(!validteEmail($('#username').val())){
			//   generateNoty('topCenter', 2000, 'error',
				//"Email Id is not valid."); 
	//}
	//});
		
	function validteEmail(email){
		var pattern = new RegExp(/^(("[\w-+\s]+")|([\w-+]+(?:\.[\w-+]+)*)|("[\w-+\s]+")([\w-+]+(?:\.[\w-+]+)*))(@((?:[\w-+]+\.)*\w[\w-+]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][\d]\.|1[\d]{2}\.|[\d]{1,2}\.))((25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\.){2}(25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\]?$)/i);
		return pattern.test(email);
	}

	function loginCheck() {
		if ($('#username').val().length === 0
				&& $('#password').val().length === 0) {
			generateNoty('topCenter', 800, 'error',
					"Email Id and password can not be blank");
		} else if ($('#password').val().length === 0) {
			generateNoty('topCenter', 800, 'error', "password can not be blank");
		} else if ($('#username').val().length === 0) {
			generateNoty('topCenter', 800, 'error', "Email Id can not be blank");
		}  else if(!validteEmail($('#username').val())){
			   generateNoty('topCenter', 2000, 'error',
				"Email Id is not valid."); 
		}  else {
			//alert($('#remember').prop('checked'));
			var input = {
				"userId" : $('#username').val(),
				"password" : $('#password').val()
			};
			var input2 = {
					"userId" : $('#username').val(),
					"password" : $('#password').val()
				};
			$.ajax({
				url : "authenticate/"+$('#remember').prop('checked'),
				type : "POST",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(input),
				success : function(data) {
					console.log(data);
					if (data.status == "true") {
						if(data.roleName=='DRIVER')
							{
							//alert(data.roleName)
							//Driver login
							$.ajax({
								url : "ocppDriver/driver/authenticate/"+$('#remember').prop('checked'),
								type : "POST",
								contentType : "application/json",
								dataType : "json",
								crossDomain: true,
								data : JSON.stringify(input2),
								success : function(data) {
									console.log(data);
									if (data.status == "true") {
										window.location.href = "ocppDriver/driver/index";
									} else {
										generateNoty('topCenter', 800, 'error',
												"Invalid email or password.");
									}
								},
								error : function(status) {
									console.log(status);
									generateNoty('topCenter', 800, 'error',
											"Error Occured. Please try again Later.");
								}
							});
							
							//End
							}
						else
							{
							$.ajax({
								url : "ocppDriver/driver/externalAuthenticate/"+$('#remember').prop('checked'),
								type : "POST",
								contentType : "application/json",
								dataType : "json",
								crossDomain: true,
								data : JSON.stringify(input2),
								success : function(data) {
									console.log(data);
									if (data.status == "true") {
										window.location.href = "dashboard";
									} else {
										window.location.href = "dashboard";
//										generateNoty('topCenter', 800, 'error',
//												"Invalid email or password.");
									}
								},
								error : function(status) {
									console.log(status);
									generateNoty('topCenter', 800, 'error',
											"Error Occured. Please try again Later.");
								}
							});
						//	window.location.href = "dashboard";
							
							}
						
					} else {
						generateNoty('topCenter', 800, 'error',
								"Invalid email or password.");
					}
				},
				error : function(status) {
					console.log(status);
					generateNoty('topCenter', 800, 'error',
							"Error Occured. Please try again Later.");
				}
			});
		}
	}
	function forgetPasswordCheck() {
		if ($('#email').val().length === 0 ) {
			generateNoty('topCenter', 800, 'error',
					"Email can not be blank");
		
		} else if(!validteEmail($('#email').val())){
			   generateNoty('topCenter', 800, 'error',
				"Email Id is not valid."); 
		}  
		else {
				$.ajax({
				url : "sendForgotPasswordMail?userId="+$("#email").val(),
				type : "GET",
				contentType : "application/json",
				dataType : "json",
				success : function(data) {
					console.log(data);
					if (data.status == "true") {
						generateNoty('topCenter',5000, 'success',
						"Reset Password Link sent to your email.");
						
					} else {
						generateNoty('topCenter', 800, 'error',
						"you haven't registered yet.");
					}
				},
				error : function(status) {
					console.log(status);
					generateNoty('topCenter', 800, 'error',
					"Error Occured. Please try again Later.");
				}
				
			});
		}
	}
	function resetPasswordCheck(){
		if ($('#password').val().length === 0 && $('#confirm-password').val().length === 0) {
            generateNoty('topCenter', 800, 'error', "Please Enter password to reset");
        }
        else if ($('#password').val().length === 0) {
            generateNoty('topCenter', 800, 'error', "Password can not be blank");
        }
        else if ($('#confirm-password').val().length === 0) {
            generateNoty('topCenter', 800, 'error', "Please Confirm your Password");
        }
		else if($('#password').val() === $('#confirm-password').val()){
				$.urlParam = function(name){
				var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
				if (results==null){
					return null;
				}
				else{
					return results[1] || 0;
				}
		}
		var userId = $.urlParam('userId'); 
		var token = $.urlParam('token'); 
		var data = '{"userId":"'+userId+'","password":"'+$('#password').val()+'","token":"'+token+'"}';
		console.log(data);
		$.ajax({
			url : "updatePassword",
			type : "POST",
			contentType : "application/json",
			dataType : "json",
			data : data,
			error : function(status) {
				alert("Problem in reset password");
			},
			success : function(data) {
				console.log(data);
				if (data.status == "true") {
					generateNoty('topCenter', false, 'success', "Password Change Successfully.!");
					setTimeout(function redirect(){
						window.location.href = "login";
					},2000);
				} else {
					generateNoty('topCenter', false, 'error', "Problem occured. Please Try again Later.");
				}
			}
		});
	
		}
        else {
			generateNoty('topCenter', 800, 'error', "Confirm Password should match");
		}		
	}
	
	function generateNoty(layout, timeout, type, response) {
		var n = noty({
			layout : layout,
			type : type,
			text : response, // can be html or string
			dismissQueue : true, // If you want to use queue feature set this true
			timeout : timeout, // delay for closing event. Set false for sticky notifications
			maxVisible : 1, // you can set max visible notification for dismissQueue true option,
			killer : true
		// for close all notifications before show
		});
	}

	$('.login-form input').keypress(function(e) {
		if (e.which == 13) {
			loginCheck();
			return false;
		}
	});
	$('.forget-form input').keypress(function(e) {
		if (e.which == 13) {
			forgetPasswordCheck();
			return false;
		}
	});
	$('.reset-form input').keypress(function(e) {
		if (e.which == 13) {
			resetPasswordCheck();
			return false;
		}
	});
	return {
		//        //main function to initiate the module
		init : function() {

			$.backstretch([ "public/img/bg/1.jpg",
					"public/img/bg/2.jpg",
					"public/img/bg/3.jpg"], {
				fade : 1000,
				duration : 1000
			});
		}
	//
	};

}();