var neTypeDetailsRowData = "";
var neSubTypeDetailsRowData = "";
var dataLoggerNeSubTypeDetailsRowData = "";
var snmpNeSubTypeDetailsRowData = "";
var neCommTypeForSubType = {};
var neVersionsRowData = "";
var operatorTypesRowData = "";
var neVersionEntityRowData = "";
var neVersionsWithEntity = "";
var neVersionsWithEntityArray = {};
var neVersionsWithEntityTypeArray = {};
var tableCMenuArray = {};
var tableEditIndex = {};
var chillerNeId = 0;

$.extend($.fn.datagrid.methods, {
    keyCtrl: function (jq) {
        return jq.each(function () {
            var grid = $(this);
            grid.datagrid('getPanel').panel('panel').attr('tabindex', 1).bind('keydown', function (e) {
                var selected;
                var index;
                switch (e.keyCode) {
                    case 38: // up
                        selected = grid.datagrid('getSelected');
                        if (selected) {
                            index = grid.datagrid('getRowIndex', selected);
                            if (index > 0) {
                                grid.datagrid('selectRow', index - 1);
                            }
                        } else {
                            var rows = grid.datagrid('getRows');
                            grid.datagrid('selectRow', rows.length - 1);
                        }
                        break;
                    case 40: // down
                        selected = grid.datagrid('getSelected');
                        if (selected) {
                            index = grid.datagrid('getRowIndex', selected);
                            if (index < grid.datagrid('getRows').length - 1) {
                                grid.datagrid('selectRow', index + 1);
                            }
                        } else {
                            grid.datagrid('selectRow', 0);
                        }
                        break;
                }
            });
        });
    }
});

function addAddtReqParamToReqParam(parameters, additionalReqParams) {
    if ($.trim(additionalReqParams) !== null && $.trim(additionalReqParams) !== "null" && $.trim(additionalReqParams) !== undefined && $.trim(additionalReqParams) !== '') {
        var addReqParameters = $.deserialize(additionalReqParams);
        for (var key in addReqParameters) {
            if (addReqParameters.hasOwnProperty(key)) {
                var paramStr = addReqParameters[key];
                if (paramStr.indexOf(",") > -1) {
                    var conditionStr = "";
                    $.each(paramStr.split(","), function (index, item) {
                        if (item !== "" && item !== '' && item !== null && item !== undefined && item !== "null") {
                            var itemValue = $("#" + item).val() || $("[name='" + item + "']").val();
                            if (itemValue !== "" && itemValue !== '' && itemValue !== null && itemValue !== undefined && itemValue !== "null" && itemValue !== "All") {
                                if (itemValue.indexOf(",") > -1) {
                                    var itemValues = "";
                                    $.each(paramStr.split(","), function (index1, item1) {
                                        if (index1 === 0) {
                                            itemValues = "'" + item1 + "'";
                                        } else {
                                            itemValues = ", '" + item1 + "'";
                                        }
                                    });
                                    conditionStr += " AND " + item + " IN (" + itemValues + ")";
                                } else {
                                    conditionStr += " AND " + item + " = '" + itemValue + "'";
                                }
                            }
                        }
                    });
                    parameters[key] = conditionStr;
                } else {
                    //parameters[key] = $("#" + paramStr).val() || $("[name='" + paramStr + "']").val() || Number(-1);
                    parameters[key] = $("#" + paramStr).val() || $("[name='" + paramStr + "[]']").map(function () {
                        return $(this).val();
                    }).get().toString() || $("[name='" + paramStr + "']").val() || Number(-1);
                }
            }
        }
    }
    return parameters;
}

function getNETypeDetailsFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNeTypeDetails&QueryNum=1151&key=NE_TYPE_DETAILS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    neTypeDetailsRowData = data.rows;
}

function getNESubTypeDetailsFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNeSubTypeDetails&QueryNum=1167&key=NE_SUB_TYPE_DETAILS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    neSubTypeDetailsRowData = data.rows;
    $.each(data.rows, function (index, value) {
        neCommTypeForSubType[value.text] = value.nesubtypecommtype;
    });
}

function getDataLoggerNESubTypeDetailsFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNeSubTypeDetails&QueryNum=1173&key=NE_SUB_TYPE_DETAILS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    dataLoggerNeSubTypeDetailsRowData = data.rows;
}

function getSNMPNESubTypeDetailsFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNeSubTypeDetails&QueryNum=1180&key=NE_SUB_TYPE_DETAILS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    snmpNeSubTypeDetailsRowData = data.rows;
}

function getNEVersionsListFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNeVersions&QueryNum=1161&key=NE_VERSIONS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    neVersionsRowData = data.rows;
}

function getNEVersionsEntityFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNeVersionEntity&QueryNum=1165&key=NE_VERSIONS_ENTITY";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    neVersionEntityRowData = data.rows;
    $.each(data.rows, function (index, value) {
        neVersionsWithEntityArray[value.neverentityversionnumber] = value.neverentitynames;
        neVersionsWithEntityTypeArray[value.neverentityversionnumber] = value.neverentitytypes;
    });
}

function getOperatorTypeListFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=UserManager&subRequestType=refreshOperatorTypes&QueryNum=2027&key=OPERATOR_TYPES";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    operatorTypesRowData = data.rows;
}

function getNEVersionsWithEntityFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/getNeVersionsWithEntity";
    var parameters = "requestType=NEManager&subRequestType=refreshNeVersionsWithEntity&key=NE_VERSIONS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    neVersionsWithEntity = data.data;
}

function getChillerNeIdFromServer() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgr";
    var parameters = "requestType=NEManager&subRequestType=getChillerNeId&key=CHILLER_NE_ID&QueryNum=1178";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    chillerNeId = data.formdata.neid;
}

function loadDefault() {
    getNETypeDetailsFromServer();
    getNESubTypeDetailsFromServer();
    getDataLoggerNESubTypeDetailsFromServer();
    getSNMPNESubTypeDetailsFromServer();
    getNEVersionsListFromServer();
    getOperatorTypeListFromServer();
    //getNEVersionsWithEntityFromServer();
    getNEVersionsEntityFromServer();
    getChillerNeIdFromServer();
}

function iconFormatter(value, row, index) {
    var returnVal = "";
    if (value === "on" || value === 1 || value === "true") {
        returnVal = '<div class=\'icon-ok\'>&nbsp;</div>';
    } else if (value === "off" || value === 0 || value === "false") {
        returnVal = '<div class=\'icon-no\'>&nbsp;</div>';
    }
    return returnVal;
}

function swBinaryFileFileName(value, row, index) {
    var href = $.jStorage.set("FilePath") + value;
    return '<a target="_blank" href="' + href + '">' + value + '</a>';
}

function parseColor(color) {
    color = '#' + ('00000' + (color | 0).toString(16)).substr(-6);
    return color;
}

function mapKeyValues(value, row, index) {
    var returnVal = value;
    var modifiedValue = value;
    var frmterCellClass = $(this).attr('cellClass');
    var tableId = $("div." + frmterCellClass).parentsUntil('div.datagrid').children('.datagrid-f').attr('id');
    var mapkeys = $(this).attr('mapkeys');
    var mapvalues = $(this).attr('mapvalues');
    var bgcolors = $(this).attr('bgcolors');
    var type = $(this).attr('type');
    var field = $(this).attr('field');
    var title = $(this).attr('title');
    var keys = mapkeys.split(',');
    var values = mapvalues.split(',');
    var colors = bgcolors.split(',');
    if (mapkeys !== null && mapkeys !== "" && mapkeys !== undefined && mapkeys !== "None" && mapkeys !== "none") {
        if (mapvalues !== null && mapvalues !== "" && mapvalues !== undefined && mapvalues !== "None" && mapvalues !== "none") {
            if (keys.length === values.length) {
                $.each(keys, function (keyIndex, keyValue) {
                    if ($.trim(keyValue) === $.trim(value)) {
                        var matchedValue = $.trim(values[keyIndex]);
                        if (matchedValue !== null && matchedValue !== "" && matchedValue !== undefined && matchedValue !== "None" && matchedValue !== "none") {
                            if (type !== null && type !== "" && type !== undefined && type.toLowerCase() === "checkbox") {
                                if (matchedValue === "on" || matchedValue === 1 || matchedValue === "true" || matchedValue === "Enabled") {
                                    returnVal = '<input class="' + field + '_col_checkbox" type="checkbox" checked="true" value="1" onchange="changeCheckBoxValue(this, \'' + field + '_checkbox\');">';
                                } else if (matchedValue === "off" || matchedValue === 0 || matchedValue === "false" || matchedValue === "Disabled") {
                                    returnVal = '<input class="' + field + '_col_checkbox" type="checkbox" value="0" onchange="changeCheckBoxValue(this, \'' + field + '_checkbox\');">';
                                }
                            } else {
                                modifiedValue = matchedValue;
                                returnVal = matchedValue;
                            }
                            if (bgcolors !== null && bgcolors !== "" && bgcolors !== undefined && bgcolors !== "None" && bgcolors !== "none") {
                                if (keys.length === colors.length) {
                                    var matchedColor = $.trim(colors[keyIndex]);
                                    if (matchedColor !== null && matchedColor !== "" && matchedColor !== undefined && matchedColor !== "None" && matchedColor !== "none") {
                                        modifiedValue = matchedValue;
                                        returnVal = '<div style="background-color:' + parseColor(matchedColor) + '">' + matchedValue + '</div>';
                                    }
                                }
                            }
                        }
                        return;
                    }
                });
            }
        }
    }
    //row[field] = modifiedValue;
    return returnVal;
}

function durationToHumanReadable(seconds) {
    var levels = [
        [Math.floor(seconds / 31536000), 'years'],
        [Math.floor((seconds % 31536000) / 86400), 'days'],
        [Math.floor(((seconds % 31536000) % 86400) / 3600), 'hours'],
        [Math.floor((((seconds % 31536000) % 86400) % 3600) / 60), 'minutes'],
        [(((seconds % 31536000) % 86400) % 3600) % 60, 'seconds']
    ];
    var returntext = '';
    for (var i = 0, max = levels.length; i < max; i++) {
        if (levels[i][0] === 0)
            continue;
        returntext += ' ' + levels[i][0] + ' ' + (levels[i][0] === 1 ? levels[i][1].substr(0, levels[i][1].length - 1) : levels[i][1]);
    }
    return returntext.trim();
}

function hoursFormatter(value, row, index) {
    var returnVal = value;
    if ($.trim(value) !== null && $.trim(value) !== "" && $.trim(value) !== undefined) {
        var h = parseFloat(value).toFixed(2).toString().split(".")[0];
        var mTemp = ((parseFloat(value).toFixed(2).toString().split(".")[1] * 60) / 100);
        var m = mTemp.toString().split(".")[0];
        var s = mTemp.toString().split(".")[1] || 0;
        var s1 = ((h * 60 * 60) + (m * 60) + parseInt(s));
        returnVal = durationToHumanReadable(s1);
    }
    return returnVal;
}

function checkAllUncheckAll(fieldCheckBoxClass) {
    var colCheckBoxClass = fieldCheckBoxClass.replace("_checkbox", "_col_checkbox");
    if ($("." + colCheckBoxClass).length > 0 && $("." + colCheckBoxClass).length === $("." + colCheckBoxClass + ":checked").length) {
        $("input." + fieldCheckBoxClass).attr("checked", true);
        $('input.' + fieldCheckBoxClass).prop("checked", true);
    } else {
        $("." + fieldCheckBoxClass).attr("checked", false);
        $('input.' + fieldCheckBoxClass).prop("checked", false);
    }
}

function changeCheckBoxValue(event, fieldCheckBoxClass) {
    var colCheckBoxClass = fieldCheckBoxClass.replace("_checkbox", "_col_checkbox");
    if ($("." + colCheckBoxClass).length === $("." + colCheckBoxClass + ":checked").length) {
        $("input." + fieldCheckBoxClass).attr("checked", true);
        $('input.' + fieldCheckBoxClass).prop("checked", true);
    } else {
        $("." + fieldCheckBoxClass).attr("checked", false);
        $('input.' + fieldCheckBoxClass).prop("checked", false);
    }
    event.value = event.checked ? 1 : 0;
}

function selectAllCheckBox(event) {
    var fieldCheckBoxClass = $(event).attr('id');
    var colCheckBoxClass = fieldCheckBoxClass.replace("_checkbox", "_col_checkbox");
    $('.' + colCheckBoxClass).attr('checked', event.checked ? true : false);
    $('.' + colCheckBoxClass).prop('checked', event.checked ? true : false);
    $('.' + colCheckBoxClass).val(event.checked ? 1 : 0);
}

function checkBoxFormatter(value, row, index) {
    var returnVal = "";
    if (value === "on" || value === 1 || value === "true" || value === "Enabled") {
        returnVal = '<input type="checkbox" checked="true" value="1" onchange="changeCheckBoxValue(this);">';
    } else if (value === "off" || value === 0 || value === "false" || value === "Disabled") {
        returnVal = '<input type="checkbox" value="0" onchange="changeCheckBoxValue(this);">';
    }
    return returnVal;
}

function reachableAndNotReachableFormatter(value, row, index) {
    var returnVal = "";
    if (Number(value) === 1 || value === "Reachable") {
        returnVal = '<div class=\'connected\'>Reachable</div>';
    } else if (Number(value) === 0 || value === "Not Reachable") {
        returnVal = '<div class=\'notconnected\'>Not Reachable</div>';
    }
    return returnVal;
}

function runningAndNotRunningFormatter(value, row, index) {
    var returnVal = "";
    if (Number(value) === 1 || value === "Running") {
        returnVal = '<div class=\'connected\'>Running</div>';
    } else if (Number(value) === 0 || value === "Not Running" || value === "Stopped") {
        returnVal = '<div class=\'notconnected\'>Not Running</div>';
    }
    return returnVal;
}

function backupTakenAndNotFormatter(value, row, index) {
    var returnVal = "";
    if (Number(value) === 1 || value === "Backup Done") {
        returnVal = '<div class=\'connected\'>Backup Done</div>';
    } else if (Number(value) === 0 || value === "Backup Not Taken") {
        returnVal = '<div class=\'notconnected\'>Backup Not Taken</div>';
    }
    return returnVal;
}

function swUpldFileFileName(value, row, index) {
    var fileName = value.split("/").pop();
    var href = $.i18n.prop('SERVER_URL') + "/" + $.i18n.prop('SW_UPLOAD_FILE_PATH_LINK') + "/" + fileName;
    return '<a target="_blank" href="' + href + '">' + fileName + '</a>';
}

var userProfileUpdate = {
    type: 'combobox',
    options: {
        required: false,
        multiple: false,
        editable: false,
        cache: false,
        selectOnNavigation: true,
        valueField: 'profilename',
        textField: 'profilename',
        onChange: function (newValue, oldValue) {
            if (oldValue !== null && oldValue !== undefined && oldValue !== '' && oldValue !== "null") {
                if (newValue) {
                    $('#seluserprofilename').val(newValue);
                }
            }
        }
    }
};
var UserDefaultNEPrivileges = {
    type: 'combobox',
    options: {
        required: false,
        multiple: false,
        editable: false,
        cache: false,
        selectOnNavigation: true,
        valueField: 'value',
        textField: 'text',
        onChange: function (newValue, oldValue) {
            if (oldValue !== null && oldValue !== undefined && oldValue !== '' && oldValue !== "null") {
                if (newValue) {
                    $('#seluserdefneprvprofilename').val(newValue);
                }
            }
        }
    }
};
var UserNEPrivileges = {
    type: 'combobox',
    options: {
        required: false,
        multiple: false,
        editable: false,
        cache: false,
        selectOnNavigation: true,
        valueField: 'value',
        textField: 'text',
        onChange: function (newValue, oldValue) {
            if (oldValue !== null && oldValue !== undefined && oldValue !== '' && oldValue !== "null") {
                if (newValue) {
                    $('#seluserneprvprofilename').val(newValue);
                }
            }
        }
    }
};
function numericSort(a, b) {
    return b - a;
}

function addData(datagridId, formId) {
    var row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        $('#' + formId).form('load', row);
    }
}

function updateData(datagridId, formId) {
    var row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        $('#' + formId).form('load', row);
    } else {
        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('EDIT_ROW_MSG'), 'info');
    }
}

function passwordValidation(row, label) {
    $('#popUpDialogForm').eq(1);
    if (label !== "Add") {
        if (row) {
            $('#popUpDialogForm').form('load', row);
            $("#userdetconfirmpassword").val($("#userdetpassword").val());
        }

    }
}

function showAndHideElements(showElements, hideElements) {
    $.each(showElements.split(','), function (index, item) {
        $("#" + item).show();
    });
    $.each(hideElements.split(','), function (index, item) {
        $("#" + item).hide();
    });
}

function communicationTypes() {
    $('#nesubtypename').combobox({
        url: $.i18n.prop('CLIENT_URL') + '/' + $.i18n.prop('COMMUNICATION_TYPES_URL'),
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: false,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                if (newValue === 1) {
                    showAndHideElements("agentip,agentport", "agentuserid,agentmobilenumber");
                } else if (newValue === 2) {
                    showAndHideElements("agentuserid", "agentip,agentport,agentmobilenumber");
                } else if (newValue === 3) {
                    showAndHideElements("agentmobilenumber", "agentip,agentport,agentuserid");
                } else if (newValue === 4) {
                    showAndHideElements("agentuserid,agentmobilenumber", "agentip,agentport");
                }
            }
        }
    });
    comboboxSearchOnSelect("nesubtypename");
}

function enableTextBoxValidation(elementId) {
    try {
        $("#" + elementId).validatebox('enableValidation');
        $("#" + elementId).validatebox('validate');
    } catch (e) {
//Do Nothing
    }
    try {
        $("#" + elementId).textbox('enableValidation');
        $("#" + elementId).textbox('validate');
    } catch (e) {
//Do Nothing
    }
}

function disableTextBoxValidation(elementId) {
    try {
        $("#" + elementId).validatebox('disableValidation');
        $("#" + elementId).validatebox('validate');
    } catch (e) {
//Do Nothing
    }
    try {
        $("#" + elementId).textbox('disableValidation');
        $("#" + elementId).textbox('validate');
    } catch (e) {
//Do Nothing
    }
}

function enableNumberSpinnerValidation(elementId) {
    try {
        $("#" + elementId).validatebox('enableValidation');
        $("#" + elementId).validatebox('validate');
    } catch (e) {
//Do Nothing
    }
    try {
        $("#" + elementId).numberspinner('enableValidation');
        $("#" + elementId).numberspinner('validate');
    } catch (e) {
//Do Nothing
    }
}

function disableNumberSpinnerValidation(elementId) {
    try {
        $("#" + elementId).validatebox('disableValidation');
        $("#" + elementId).validatebox('validate');
    } catch (e) {
//Do Nothing
    }
    try {
        $("#" + elementId).numberspinner('disableValidation');
        $("#" + elementId).numberspinner('validate');
    } catch (e) {
//Do Nothing
    }
}

function enableAndDisableAgentInputs(nesubtypename) {
    var communicationType = neCommTypeForSubType[nesubtypename];
    if (communicationType === 1 || communicationType === "1") {
        enableTextBoxValidation("agentip");
        $("#agentip").closest("tr").show();
        enableNumberSpinnerValidation("agentport");
        $("#agentport").closest("tr").show();
        disableTextBoxValidation("agentuserid");
        $("#agentuserid").closest("tr").hide();
        //disableTextBoxValidation("agentmobilenumber");
        //$("#agentmobilenumber").closest("tr").hide();
    } else if (communicationType === 2 || communicationType === "2") {
        disableTextBoxValidation("agentip");
        $("#agentip").closest("tr").hide();
        disableNumberSpinnerValidation("agentport");
        $("#agentport").closest("tr").hide();
        enableTextBoxValidation("agentuserid");
        $("#agentuserid").closest("tr").show();
        //disableTextBoxValidation("agentmobilenumber");
        //$("#agentmobilenumber").closest("tr").hide();
    }
}

function neSubTypesList(dataGridId, neSubTypeId, neVersionId) {
    if (dataGridId.indexOf('dataLogger') > -1) {
        $('#' + neSubTypeId).combobox({
            data: dataLoggerNeSubTypeDetailsRowData,
            valueField: 'value',
            textField: 'text',
            cache: false,
            required: true,
            multiple: false,
            editable: false,
            selectOnNavigation: true,
            onChange: function (newValue, oldValue) {
                if (newValue !== oldValue) {
                    try {
                        $("#" + neVersionId).combobox('clear');
                        $("#" + neVersionId).combobox('loadData', "");
                    } catch (e) {
                        //Do Nothing
                    }
                    neVersionsList(newValue, neVersionId);
                }
            }
        });
    } else if (dataGridId.indexOf('snmp') > -1) {
        $('#' + neSubTypeId).combobox({
            data: snmpNeSubTypeDetailsRowData,
            valueField: 'value',
            textField: 'text',
            cache: false,
            required: true,
            multiple: false,
            editable: false,
            selectOnNavigation: true,
            onChange: function (newValue, oldValue) {
                if (newValue !== oldValue) {
                    try {
                        $("#" + neVersionId).combobox('clear');
                        $("#" + neVersionId).combobox('loadData', "");
                    } catch (e) {
                        //Do Nothing
                    }
                    neVersionsList(newValue, neVersionId);
                }
            }
        });
    } else {
        $('#' + neSubTypeId).combobox({
            data: neSubTypeDetailsRowData,
            valueField: 'value',
            textField: 'text',
            cache: false,
            required: true,
            multiple: false,
            editable: false,
            selectOnNavigation: true,
            onChange: function (newValue, oldValue) {
                if (newValue !== oldValue) {
                    try {
                        $("#" + neVersionId).combobox('clear');
                        $("#" + neVersionId).combobox('loadData', "");
                    } catch (e) {
                        //Do Nothing
                    }
                    neVersionsList(newValue, neVersionId);
                    enableAndDisableAgentInputs(newValue);
                }
            },
            onLoadSuccess: function () {
                var selectedValue = $(this).combobox('getValue');
                if (selectedValue !== null && selectedValue !== "" && selectedValue !== undefined) {
                    enableAndDisableAgentInputs(selectedValue);
                }
            }
        });
    }
    comboboxSearchOnSelect(neSubTypeId);
}

function neVersionsList(neSubTypeName, neVersionId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNeVersions&QueryNum=1168&key=NE_VERSIONS&Parm1=" + neSubTypeName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var neVersions = data.rows;
    $('#' + neVersionId).combobox({
        data: neVersions,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(neVersionId);
}

function neVersionsListForProfile() {
    $("#profileneversionnumber").combobox({
        data: neVersionsRowData,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("profileneversionnumber");
}

function operatorTypesList(id) {
    $('#' + id).combobox({
        data: operatorTypesRowData,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(id);
}

function groupNameList() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=GroupManager&subRequestType=refreshGroupName&QueryNum=1006&key=GROUP_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var groupNames = data.rows;
    $('#buldgroupname').combobox({
        data: groupNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("buldgroupname");
}

function buildingNameListForNE(buildingListId, floorListId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=BuildingManager&subRequestType=refreshBuildingName&QueryNum=1056&key=BUILDING_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var buildingNames = data.rows;
    $("#" + buildingListId).combobox({
        data: buildingNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#" + floorListId).combobox('clear');
                    $("#" + floorListId).combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                floorNameListForNE(newValue, floorListId);
            }
        }
    });
    comboboxSearchOnSelect(buildingListId);
}

function floorNameListForNE(buldingName, floorListId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=FloorManager&subRequestType=refreshFloorName&QueryNum=1107&key=FLOOR_NAME&Parm1=" + buldingName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var floorNames = data.rows;
    $("#" + floorListId).combobox({
        data: floorNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(floorListId);
}
// combobox for Parent NE Name
function parentNeNameListForMeterAssociation(parentNeId, parentSubSysId, childNeId, childSubSysId) {
    $("#" + parentSubSysId).combobox({disabled: true});
    $("#" + childNeId).combobox({disabled: true});
    $("#" + childSubSysId).combobox({disabled: true});
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=meterAssociationManager&subRequestType=refreshMeterAssociationName&QueryNum=10009&key=METER_ASSOCIATION_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var neNames = data.rows;
    $("#" + parentNeId).combobox({
        data: neNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#" + parentSubSysId).combobox('clear');
                } catch (e) {
                    //Do Nothing
                }
                parentSubSysNameListForMeterAssociation(newValue, parentSubSysId, childNeId, childSubSysId);
            }
        }
    });
    comboboxSearchOnSelect(parentNeId);
}

// combobox for Parent SubSystemName
function parentSubSysNameListForMeterAssociation(parentNeName, parentSubSysId, childNeId, childSubSysId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=meterAssociationManager&subRequestType=refreshMeterAssociationName&QueryNum=10002&key=METER_ASSOCIATION_NAME&Parm1=" + parentNeName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var parentSubSysNames = data.rows;
    $("#" + parentSubSysId).combobox({
        data: parentSubSysNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        disabled: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#" + childNeId).combobox('clear');
                } catch (e) {
                    //Do Nothing
                }
                childNeNameListForMeterAssociation(newValue, childNeId, childSubSysId);
            }
        }
    });
    comboboxSearchOnSelect(parentSubSysId);
}

// combobox for Child NE Name
function childNeNameListForMeterAssociation(parentSubSysName, childNeId, childSubSysId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=meterAssociationManager&subRequestType=refreshMeterAssociationName&QueryNum=10009&key=METER_ASSOCIATION_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var childNeNames = data.rows;
    $("#" + childNeId).combobox({
        data: childNeNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        disabled: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#" + childSubSysId).combobox('clear');
                } catch (e) {
                    //Do Nothing
                }
                childSubSysNameListForMeterAssociation(newValue, childSubSysId, parentSubSysName);
            }
        }
    });
    comboboxSearchOnSelect(childNeId);
}

// combobox for Child SubSystemName
function childSubSysNameListForMeterAssociation(childNeName, childSubSysId, parentSubSysName) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=meterAssociationManager&subRequestType=refreshMeterAssociationName&QueryNum=10003&key=METER_ASSOCIATION_NAME&Parm1=" + childNeName + "&Parm2=" + parentSubSysName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var childSubSysNames = data.rows;
    $("#" + childSubSysId).combobox({
        data: childSubSysNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        disabled: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(childSubSysId);
}

function typeNameListForMeterAssociation(typeId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=meterAssociationManager&subRequestType=refreshMeterAssociationName&QueryNum=10008&key=METER_ASSOCIATION_TYPE_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var floorNames = data.rows;
    $("#" + typeId).combobox({
        data: floorNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(typeId);
}

function buildingNameListForTenant(buildingListId, floorListId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=BuildingManager&subRequestType=refreshBuildingName&QueryNum=1056&key=BUILDING_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var buildingNames = data.rows;
    $("#" + buildingListId).combobox({
        data: buildingNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#" + floorListId).combobox('clear');
                    $("#" + floorListId).combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                floorNameListForTenant(newValue, floorListId);
            }
        }
    });
    comboboxSearchOnSelect(buildingListId);
}

function buildingNameListForIPCAM(buildingListId, floorListId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=BuildingManager&subRequestType=refreshBuildingName&QueryNum=1056&key=BUILDING_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var buildingNames = data.rows;
    $("#" + buildingListId).combobox({
        data: buildingNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#" + floorListId).combobox('clear');
                } catch (e) {
                    //Do Nothing
                }
                floorNameListForIPCAM(newValue, floorListId);
            }
        }
    });
    comboboxSearchOnSelect(buildingListId);
}

function floorNameListForTenant(buldingName, floorListId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=FloorManager&subRequestType=refreshFloorName&QueryNum=1107&key=FLOOR_NAME&Parm1=" + buldingName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var floorNames = data.rows;
    $("#" + floorListId).combobox({
        data: floorNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#tenantasscnename").combobox('clear');
                    $("#tenantasscsubsystemtype").combobox('clear');
                    $("#tenantasscnename").combobox('loadData', "");
                    $("#tenantasscsubsystemtype").combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                tenantAsscNeNameList(buldingName, newValue);
            }
        }
    });
    comboboxSearchOnSelect(floorListId);
}

function floorNameListForIPCAM(buldingName, floorListId) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=FloorManager&subRequestType=refreshFloorName&QueryNum=1107&key=FLOOR_NAME&Parm1=" + buldingName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var floorNames = data.rows;
    $("#" + floorListId).combobox({
        data: floorNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(floorListId);
}
function swVerDetNeSubTypeNameList() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshswVersionDetDetails&QueryNum=1508&key=NE_SUB_TYPE_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var neSubTypes = data.rows;
    $('#swverdetnesubtypename').combobox({
        data: neSubTypes,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("swverdetnesubtypename");
}

function swBinaryFileNeSubTypeNameList() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshswVersionDetDetails&QueryNum=1508&key=NE_SUB_TYPE_NAME";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var neSubTypes = data.rows;
    $('#swbinaryfilenesubtypename').combobox({
        data: neSubTypes,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#swbinaryfileapplicableto").combobox('clear');
                    $("#swbinaryfileapplicableto").combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                neVersionsListForSWUploadFile(newValue);
            }
        }
    });
    comboboxSearchOnSelect("swbinaryfilenesubtypename");
}

function swDwldSchdlrFileName() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=SchedulerManagement&subRequestType=refreshSchedulerManagement&QueryNum=1520&key=SOFTWARE_DOWNLOAD_SCHEDULER_DETAILS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var fileNames = data.rows;
    $('#swdwldschdlrfilename').combobox({
        data: fileNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
                var parameters = "requestType=SchedulerManagement&subRequestType=refreshSchedulerManagement&QueryNum=1522&key=SOFTWARE_DOWNLOAD_SCHEDULER_DETAILS&Parm1=" + $('#swdwldschdlrfilename').combobox('getValue');
                var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
                var data = eval('(' + replyFormat + ')');
                updateStatusMessage(data, "");
                var version = data.rows[0].value;
                $('#swdwldschdlrversionid').textbox('setValue', version);
                if ($('#swdwldschdlrnelist').length) {
                    swDwldSchdlrNeList();
                }
            }
        }
    });
    comboboxSearchOnSelect("swdwldschdlrfilename");
}

function swDwldSchdlrNeList() {
    var selFile = $('#swdwldschdlrfilename').combobox('getValue') || -1;
    var URL = $.i18n.prop('SERVER_URL') + "/getSoftwareDownloadNowTree";
    var parameters = "requestType=DownloadNowManager&subRequestType=refreshDownloadNowManager&key=SOFTWARE_DOWNLOAD_NOW&swbinaryfilefilename=" + selFile + "&userName=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    var comboTreeData = JSON.parse(data.treedata.trim());
    $('#swdwldschdlrnelist').combotreegrid({
        cache: false,
        data: comboTreeData,
        treeField: 'text',
        idField: 'text',
        showFooter: true,
        rownumbers: true,
        fitColumns: true,
        disabled: true,
        panelWidth: 500,
        multiple: true,
        unselectAll: true,
        labelPosition: 'top',
        columns: [[
                {field: 'text', title: 'NE Name', width: '60%'},
                {field: 'ipAddress', title: 'Ip Address', width: '20%'},
                {field: 'neVersion', title: 'NE Version', width: '20%'}
            ]],
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("swdwldschdlrnelist");
}

function swdwldSchdlrNemanufactureVersion() {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=SchedulerManagement&subRequestType=refreshSchedulerManagement&QueryNum=1161&key=SOFTWARE_DOWNLOAD_SCHEDULER_DETAILS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var fileNames = data.rows;
    $('#swdwldschdlrnemanufactureversion').combobox({
        data: fileNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: true,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("swdwldschdlrnemanufactureversion");
}

function enableDisableNeTypeCheckbox(defaultRadioBtnId, threshValueId, threshIntervalId) {
    var tableColumn = $('#' + defaultRadioBtnId).parent('td');
    var radioButtonGroup = '<input id="' + defaultRadioBtnId + 'Version" type="radio" name="' + defaultRadioBtnId + '" class="easyui-radio" value="0" checked="checked">Version <input id="' + defaultRadioBtnId + 'List" type="radio" name="' + defaultRadioBtnId + '" class="easyui-radio" value="1">List';
    $(tableColumn).html(radioButtonGroup);
    $("#" + defaultRadioBtnId + "Version").on('click select change', function () {
        if ($(this).is(":checked")) {
            $('#' + threshIntervalId).combotreegrid('disable', true);
            $('#' + threshIntervalId).combotreegrid('required', false);
            $('#' + threshValueId).combobox('enable', true);
            $('#' + threshValueId).combobox('required', true);
        } else {
            $('#' + threshValueId).combobox('disable', true);
            $('#' + threshValueId).combobox('required', false);
            $('#' + threshIntervalId).combotreegrid('enable', true);
            $('#' + threshIntervalId).combotreegrid('required', true);
        }
    });
    $("#" + defaultRadioBtnId + "List").on('click select change', function () {
        if ($(this).is(":checked")) {
            $('#' + threshValueId).combobox('disable', true);
            $('#' + threshValueId).combobox('required', false);
            $('#' + threshIntervalId).combotreegrid('clear');
            $('#' + threshIntervalId).combotreegrid('enable', true);
            $('#' + threshIntervalId).combotreegrid('required', true);
        } else {
            $('#' + threshIntervalId).combotreegrid('disable', true);
            $('#' + threshIntervalId).combotreegrid('required', false);
            $('#' + threshValueId).combobox('enable', true);
            $('#' + threshValueId).combobox('required', true);
        }
    });
}

function priorityList(priorityId) {
    $('#' + priorityId).combobox({
        url: $.i18n.prop('CLIENT_URL') + '/' + $.i18n.prop('SOFTWARE_DOWNLOAD_PRIORITY_URL'),
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        onLoadSuccess: function () {
            var ccpyid = $('#' + priorityId).combobox('getValue');
            var val = $(this).combobox("getData");
            $.each(val, function (i, obj) {
                if (ccpyid === obj.text) {
                    $('#' + priorityId).combobox('setValue', obj.value);
                }
            });
        }
    });
}


function getSubSystemTypesForNEVersion(neVersionNumber) {
    var subSystemTypesArray = [];
    var subSystemTypes = neVersionsWithEntityArray[neVersionNumber];
    if (subSystemTypes !== null && subSystemTypes !== undefined && subSystemTypes !== '') {
        $.each(subSystemTypes.split(","), function (index, value) {
            var comboBoxObj = {};
            comboBoxObj.text = value;
            comboBoxObj.value = value;
            subSystemTypesArray.push(comboBoxObj);
        });
    }
    return subSystemTypesArray;
}

function changeSubSystemIdValidType(subSystemId, neVersionNumber) {
    if (neVersionNumber !== "CAS_001") {
        enableGOAMeterId(subSystemId, neVersionNumber);
    } else {
        enableCASMeterId(subSystemId, neVersionNumber);
    }
}

function enableGOAMeterId(subSystemId, neVersionNumber) {
    var selSubSystemType = $("#subsystemdetltype").combobox('getValue');
    var min = 1;
    var max = 255;
    var options = $("#" + subSystemId).numberspinner('options');
    $.each(neVersionEntityRowData, function (i, neversion) {
        if (neversion.neverentityversionnumber === neVersionNumber) {
            $.each(neversion.neverentitynames.split(","), function (j, subSystemType) {
                if (subSystemType === selSubSystemType) {
                    min = parseInt(neversion.neverentitytypeidstart.split(",")[j]);
                    max = parseInt(neversion.neverentitytypeidend.split(",")[j]);
                }
            });
        }
    });
    options.min = min;
    options.max = max;
    options.onChange = function (newValue, oldValue) {
        if (newValue !== oldValue) {
            $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + newValue);
        }
    };
    options.onSpinUp = function () {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + $(this).val());
    };
    options.onSpinDown = function () {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + $(this).val());
    };
    $("#" + subSystemId).numberspinner(options);
    $("#" + subSystemId).numberspinner('fix');
    var subSystemIdVal = $("#" + subSystemId).numberspinner('getValue');
    if (subSystemIdVal !== null && subSystemIdVal !== "" && subSystemIdVal !== undefined) {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + subSystemIdVal);
    } else {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue'));
    }
    /*var options = $("#" + subSystemId).validatebox('options');
     options.validType = ['goameterid', 'length[1,3]'];
     $("#" + subSystemId).validatebox(options);
     $("#" + subSystemId).textbox(options);
     $("#" + subSystemId).validatebox('validate');
     $("#" + subSystemId).textbox('validate');*/
}

function enableCASMeterId(subSystemId, neVersionNumber) {
    var selSubSystemType = $("#subsystemdetltype").combobox('getValue');
    var min = 1;
    var max = 9999;
    var options = $("#" + subSystemId).numberspinner('options');
    $.each(neVersionEntityRowData, function (i, neversion) {
        if (neversion.neverentityversionnumber === neVersionNumber) {
            $.each(neversion.neverentitynames.split(","), function (j, subSystemType) {
                if (subSystemType === selSubSystemType) {
                    min = parseInt(neversion.neverentitytypeidstart.split(",")[j]);
                    max = parseInt(neversion.neverentitytypeidend.split(",")[j]);
                }
            });
        }
    });
    options.min = min;
    options.max = max;
    options.onChange = function (newValue, oldValue) {
        if (newValue !== oldValue) {
            $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + newValue);
        }
    };
    options.onSpinUp = function () {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + $(this).val());
    };
    options.onSpinDown = function () {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + $(this).val());
    };
    $("#" + subSystemId).numberspinner(options);
    $("#" + subSystemId).numberspinner('fix');
    var subSystemIdVal = $("#" + subSystemId).numberspinner('getValue');
    if (subSystemIdVal !== null && subSystemIdVal !== "" && subSystemIdVal !== undefined) {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue') + "-" + subSystemIdVal);
    } else {
        $("#subsystemdetldisplayname").textbox('setValue', $("#subsystemdetltype").combobox('getValue'));
    }
    /*var options = $("#" + subSystemId).validatebox('options');
     options.validType = ['casmeterid', 'length[1,4]'];
     $("#" + subSystemId).validatebox(options);
     $("#" + subSystemId).textbox(options);
     $("#" + subSystemId).validatebox('validate');
     $("#" + subSystemId).textbox('validate');*/
}

function disableSubSystemInputs(subSystemVerId) {
    try {
        $("#" + subSystemVerId).combobox('clear');
        $("#" + subSystemVerId).combobox('disableValidation');
        $("#" + subSystemVerId).combobox('validate');
    } catch (e) {
//Do Nothing
    }
    try {
        $("#" + subSystemVerId).validatebox('disableValidation');
        $("#" + subSystemVerId).validatebox('validate');
    } catch (e) {
//Do Nothing
    }
    $("#" + subSystemVerId).closest("tr").hide();
}

function enableAndDisableSubSystemInputs(subSystemVerId, subSystemType, neVersionNumber) {
    if (subSystemType === "Water" || subSystemType === "GAS" || subSystemType === "EnvSensor") {
        subSystemVersions(subSystemVerId, subSystemType, neVersionNumber);
        try {
            $("#" + subSystemVerId).combobox('clear');
            $("#" + subSystemVerId).combobox('enableValidation');
            $("#" + subSystemVerId).combobox('validate');
        } catch (e) {
//Do Nothing
        }
        $("#" + subSystemVerId).validatebox('enableValidation');
        $("#" + subSystemVerId).validatebox('validate');
        $("#" + subSystemVerId).closest("tr").show();
    } else {
        disableSubSystemInputs(subSystemVerId);
    }
}

function subSystemVersions(subSystemVerId, subSystemType, neVersionNumber) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshSubSystemVersion&QueryNum=1356&key=SUB_SYSTEM_VERSIONS&Parm1=" + subSystemType;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var subSystemVersionRows = data.rows;
    $("#" + subSystemVerId).combobox({
        data: subSystemVersionRows,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(subSystemVerId);
    if (neVersionNumber !== "CAS_001") {
        disableSubSystemInputs(subSystemVerId);
    }
}

function subsystemTypes(subSystemTypeId, neVersionNumber) {
    var subSystemTypesArray = getSubSystemTypesForNEVersion(neVersionNumber);
    $('#' + subSystemTypeId).combobox({
        data: subSystemTypesArray,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                if (neVersionNumber.indexOf('DATALOGGER') === -1) {
                    enableAndDisableSubSystemInputs("subsystemdetlversionid", newValue, neVersionNumber);
                }
                changeSubSystemIdValidType("subsystemdetlid", neVersionNumber);
            }
        },
        onLoadSuccess: function () {
            var selectedValue = $(this).combobox('getValue');
            if (selectedValue !== null && selectedValue !== "" && selectedValue !== undefined) {
                if (neVersionNumber.indexOf('DATALOGGER') === -1) {
                    enableAndDisableSubSystemInputs("subsystemdetlversionid", selectedValue, neVersionNumber);
                }
                changeSubSystemIdValidType("subsystemdetlid", neVersionNumber);
            }
        }
    });
    comboboxSearchOnSelect(subSystemTypeId);
}

function tenantAsscNeNameList(buildingName, floorName) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshNEName&QueryNum=1166&key=NE_NAME&Parm1=" + buildingName + "&Parm2=" + floorName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var neNames = data.rows;
    $('#tenantasscnename').combobox({
        data: neNames,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#tenantasscsubsystemtype").combobox('clear');
                    $("#tenantasscsubsystemtype").combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                $.each(data.rows, function (index, row) {
                    if (row.value === newValue) {
                        tenantAsscSubSystemTypeList(newValue, row.neversionnumber);
                        //changeSubSystemIdValidType("tenantasscsubsystemid", row.neversionnumber);
                        return false;
                    }
                });
            }
        },
        onLoadSuccess: function () {
            var selectedValue = $(this).combobox('getValue');
            if (selectedValue !== null && selectedValue !== "" && selectedValue !== undefined) {
                try {
                    $("#tenantasscsubsystemtype").combobox('clear');
                    $("#tenantasscsubsystemtype").combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                $.each(data.rows, function (index, row) {
                    if (row.value === selectedValue) {
                        tenantAsscSubSystemTypeList(selectedValue, row.neversionnumber);
                        //changeSubSystemIdValidType("tenantasscsubsystemid", row.neversionnumber);
                        return false;
                    }
                });
            }
        }
    });
    comboboxSearchOnSelect("tenantasscnename");
}

function tenantAsscSubSystemTypeList(neName, neVersion) {
//var subSystemTypes = getSubSystemTypesForNEVersion(neVersion);
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshSubSystemTypes&QueryNum=1358&key=SUBSYSTEM_DETAILS&Parm1=" + neName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var subSystemTypes = data.rows;
    $('#tenantasscsubsystemtype').combobox({
        data: subSystemTypes,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue) {
                try {
                    $("#tenantasscsubsystemid").combobox('clear');
                    $("#tenantasscsubsystemid").combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                //enableAndDisableSubSystemInputs("tenantasscsubsysverid", newValue, neVersion);
                tenantAsscSubSystemIdList(neName, newValue);
            }
        },
        onLoadSuccess: function () {
            var selectedValue = $(this).combobox('getValue');
            if (selectedValue !== null && selectedValue !== "" && selectedValue !== undefined) {
                try {
                    $("#tenantasscsubsystemid").combobox('clear');
                    $("#tenantasscsubsystemid").combobox('loadData', "");
                } catch (e) {
                    //Do Nothing
                }
                //enableAndDisableSubSystemInputs("tenantasscsubsysverid", selectedValue, neVersion);
                tenantAsscSubSystemIdList(neName, selectedValue);
            }
        }
    });
    comboboxSearchOnSelect("tenantasscsubsystemtype");
}

function tenantAsscSubSystemIdList(neName, subSystemType) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=NEManager&subRequestType=refreshSubSystemIds&QueryNum=1359&key=SUBSYSTEM_DETAILS&Parm1=" + neName + "&Parm2=" + subSystemType;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var subSystemIds = data.rows;
    $('#tenantasscsubsystemid').combobox({
        data: subSystemIds,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("tenantasscsubsystemid");
}

function addUnitToInputBox(id, url) {
    $('#' + id).combobox({
        url: url,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: false,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(id);
}

function enableDisableEventCheckbox(defaultRadioBtnId, threshValueId, threshIntervalId) {
    var tableColumn = $('#' + defaultRadioBtnId).parent('td');
    var radioButtonGroup = '<input id="' + defaultRadioBtnId + 'count" type="radio" name="' + defaultRadioBtnId + '" value="0">Count <input id="' + defaultRadioBtnId + 'interval" type="radio" name="' + defaultRadioBtnId + '" value="1">Interval';
    $(tableColumn).html(radioButtonGroup);
    $("#" + defaultRadioBtnId + "count").on('click select change', function () {
        if ($(this).is(":checked")) {
            $('#' + threshIntervalId).numberspinner('disable', true);
            $('#' + threshValueId).numberspinner('enable', true);
        } else {
            $('#' + threshValueId).numberspinner('disable', true);
            $('#' + threshIntervalId).numberspinner('enable', true);
        }
    });
    $("#" + defaultRadioBtnId + "interval").on('click select change', function () {
        if ($(this).is(":checked")) {
            $('#' + threshValueId).numberspinner('disable', true);
            $('#' + threshIntervalId).numberspinner('enable', true);
        } else {
            $('#' + threshIntervalId).numberspinner('disable', true);
            $('#' + threshValueId).numberspinner('enable', true);
        }
    });
}

function triggerRadioButtonGroupChange(defaultRadioBtnId, currentValue) {
    if ($("#" + defaultRadioBtnId + "count").length && $("#" + defaultRadioBtnId + "interval").length) {
        if (currentValue === 0 || currentValue === "0") {
            $("#" + defaultRadioBtnId + "count").trigger('click');
        } else if (currentValue === 1 || currentValue === "1") {
            $("#" + defaultRadioBtnId + "interval").trigger('click');
        } else {
            $("#" + defaultRadioBtnId + "count").trigger('click');
        }
    }
}

function neVersionsListForSWUploadFile() {
    $("#swupldfileupgradeover").combobox({
        data: neVersionsRowData,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: true,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("swupldfileupgradeover");
    $("#swupldfileupgradeover").prop("name", "swupldfileupgradeover[]");
    $("#swupldfileupgradeover").attr("name", "swupldfileupgradeover[]");
}

function neVersionsListForSWUploadFile(neSubTypeName) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
    var parameters = "requestType=GroupManager&subRequestType=refreshGroupName&QueryNum=1519&key=SOFTWARE_VERSION_DETAILS&Parm1=" + neSubTypeName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    var softwareVersion = data.rows;
    updateStatusMessage(data, "");
    $("#swbinaryfileapplicableto").combobox({
        data: softwareVersion,
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: true,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("swbinaryfileapplicableto");
}

function loadSNMPAgentVersion(agentVersionId) {
    $('#' + agentVersionId).combobox({
        url: $.i18n.prop('CLIENT_URL') + "/" + $.i18n.prop('AGENT_SNMP_VERSION_URL'),
        valueField: 'value',
        textField: 'text',
        cache: false,
        required: true,
        multiple: false,
        editable: false,
        selectOnNavigation: true
    });
    comboboxSearchOnSelect(agentVersionId);
}

function addDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    var row;
    var parentRow;
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        parentRow = $('#' + parentTableId).datagrid('getSelected');
        if (!parentRow) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    requestParams += "&operationDoneBy=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var parameters = $.deserialize(requestParams);
    var columnFields = data.column;
    var dialogContent;
    if (URL.indexOf('addSoftwareUploadFile') !== -1) {
        dialogContent = '<form id="popUpDialogForm" class="popUpDialogForm" method="post" autocomplete="off" enctype="multipart/form-data"><table>';
    }
    else if (URL.indexOf('addSoftwareBinaryFile') !== -1) {
        dialogContent = '<form id="popUpDialogForm" class="popUpDialogForm" method="post" autocomplete="off" enctype="multipart/form-data"><table>';
    } else {
        dialogContent = '<form id="popUpDialogForm" class="popUpDialogForm" method="post" autocomplete="off"><table>';
    }
    var editableCount = 0;
    for (var i = 0; i < columnFields.length; i++) {
        $.each(columnFields[i], function (index, data) {
            if (data.editable) {
                editableCount++;
            }
        });
    }
    var colSpanCnt = 0;
    for (var j = 0; j < columnFields.length; j++) {
        $.each(columnFields[j], function (index, data) {
            if (data.editable) {
                if (editableCount > 12) {
                    if (colSpanCnt % 2 === 0) {
                        dialogContent += '<tr>';
                    }
                } else {
                    dialogContent += '<tr>';
                }
                dialogContent += '<th>' + data.title + '</th>' + '<td>';
                dialogContent += generateElementBasedOnType(data, disabledKey, clearChildTables);
                dialogContent += '</td>';
                if (editableCount > 12) {
                    if (colSpanCnt % 2 === 1) {
                        dialogContent += '</tr>';
                    }
                    colSpanCnt++;
                } else {
                    dialogContent += '</tr>';
                }
            }
        });
    }
    dialogContent += '</table></form>';
    $("#popUpDialog").empty().append(dialogContent);
    row = $('#' + datagridId).datagrid('getSelected');
   console.log("Row for "+row);
    var widthLimit = 450;
    if (editableCount > 12) {
        widthLimit = 650;
    }
    $('#popUpDialog').dialog({
        cache: false,
        shadow: false,
        model: true,
        width: widthLimit,
        height: 'auto',
        title: title,
        resizable: false,
        buttons: [{
                text: label,
                iconCls: iconClass,
                handler: function () {
                    var okBtn = $(this);
                    $("#" + parentId).block();
                    $('#popUpDialogForm').form('submit', {
                        url: URL,
                        onSubmit: function (param) {
                            var isValid = $('#popUpDialogForm').form('validate');
                            if (isValid) {
                                $(okBtn).linkbutton('disable');
                                if (parameters) {
                                    $.each(parameters, function (key, value) {
                                        if (key !== null && key !== '' && key !== undefined) {
                                            param[key] = value;
                                        }
                                    });
                                }
                                $("#popUpDialogForm input:checkbox").each(function () {
                                    if ($(this).prop('checked') === true) {
                                        $(this).val('1');
                                        param[$(this).attr('name')] = 1;
                                    } else {
                                        $(this).val('0');
                                        param[$(this).attr('name')] = 0;
                                    }
                                });
                                $("#popUpDialogForm input:disabled").each(function () {
                                    var key = $(this).attr('name');
                                    if (key !== null && key !== '' && key !== undefined) {
                                        param[key] = $(this).val();
                                    }
                                });
                                $("#popUpDialogForm div.c-cron span.cron-span").each(function () {
                                    var key = $(this).attr('name');
                                    param[key] = $("[name='" + key + "']").text();
                                });
                                if (disabledParam !== null && disabledParam !== undefined && disabledParam !== '' && disabledParam !== "null") {
                                    $.each(disabledParam.split(","), function (index, item) {
                                        //var disabledParamKey = item.replace(/disabledKey/g, '').trim();
                                        var disabledParamKey = $("#" + disabledKey + item).attr('name') || $("#" + item).attr('name');
                                        var disabledParamVal = $("#" + disabledKey + item).val() || $("#" + item).val();
                                        if (disabledParamKey !== null && disabledParamKey !== "" && disabledParamKey !== undefined && disabledParamVal !== null && disabledParamVal !== "" && disabledParamVal !== undefined) {
                                            param[disabledParamKey] = disabledParamVal;
                                        }
                                    });
                                }
                                if (label === "Update" || label === "Copy") {
                                    if (duplicateParam !== null && duplicateParam !== undefined && duplicateParam !== '' && duplicateParam !== "null") {
                                        $.each(duplicateParam.split(","), function (index, item) {
                                            if (row) {
                                                param["old" + item] = row[item];
                                            }
                                        });
                                    }
                                }
                                if (label === "Copy") {
                                    if ($("#userdetoprtypename").length) {
                                        param.userdetoprtypename = row.userdetoprtypename;
                                    }
                                }
                            } else {
                                $("#" + parentId).unblock();
                            }
                            return isValid;
                        },
                        success: function (data) {
                            if (refreshParams.subRequestType === "refreshAgent") {
                                var pager = $('#' + parentTableId).datagrid('getPager');
                                pager.pagination('options').onBeforeRefresh();
                            } else {
                                reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                            }
                            $('#popUpDialog').dialog('close');
                            var replyFormat = eval('(' + data + ')');
                            updateStatusMessage(replyFormat, datagridId);
                            $("#" + parentId).unblock();
                            //reloadTree();
                        },
                        onLoadError: function () {
                            $('#popUpDialog').dialog('close');
                            $("#" + parentId).unblock();
                        }
                    });
                }
            }, {
                text: 'Close',
                iconCls: 'icon-cancel',
                handler: function () {
                    $('#popUpDialog').dialog('close');
                }
            }]
    });
    $('#popUpDialog').dialog('open');
    $('#popUpDialog').dialog('center');
    /* if (label === "Update") {
     if (disabledParam !== null && disabledParam !== undefined && disabledParam !== '' && disabledParam !== "null") {
     $.each(disabledParam.split(","), function (index, item) {
     $("#" + item).attr("disabled", "disabled");
     });
     }
     } */
    $('#popUpDialogForm').find('input, textarea').each(function (i, field) {
        var elementId = field.id;
        var dataOptions;
        var dataOptionObj = {};
        if (!$('#' + elementId).prop('disabled') === true) {
            if ($('#' + elementId).hasClass("easyui-numberbox")) {
                $('#' + elementId).numberbox();
            } else if ($('#' + elementId).hasClass("easyui-datebox")) {
                dataOptions = $('#' + elementId).attr('data-options');
                dataOptionObj = {};
                $('#' + elementId).removeAttr('data-options');
                $.each(dataOptions.split(","), function (index, item) {
                    dataOptionObj[item.split(":")[0]] = item.split(":")[1];
                });
                $('#' + elementId).datebox(dataOptionObj);
//            } else if ($('#' + elementId).hasClass("easyui-datetimebox")) {
//                dataOptions = $('#' + elementId).attr('data-options');
//                dataOptionObj = {};
//                $('#' + elementId).removeAttr('data-options');
//                $.each(dataOptions.split(","), function (index, item) {
//                    dataOptionObj[item.split(":")[0]] = item.split(":")[1];
//                });
//                $('#' + elementId).datetimebox(dataOptionObj);
            } else if ($('#' + elementId).hasClass("easyui-datetimebox")) {
                $('#' + elementId).datetimebox({
                    editable: false
                });
            } else if ($('#' + elementId).hasClass("easyui-timespinner")) {
                $('#' + elementId).timespinner();
            } else if ($('#' + elementId).hasClass("easyui-numberspinner")) {
                $('#' + elementId).numberspinner();
            } else if ($('#' + elementId).hasClass("spinner")) {
                $('#' + elementId).spinner();
            } else if ($('#' + elementId).hasClass("easyui-textbox")) {
                $('#' + elementId).textbox();
            } else if ($('#' + elementId).hasClass("easyui-passwordbox")) {
                if (label === "Update") {
                    $('#' + elementId).passwordbox({
                        showEye: false
                    });
                } else {
                    $('#' + elementId).passwordbox();
                }
            } else if ($('#' + elementId).hasClass("easyui-filebox")) {
                if (disabledParam.indexOf(elementId) > -1 && label === "Update") {
                    $('#' + elementId).removeClass('easyui-filebox').addClass('easyui-textbox');
                    $('#' + elementId).textbox();
                } else {
                    $('#' + elementId).filebox();
                }
            } else if ($('#' + elementId).hasClass("c-cron")) {
                var cronExpression = "* * * * * ?";
                if (row) {
                    cronExpression = row[elementId];
                }
                $('#' + elementId).jqCron({
                    enabled_minute: false,
                    multiple_dom: true,
                    multiple_month: true,
                    multiple_mins: true,
                    multiple_dow: true,
                    multiple_time_hours: true,
                    multiple_time_minutes: true,
                    default_period: 'day',
                    default_value: cronExpression.substr(2).replace(/\?/g, "*"),
                    no_reset_button: false,
                    numeric_zero_pad: true,
                    lang: 'en', bind_to: $('.cron-span'),
                    bind_method: {
                        set: function ($element, value) {
                            $element.html(value);
                        }
                    }
                });
            }
            if (disabledParam.indexOf(elementId) > -1) {
                addValidationToElement(elementId);
            }
        }
    });
    if ($('#buldgroupname').length) {
        groupNameList();
    }
    if ($('#nebuldname').length) {
        buildingNameListForNE("nebuldname", "nefloorname");
    }
    if ($('#nefloorname').length) {
        var selectedNEFloorName = "None";
        if (row) {
            selectedNEFloorName = row.nebuldname;
        }
        floorNameListForNE(selectedNEFloorName, "nefloorname");
    }
    if ($('#nesubtypename').length) {
        neSubTypesList(datagridId, 'nesubtypename', 'neversionnumber');
    }
    if ($('#neversionnumber').length) {
        var selectedNESubTypeName = "None";
        if (row) {
            selectedNESubTypeName = row.nesubtypename;
        }
        neVersionsList(selectedNESubTypeName, 'neversionnumber');
    }
    if ($('#agentversion').length) {
        loadSNMPAgentVersion('agentversion');
    }
    if ($('#userdetpassword').length) {
        passwordValidation(row, label);
    }
    if ($('#userdetoprtypename').length) {
        operatorTypesList("userdetoprtypename");
    }
    if ($('#profileneversionnumber').length) {
        neVersionsListForProfile();
    }
    if ($('#profileoprtypename').length) {
        operatorTypesList("profileoprtypename");
    }
    if ($('#tenantasscbuldname').length) {
        buildingNameListForTenant("tenantasscbuldname", "tenantasscfloorname");
    }
    if ($('#tenantasscfloorname').length) {
        var selTenantAsscBuildingName = "None";
        if (row) {
            selTenantAsscBuildingName = row.tenantasscbuldname;
        }
        floorNameListForTenant(selTenantAsscBuildingName, "tenantasscfloorname");
    }
    if ($('#tenantasscnename').length) {
        var selectedTenantAsscFloorName = "None";
        var selectedTenantAsscBuildingName = "None";
        if (row) {
            selectedTenantAsscFloorName = row.tenantasscfloorname;
            selectedTenantAsscBuildingName = row.tenantasscbuldname;
        }
        tenantAsscNeNameList(selectedTenantAsscBuildingName, selectedTenantAsscFloorName);
    }
    if ($('#tenantasscsubsystemtype').length) {
        try {
            $('#tenantasscsubsystemtype').combobox('getValue');
        } catch (e) {
            tenantAsscSubSystemTypeList("None", "None");
        }
    }
    if ($('#tenantasscsubsysverid').length) {
        var selectedSubSystemType = "None";
        if (row) {
            selectedSubSystemType = row.tenantasscsubsystemtype;
        }
        subSystemVersions("tenantasscsubsysverid", selectedSubSystemType, "None");
    }
    if ($('#tenantasscsubsystemid').length) {
        try {
            $('#tenantasscsubsystemid').combobox('getValue');
        } catch (e) {
            tenantAsscSubSystemIdList("None", "None");
        }
    }
    if ($('#subsystemdetltype').length) {
        var neVersionNumber = "None";
        if (parentRow) {
            neVersionNumber = parentRow.neversionnumber;
        }
        subsystemTypes("subsystemdetltype", neVersionNumber);
    }
    var selNeVersion = $("#selneversionnumber").val() || "None";
    if ($('#subsystemdetlversionid').length) {
        var selSubSystemType = "None";
        if (row) {
            selSubSystemType = row.subsystemdetltype;
        }
        subSystemVersions("subsystemdetlversionid", selSubSystemType, selNeVersion);
    }
    if ($('#subsystemdetlid').length) {
        changeSubSystemIdValidType("subsystemdetlid", selNeVersion);
    }
    if ($('#subsystemdetladminstate').length) {
        $('#subsystemdetladminstate').prop('checked', true);
        $('#subsystemdetladminstate').attr('checked', true);
    }

    if ($('#ipcambuldname').length) {
        buildingNameListForIPCAM("ipcambuldname", "ipcamfloorname");
    }
    if ($('#ipcamfloorname').length) {
        var selectedIPCAMBuildingName = "None";
        if (row) {
            selectedIPCAMBuildingName = row.ipcambuldname;
        }
        floorNameListForIPCAM(selectedIPCAMBuildingName, "ipcamfloorname");
    }

    if ($('#devcdetcapacity').length) {
        $('#devcdetcapacity').parent("td").parent("tr").attr('colspan', 2);
        $('#devcdetcapacity').parent("td").parent("tr").append("<td><input id='devcdetcapacityunit' name='devcdetcapacityunit' type='text' style='width:35%'/></td>");
        var deviceCapacityUnitURL = $.i18n.prop('CLIENT_URL') + '/' + $.i18n.prop('INVERTER_UNITS_URL');
        addUnitToInputBox("devcdetcapacityunit", deviceCapacityUnitURL);
    }

    if ($('#eventthreshtype').length) {
        enableDisableEventCheckbox('eventthreshtype', 'eventdetlthreshvalue', 'eventdetlthreshinterval');
    }

    if ($('#nesubtypeeventthreshtype').length) {
        enableDisableEventCheckbox('nesubtypeeventthreshtype', 'nesubtypeeventdetlthreshvalue', 'nesubtypeeventdetlthreshinterval');
    }

    if ($('#agenteventthreshtype').length) {
        enableDisableEventCheckbox('agenteventthreshtype', 'agenteventdetlthreshvalue', 'agenteventdetlthreshinterval');
    }

    if ($('#subsystemeventthreshtype').length) {
        enableDisableEventCheckbox('subsystemeventthreshtype', 'subsystemeventdetlthreshvalue', 'subsystemeventdetlthreshinterval');
    }

    if ($('#swupldfileupgradeover').length) {
        neVersionsListForSWUploadFile();
    }
    if ($('#parentne').length) { //M eter Parent NE (Which includes Meter chil d  NE,MeterParentSubSystem & Meter Child SubSystem)
        parentNeNameListForMeterAssociation("parentne", "parentsubsystem", "childne", "childsubsystem");
    }
    if ($('#type').length) { // Meter Type
        typeNameListForMeterAssociation("type");
    }
    if ($('#swverdetnesubtypename').length) {
        swVerDetNeSubTypeNameList();
    }

    if ($('#swbinaryfilenesubtypename').length) {
        swBinaryFileNeSubTypeNameList();
    }

    if ($('#swdwldschdlrfilename').length) {
        swDwldSchdlrFileName();
    }
    if ($('#swdwldschdlrnemanufactureversion').length) {
        swdwldSchdlrNemanufactureVersion();
    }

    if ($('#swdwldschdlrnelist').length) {
        swDwldSchdlrNeList();
    }
    if ($('#swdwldschdlrnetype').length) {
        enableDisableNeTypeCheckbox('swdwldschdlrnetype', 'swdwldschdlrnemanufactureversion', 'swdwldschdlrnelist');
    }

    if ($('#swdwldschdlrpriority').length) {
        priorityList("swdwldschdlrpriority");
    }

//    if ($('#' + elementId).length) {
//
//        comboboxLoadForTemplate("" + elementId);
//    }
    if (row) {
//        var rowIndex = $("#" + datagridId).datagrid('getRowIndex', row);
        //        $.each(row, function (fieldName, fieldValue) {
        //            var col = $("#" + datagridId).datagrid('getColumnOption', fieldName);
        //            var formattedValue = (col && col.formatter) ? col.formatter(row[fieldName], row, rowIndex) : fieldValue;
        //            row[fieldName] = formattedValue;
        //        });
        $('#popUpDialogForm').form('load', row);
        if ($('#eventthreshtypecount').length && $('#eventthreshtypeinterval').length) {
            triggerRadioButtonGroupChange('eventthreshtype', row.eventthreshtype);
        }
        if ($('#nesubtypeeventthreshtypecount').length && $('#nesubtypeeventthreshtypeinterval').length) {
            triggerRadioButtonGroupChange('nesubtypeeventthreshtype', row.nesubtypeeventthreshtype);
        }
        if ($('#agenteventthreshtypecount').length && $('#agenteventthreshtypeinterval').length) {
            triggerRadioButtonGroupChange('agenteventthreshtype', row.agenteventthreshtype);
        }
        if ($('#subsystemeventthreshtypecount').length && $('#subsystemeventthreshtypeinterval').length) {
            triggerRadioButtonGroupChange('subsystemeventthreshtype', row.subsystemeventthreshtype);
        }
    }
    if (label === "Add") {
        $("#popUpDialogForm input:checkbox").each(function () {
            $(this).prop('checked', true);
            $(this).attr('checked', true);
        });
        if ($('#swupldfilefilename').length) {
            $('#swupldfilefilename').prop('accept', ".bin");
            $('#swupldfilefilename').attr('accept', ".bin");
        }
    } else if (label === "Update") {
        var options;
        if (disabledParam !== null && disabledParam !== undefined && disabledParam !== '' && disabledParam !== "null") {
            $.each(disabledParam.split(","), function (index, elementId) {
                $('#' + elementId).validatebox({novalidate: true
                });
                if ($('#' + elementId).hasClass("easyui-numberbox")) {
                    options = $('#' + elementId).numberbox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).numberbox(options);
                } else if ($('#' + elementId).hasClass("easyui-datebox")) {
                    options = $('#' + elementId).datebox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).datebox(options);
                } else if ($('#' + elementId).hasClass("easyui-datetimebox")) {
                    options = $('#' + elementId).datetimebox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).datetimebox(options);
                } else if ($('#' + elementId).hasClass("easyui-timespinner")) {
                    options = $('#' + elementId).timespinner('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).timespinner(options);
                } else if ($('#' + elementId).hasClass("easyui-numberspinner")) {
                    options = $('#' + elementId).numberspinner('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).numberspinner(options);
                } else if ($('#' + elementId).hasClass("spinner")) {
                    options = $('#' + elementId).spinner('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).spinner(options);
                } else if ($('#' + elementId).hasClass("easyui-textbox")) {
                    options = $('#' + elementId).textbox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).textbox(options);
                } else if ($('#' + elementId).hasClass("easyui-combobox")) {
                    options = $('#' + elementId).combobox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).combobox(options);
                } else if ($('#' + elementId).hasClass("easyui-passwordbox")) {
                    options = $('#' + elementId).passwordbox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).passwordbox(options);
                } else if ($('#' + elementId).hasClass("easyui-filebox")) {
                    options = $('#' + elementId).filebox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).filebox(options);
                }
                else if ($('#' + elementId).hasClass("easyui-radio")) {
                    $('#' + elementId).attr("disabled", true);
                }
                else if ($('#' + elementId).hasClass("combotreegrid-f")) {
                    options = $('#' + elementId).combotreegrid('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).combotreegrid(options);
                } else if ($('#' + elementId).hasClass("combobox-f")) {
                    options = $('#' + elementId).combobox('options');
                    options.disabled = true;
                    options.required = false;
                    $('#' + elementId).combobox(options);
                } else if ($('#' + elementId).hasClass("c-cron")) {
                    var cronExpression = "* * * * * ?";
                    if (row) {
                        cronExpression = row[elementId];
                    }
                    $('#' + elementId).jqCron({
                        enabled_minute: false,
                        multiple_dom: true,
                        multiple_month: true,
                        multiple_mins: true,
                        multiple_dow: true,
                        multiple_time_hours: true,
                        multiple_time_minutes: true,
                        default_period: 'day',
                        default_value: cronExpression.substr(2).replace(/\?/g, "*"),
                        no_reset_button: false,
                        numeric_zero_pad: true,
                        lang: 'en',
                        bind_to: $('.cron-span'),
                        bind_method: {
                            set: function ($element, value) {
                                $element.html(value);
                            }
                        }
                    });
                }
            });
        }
        if ($('#swupldfilefilename').length) {
            var value = $('#swupldfilefilename').textbox('getValue');
            $('#swupldfilefilename').textbox('setValue', value.split("/").pop());
        }
        if ($('#swbinaryfilefilename').length) {
            var value = $('#swbinaryfilefilename').textbox('getValue');
            $('#swbinaryfilefilename').textbox('setValue', value.split("/").pop());
        }
        if ($('#swdwldschdlrfilename').length) {
            $('#swdwldschdlrfilename').combobox('setValue', row.swdwldschdlrfilename);
        }

        if (row.swdwldschdlrattribute) {
            var value = row.swdwldschdlrattribute;
            if (value.indexOf($.i18n.prop('SCHEDULER_KEY_FOR_NEVERSION_LIST')) > -1) {
                var replaceKey = $.i18n.prop('SCHEDULER_KEY_FOR_NEVERSION_LIST') + "=";
                $('#swdwldschdlrnetypeVersion').attr('checked', true);
                $('input[name=swdwldschdlrnetype]').val(0);
                $("#swdwldschdlrnemanufactureversion").combobox("setValues", value.replace(replaceKey, ""));
            } else if (value.indexOf($.i18n.prop('SCHEDULER_KEY_FOR_NE_LIST')) > -1) {
                var replaceKey = $.i18n.prop('SCHEDULER_KEY_FOR_NE_LIST') + "=";
                $('#swdwldschdlrnetypeList').attr('checked', true);
                $('input[name=swdwldschdlrnetype]').val(1);
                $("#swdwldschdlrnelist").combotreegrid("setValues", value.replace(replaceKey, ""));
            }
        }
    }

    if (label === "Copy") {
        if ($("#userdetloginname").length) {
            $("#userdetloginname").textbox('clear');
            $("#userdetpassword").textbox('clear');
            $("#userdetconfirmpassword").textbox('clear');
            $("#userdetoprtypename").combobox('disable', true);
        }
        if ($("#ipcamname").length) {
            $("#ipcamname").textbox('clear');
            $("#ipcamshortname").textbox('clear');
            $("#ipcamurl").textbox('clear');
            //$("#ipcamip").textbox('clear');
            //$("#ipcamport").numberspinner('clear');
        }

        if ($("#profilename").length) {
            $("#profilename").textbox('clear');
            $('#profileneversionnumber').combobox('readonly', true);
            $('#profileoprtypename').combobox('readonly', true);
        }
    }
    $('#popUpDialog form:not(.filter) :input:visible:first').focus();
    $('#popUpDialogForm').form('validate');
}

function updateDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    var row;
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        addDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
    } else {
        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('EDIT_ROW_MSG'), 'info');
    }
}

function copyDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    var row;
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        addDataToServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
    } else {
        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('COPY_ROW_MSG'), 'info');
    }
}

function deleteDataFromServer(parentId, datagridId, refreshURL, refreshParams, URL, requestParams, deleteType, title, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    var row;
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    requestParams += "&operationDoneBy=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        $.messager.confirm($.i18n.prop('CONFIRM_TITLE'), $.i18n.prop('DELETE_MSG') + " " + deleteType, function (r) {
            if (r) {
                $("#" + parentId).block();
                var parameters = requestParams + "&" + $.param(row);
                if (disabledParam !== null && disabledParam !== undefined && disabledParam !== '' && disabledParam !== "null") {
                    $.each(disabledParam.split(","), function (index, item) {
                        var disabledParamKey = $("#" + item).attr('name') || $("#" + disabledKey + item).attr('name');
                        var disabledParamVal = $("#" + item).val() || $("#" + disabledKey + item).val();
                        if (disabledParamKey !== null && disabledParamKey !== "" && disabledParamKey !== undefined && disabledParamVal !== null && disabledParamVal !== "" && disabledParamVal !== undefined) {
                            parameters += "&" + disabledParamKey + "=" + disabledParamVal;
                        }
                        //parameters += "&" + item + "=" + $("#" + item).val();
                    });
                }
                var params = $.deserialize(parameters);
                if (row.swupldfilefilename !== null && row.swupldfilefilename !== "" && row.swupldfilefilename !== undefined) {
                    params.swupldfilefilename = row.swupldfilefilename.split("/").pop();
                }
                if (params.subsystemdetlversionid !== null && params.subsystemdetlversionid !== "" && params.subsystemdetlversionid !== undefined) {
                    params.subsystemdetlversionid = " ";
                }
                if (row.swbinaryfilefilename !== null && row.swbinaryfilefilename !== "" && row.swbinaryfilefilename !== undefined) {
                    params.swbinaryfilefilename = row.swbinaryfilefilename.split("/").pop();
                }
                var replyFormat = getDataFromServer("POST", URL, params, "text");
                var delStatus = eval('(' + replyFormat + ')');
                if (refreshParams.subRequestType === "refreshAgent") {
                    var pager = $('#' + parentTableId).datagrid('getPager');
                    pager.pagination('options').onBeforeRefresh();
                } else {
                    reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                }
                updateStatusMessage(delStatus, datagridId);
                $("#" + parentId).unblock();
                //reloadTree();
            }
        });
    } else {
        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('DELETE_ROW_MSG'), 'info');
    }
}

function abortDataToServer(parentId, datagridId, refreshURL, refreshParams, URL, requestParams, deleteType, title, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, deviceAttributes) {
    var row;
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    requestParams += "&operationDoneBy=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    row = $('#' + datagridId).datagrid('getSelected');
    if (row) {
        console.log("scheduler Status "+row.tempschdlrstatus);
        if ((datagridId === "templateSchdulrDetlsList" && row.tempschdlrstatus !== 2)) {
           
            $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('NON_ABORT_MSG'), 'info');
            console.log("this is if ");
        } else {
            console.log("this is else");
            $.messager.prompt($.i18n.prop('CONFIRM_TITLE'), $.i18n.prop('ABORT_MSG') + " " + deleteType, function (r) {
                if (r) {
                    var parameters = requestParams + "&" + $.param(row);
                    if (disabledParam !== null && disabledParam !== undefined && disabledParam !== '' && disabledParam !== "null") {
                        $.each(disabledParam.split(","), function (index, item) {
                            var disabledParamKey = $("#" + item).attr('name') || $("#" + disabledKey + item).attr('name');
                            var disabledParamVal = $("#" + item).val() || $("#" + disabledKey + item).val();
                            if (disabledParamKey !== null && disabledParamKey !== "" && disabledParamKey !== undefined && disabledParamVal !== null && disabledParamVal !== "" && disabledParamVal !== undefined) {
                                parameters += "&" + disabledParamKey + "=" + disabledParamVal;
                            }
                        });
                    }
                    parameters += "&abortmessage=" + r;
                    console.log("parameters",parameters);
                    var params = $.deserialize(parameters);
                    var replyFormat = getDataFromServer("POST", URL, params, "text");
                    var delStatus = eval('(' + replyFormat + ')');
                    if (refreshParams.subRequestType === "refreshAgent") {
                        var pager = $('#' + parentTableId).datagrid('getPager');
                        pager.pagination('options').onBeforeRefresh();
                    } else {
                        reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title, deviceAttributes);
                    }
                    updateStatusMessage(delStatus, datagridId);
                }
            });
        }
    } else {
        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('ABORT_ROW_MSG'), 'info');
    }
}

function reloadDataFromServer(parentId, datagridId, URL, requestParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title) {
    $("#" + parentId).unblock().block();
    var selected = $('#' + datagridId).datagrid('getSelected');
    var rowCount = $('#' + datagridId).datagrid('getRows').length;
    $('#' + datagridId).datagrid('clearChecked');
    var pager = $('#' + datagridId).datagrid('getPager');
    $(pager).find('a.l-btn').each(function () {
        $(this).tooltip('destroy');
    });
    var emptyData = {
        total: 0,
        rows: []
    };
    if (clearChildTables !== '' && clearChildTables !== null && clearChildTables !== undefined && clearChildTables !== "null") {
        $.each(clearChildTables.split(","), function (index, item) {
            try {
                if ($('#' + item).length) {
                    $('#' + item).datagrid('loadData', emptyData);
                    $('#' + item).datagrid('clearSelections');
                    $('#' + item).datagrid('clearChecked');
                }
            } catch (err) {
                try {
                    if ($('#' + item).length) {
                        $('#' + item).form('clear');
                    }
                } catch (e) {
//Do Nothing
                }
            }
        });
    }
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            $("#" + parentId).unblock();
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    var parameters = addAddtReqParamToReqParam(requestParams, additionalReqParams);
    var jsonData = getDataFromServer("POST", URL, parameters, "text");
    //jsonData = $.trim(jsonData).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');     jsonData = $.trim(jsonData).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/"\\"/g, '"').replace(/\\""/g, '"').replace(/"checkBoxFormatter"/g, "checkBoxFormatter").replace(/"UserNEPrivileges"/g, "UserNEPrivileges").replace(/"UserDefaultNEPrivileges"/g, "UserDefaultNEPrivileges").replace(/"mapKeyValues"/g, "mapKeyValues").replace(/"swUpldFileFileName"/g, "swUpldFileFileName").replace(/"hoursFormatter"/g, "hoursFormatter").replace(/"swdwldFileFileName"/g, "swdwldFileFileName");
    var data = eval('(' + jsonData + ')');
    var rowWithTotal = {};
    rowWithTotal.total = data.total;
    rowWithTotal.rows = data.rows;
    var selectedRowIndex = -1;
    if (selected) {
        selectedRowIndex = $('#' + datagridId).datagrid('getRowIndex', selected);
    }
    if (Number(data.total) > 0 && Number(rowCount) <= 0) {
        reloadWithFilter(parentId, datagridId, true, data);
    } else {
        $('#' + datagridId).datagrid('loadData', rowWithTotal);
    }
    if (Number(data.total) <= 0) {
        $('#' + datagridId).datagrid('clearSelections');
        reloadWithFilter(parentId, datagridId, true, data);
    }
    if (selected && selectedRowIndex > -1 && Number(data.total) > 0 && Number(rowCount) > 0) {
        if (title === "Delete") {
            $('#' + datagridId).datagrid('clearSelections');
        } else if (title === "Add" || title === "Update") {
            $('#' + datagridId).datagrid('selectRow', selectedRowIndex);
            $('#' + datagridId).datagrid('highlightRow', selectedRowIndex);
        }
    }
    if (title === "Delete") {
        if (Number(rowCount) === 1) {
            $('#' + datagridId).datagrid('clearSelections');
            $('#' + datagridId).datagrid('getPager').pagination('select');
        }
    }
    updateStatusMessage(data, datagridId);
    setOtherDataGridOptions(datagridId);
    setTimeout(function () {
        $("#" + parentId).unblock();
    }, 0);
}

function saveDataAtServer(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    var row, rows, replyData, defaultProfileName, selectedProfileName, replyFormat, i, j, rowIndex;
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    var parameters = $.deserialize(requestParams);
    if (datagridId === "userProfileList") {
        parameters.oldprofilename = "None";
        row = $('#' + datagridId).datagrid('getSelected');
        if (row) {
            defaultProfileName = row.profilename;
            selectedProfileName = $("#seluserprofilename").val();
            if (defaultProfileName !== selectedProfileName) {
                $("#" + parentId).block();
                parameters.oldprofilename = defaultProfileName;
                parameters.userdetloginname = $("#seluserdetloginname").val();
                parameters.profilename = selectedProfileName;
                parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                replyData = getDataFromServer("POST", URL, parameters, "text");
                reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                replyFormat = eval('(' + replyData + ')');
                updateStatusMessage(replyFormat, datagridId);
                $("#" + parentId).unblock();
            } else {
                $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
                return;
            }
        } else {
            $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
            return;
        }
    } else if (datagridId === "profileAppsList") {
        var appsinprofreadaccess = [];
        var appsinprofwriteaccess = [];
        var neappmgrid = [];
        rows = $('#' + datagridId).datagrid('getChecked');
        if (rows.length > 0) {
            $("#" + parentId).block();
            for (i = 0; i < rows.length; i++) {
                row = rows[i];
                rowIndex = $('#' + datagridId).datagrid('getRowIndex', row);
                appsinprofreadaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=appsinprofreadaccess] input:checkbox").val());
                appsinprofwriteaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=appsinprofwriteaccess] input:checkbox").val());
                neappmgrid.push(row.neappmgrid);
            }
            parameters.appsinprofreadaccess = appsinprofreadaccess.toString();
            parameters.appsinprofwriteaccess = appsinprofwriteaccess.toString();
            parameters.neappid = neappmgrid.toString();
            parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
            parameters.profilename = $("#selprofilename").val();
            replyData = getDataFromServer("POST", URL, parameters, "text");
            reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
            replyFormat = eval('(' + replyData + ')');
            updateStatusMessage(replyFormat, datagridId);
            $("#" + parentId).unblock();
        } else {
            $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('CHECK_MSG'), 'info');
            return;
        }
    } else if (datagridId === "userDefaultNePrivilegesList") {
        parameters.oldprofilename = "None";
        row = $('#' + datagridId).datagrid('getSelected');
        if (row) {
            defaultProfileName = row.profilename;
            selectedProfileName = $("#seluserdefneprvprofilename").val();
            if (selectedProfileName !== null && selectedProfileName !== undefined && selectedProfileName !== '' && selectedProfileName !== "null") {
                if (defaultProfileName !== selectedProfileName) {
                    $("#" + parentId).block();
                    parameters.oldprofilename = defaultProfileName;
                    parameters.userdetloginname = $("#seluserdetloginname").val();
                    parameters.profilename = selectedProfileName;
                    parameters.neversionnumber = row.neversionnumber;
                    parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                    replyData = getDataFromServer("POST", URL, parameters, "text");
                    reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                    replyFormat = eval('(' + replyData + ')');
                    updateStatusMessage(replyFormat, datagridId);
                    $("#" + parentId).unblock();
                } else {
                    $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
                    return;
                }
            } else {
                $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
                return;
            }
        } else {
            $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
            return;
        }
    } else if (datagridId === "userNePrivilegesList") {
        parameters.oldprofilename = "None";
        row = $('#' + datagridId).datagrid('getSelected');
        if (row) {
            defaultProfileName = row.profilename;
            selectedProfileName = $("#seluserneprvprofilename").val();
            if (selectedProfileName !== null && selectedProfileName !== undefined && selectedProfileName !== '' && selectedProfileName !== "null") {
                if (defaultProfileName !== selectedProfileName) {
                    $("#" + parentId).block();
                    parameters.oldprofilename = defaultProfileName;
                    parameters.userdetloginname = $("#seluserdetloginname").val();
                    parameters.profilename = selectedProfileName;
                    parameters.neid = row.neid;
                    parameters.nename = row.nename;
                    parameters.neversionnumber = row.neversionnumber;
                    parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                    replyData = getDataFromServer("POST", URL, parameters, "text");
                    reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
                    replyFormat = eval('(' + replyData + ')');
                    updateStatusMessage(replyFormat, datagridId);
                    $("#" + parentId).unblock();
                } else {
                    $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
                    return;
                }
            } else {
                $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
                return;
            }
        } else {
            $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('MODIFY_MSG'), 'info');
            return;
        }
    } else if (datagridId === "userGuiPrivilegesList") {
        var userguiprvappreadaccess = [];
        var userguiprvappwriteaccess = [];
        var userguiprvappid = [];
        rows = $('#' + datagridId).datagrid('getChecked');
        if (rows.length > 0) {
            $("#" + parentId).block();
            for (j = 0; j < rows.length; j++) {
                row = rows[j];
                rowIndex = $('#' + datagridId).datagrid('getRowIndex', row);
                userguiprvappreadaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=userguiprvappreadaccess] input:checkbox").val());
                userguiprvappwriteaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=userguiprvappwriteaccess] input:checkbox").val());
                userguiprvappid.push(row.guiappid);
            }
            parameters.userguiprvappreadaccess = userguiprvappreadaccess.toString();
            parameters.userguiprvappwriteaccess = userguiprvappwriteaccess.toString();
            parameters.userguiprvappid = userguiprvappid.toString();
            parameters.userdetloginname = $("#seluserdetloginname").val();
            parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
            replyData = getDataFromServer("POST", URL, parameters, "text");
            reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
            replyFormat = eval('(' + replyData + ')');
            updateStatusMessage(replyFormat, datagridId);
            $("#" + parentId).unblock();
        } else {
            $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('CHECK_MSG'), 'info');
            return;
        }
    } else if (datagridId === "ipCamAsscList") {
        var ipcamasscreadaccess = [];
        var ipcamasscwriteaccess = [];
        var ipcamasscuserid = [];
        rows = $('#' + datagridId).datagrid('getChecked');
        if (rows.length > 0) {
            $("#" + parentId).block();
            for (i = 0; i < rows.length; i++) {
                row = rows[i];
                rowIndex = $('#' + datagridId).datagrid('getRowIndex', row);
                ipcamasscreadaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=ipcamasscreadaccess] input:checkbox").val());
                ipcamasscwriteaccess.push($('#' + parentId + " .datagrid-view2 .datagrid-btable tbody tr:eq(" + rowIndex + ") td[field=ipcamasscwriteaccess] input:checkbox").val());
                ipcamasscuserid.push(row.ipcamasscuserid);
            }
            parameters.ipcamasscreadaccess = ipcamasscreadaccess.toString();
            parameters.ipcamasscwriteaccess = ipcamasscwriteaccess.toString();
            parameters.ipcamasscuserid = ipcamasscuserid.toString();
            parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
            parameters.ipcamname = $("#selipcamname").val();
            replyData = getDataFromServer("POST", URL, parameters, "text");
            reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title);
            replyFormat = eval('(' + replyData + ')');
            updateStatusMessage(replyFormat, datagridId);
            $("#" + parentId).unblock();
        } else {
            $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('CHECK_MSG'), 'info');
            return;
        }
    }
}

function doSearch(value, name) {
    var selectedSearchBox = $(this);
    var searchBoxInput = $(this).parent().find('.textbox-text');
    var parentId = $(selectedSearchBox).closest('.datagrid').parent().attr("id");
    var matches = false;
    var searchText = value;
    if (searchText === "Search Text") {
        searchText = "";
    }
    if (searchText.length > 0) {
        $("#" + parentId + " .datagrid-btable tbody tr td:containsNC(" + searchText + ")").each(function () {
            $(this).addClass("highlight-ok");
            matches = true;
        });
        $("#" + parentId + " .datagrid-btable tbody tr td:not(:containsNC(" + searchText + "))").each(function () {
            $(this).removeClass("highlight-ok");
        });
        if (matches) {
            $(searchBoxInput).removeClass('highlight-nok');
            $(searchBoxInput).addClass('highlight-ok');
        } else {
            $(searchBoxInput).removeClass('highlight-ok');
            $(searchBoxInput).addClass('highlight-nok');
        }
    } else {
        $("#" + parentId + " .datagrid-btable tbody tr td").each(function () {
            $(this).removeClass("highlight-ok");
            $(searchBoxInput).removeClass('highlight-ok');
            $(searchBoxInput).removeClass('highlight-nok');
        });
    }
}

function exportAsCSV(URL, requestParams, additionalReqParams, parentTableId, parentTableActionLabel) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var parentRow = $('#' + parentTableId).datagrid('getSelected');
        if (!parentRow) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    var parameters = addAddtReqParamToReqParam(requestParams, additionalReqParams);
    parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    parameters.isExportRequest = true;
    var buildingName = getSelectedBuildingName();
    if (buildingName !== null && buildingName !== "" && buildingName !== undefined) {
        parameters.buildingName = buildingName;

    }
    var floorName = getSelectedFloorName();
    if (floorName !== null && floorName !== "" && floorName !== undefined) {
        parameters.floorName = floorName;

    }
    var neName = getSelectedNeName();
    if (neName !== null && neName !== "" && neName !== undefined) {
        parameters.neName = neName;

    }
    var subSysDisplayName = getSelectedSubSystemDisplayName();
    if (subSysDisplayName !== null && subSysDisplayName !== "" && subSysDisplayName !== undefined) {
        parameters.subSysDisplayName = subSysDisplayName;
    }
    URL = $.i18n.prop('SERVER_URL') + "/ExportAsCSV";
    $.fileDownload(URL, {
        httpMethod: "POST",
        data: parameters
    });
}

function exportAsExcel(URL, requestParams, additionalReqParams, parentTableId, parentTableActionLabel) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var parentRow = $('#' + parentTableId).datagrid('getSelected');
        if (!parentRow) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    var parameters = addAddtReqParamToReqParam(requestParams, additionalReqParams);
    parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    parameters.isExportRequest = true;
    var buildingName = getSelectedBuildingName();
    if (buildingName !== null && buildingName !== "" && buildingName !== undefined) {
        parameters.buildingName = buildingName;

    }
    var floorName = getSelectedFloorName();
    if (floorName !== null && floorName !== "" && floorName !== undefined) {
        parameters.floorName = floorName;

    }
    var neName = getSelectedNeName();
    if (neName !== null && neName !== "" && neName !== undefined) {
        parameters.neName = neName;

    }
    var subSysDisplayName = getSelectedSubSystemDisplayName();
    if (subSysDisplayName !== null && subSysDisplayName !== "" && subSysDisplayName !== undefined) {
        parameters.subSysDisplayName = subSysDisplayName;
    }
    URL = $.i18n.prop('SERVER_URL') + "/ExportAsExcel";
    $.fileDownload(URL, {
        httpMethod: "POST",
        data: parameters
    });
}

function exportAsPDF(URL, requestParams, additionalReqParams, parentTableId, parentTableActionLabel) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var parentRow = $('#' + parentTableId).datagrid('getSelected');
        if (!parentRow) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    var parameters = addAddtReqParamToReqParam(requestParams, additionalReqParams);
    parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    parameters.isExportRequest = true;
    var buildingName = getSelectedBuildingName();
    if (buildingName !== null && buildingName !== "" && buildingName !== undefined) {
        parameters.buildingName = buildingName;

    }
    var floorName = getSelectedFloorName();
    if (floorName !== null && floorName !== "" && floorName !== undefined) {
        parameters.floorName = floorName;

    }
    var neName = getSelectedNeName();
    if (neName !== null && neName !== "" && neName !== undefined) {
        parameters.neName = neName;

    }
    var subSysDisplayName = getSelectedSubSystemDisplayName();
    if (subSysDisplayName !== null && subSysDisplayName !== "" && subSysDisplayName !== undefined) {
        parameters.subSysDisplayName = subSysDisplayName;
    }
    URL = $.i18n.prop('SERVER_URL') + "/ExportAsPDF";
    $.fileDownload(URL, {
        httpMethod: "POST",
        data: parameters
    });
}

function exportAsXML(URL, requestParams, additionalReqParams, parentTableId, parentTableActionLabel) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var parentRow = $('#' + parentTableId).datagrid('getSelected');
        if (!parentRow) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    var parameters = addAddtReqParamToReqParam(requestParams, additionalReqParams);
    parameters.userName = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    parameters.isExportRequest = true;
    var buildingName = getSelectedBuildingName();
    if (buildingName !== null && buildingName !== "" && buildingName !== undefined) {
        parameters.buildingName = buildingName;

    }
    var floorName = getSelectedFloorName();
    if (floorName !== null && floorName !== "" && floorName !== undefined) {
        parameters.floorName = floorName;

    }
    var neName = getSelectedNeName();
    if (neName !== null && neName !== "" && neName !== undefined) {
        parameters.neName = neName;

    }
    var subSysDisplayName = getSelectedSubSystemDisplayName();
    if (subSysDisplayName !== null && subSysDisplayName !== "" && subSysDisplayName !== undefined) {
        parameters.subSysDisplayName = subSysDisplayName;
    }
    URL = $.i18n.prop('SERVER_URL') + "/ExportAsXML";
    $.fileDownload(URL, {
        httpMethod: "POST",
        data: parameters
    });
}
function addExportIcons(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}

function addRefreshIconAlone(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        }
    });
}

function addActionsIcons(parentId, tableId, data, URL, parameters, addURL, addParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total, onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{iconCls: 'icon-add',
                handler: function () {
                    addDataToServer(parentId, tableId, data, URL, parameters, addURL, addParameters, "Add " + actionLabel, "Add", "icon-add", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv', handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }}, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf', handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }}]});
}

function addEditActionIcon(parentId, tableId, data, URL, parameters, editURL, editParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}

function addDelActionIcon(parentId, tableId, data, URL, parameters, delURL, delParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv', handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]});
}

function addBothActionAndExportIcons(parentId, tableId, data, URL, parameters, addURL, addParameters, editURL, editParameters, delURL, delParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','), total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-add',
                handler: function () {
                    addDataToServer(parentId, tableId, data, URL, parameters, addURL, addParameters, "Add " + actionLabel, "Add", "icon-add", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-remove', handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}

function addSaveAndExportIcons(parentId, tableId, data, URL, parameters, addURL, addParameters, editURL, editParameters, delURL, delParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','), total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-save',
                handler: function () {
                    saveDataAtServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Update " + actionLabel, "Update", "icon-save", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel', handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]});
}

function addBothWithCopyIcon(parentId, tableId, data, URL, parameters, addURL, addParameters, editURL, editParameters, delURL, delParameters, copyURL, copyParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-add',
                handler: function () {
                    addDataToServer(parentId, tableId, data, URL, parameters, addURL, addParameters, "Add " + actionLabel, "Add", "icon-add", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-copy',
                handler: function () {
                    copyDataToServer(parentId, tableId, data, URL, parameters, copyURL, copyParameters, "Copy " + actionLabel, "Copy", "icon-copy", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}

function editAndDeleteIcon(parentId, tableId, data, URL, parameters, editURL, editParameters, delURL, delParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','), total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, {
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}

function addAbortWithEditAndDelIcon(parentId, tableId, data, URL, parameters, editURL, editParameters, delURL, delParameters, abortURL, abortParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist, deviceAttributes) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh", deviceAttributes);
            return false;
        },
        buttons: [{
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, deviceAttributes);
                }
            }, {
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, deviceAttributes);
                }
            }, {
                iconCls: 'icon-cancel',
                handler: function () {
                    abortDataToServer(parentId, tableId, URL, parameters, abortURL, abortParameters, actionLabel + "?", "Abort", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, deviceAttributes);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}
function addAbortWithEditAndDelIcon(parentId, tableId, data, URL, parameters, editURL, editParameters, delURL, delParameters, abortURL, abortParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist, deviceAttributes) {
    var pager = $('#' + tableId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServer(parentId, tableId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh", deviceAttributes);
            return false;
        },
        buttons: [{
                iconCls: 'icon-edit',
                handler: function () {
                    updateDataToServer(parentId, tableId, data, URL, parameters, editURL, editParameters, "Edit " + actionLabel, "Update", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, deviceAttributes);
                }
            }, {
                iconCls: 'icon-remove',
                handler: function () {
                    deleteDataFromServer(parentId, tableId, URL, parameters, delURL, delParameters, actionLabel + "?", "Delete", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, deviceAttributes);
                }
            }, {
                iconCls: 'icon-cancel',
                handler: function () {
                    abortDataToServer(parentId, tableId, URL, parameters, abortURL, abortParameters, actionLabel + "?", "Abort", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, deviceAttributes);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}

function setOtherDataGridOptions(tableId) {
    var cells = $("#" + tableId).datagrid('getPanel').find('div.datagrid-body td[field] div.datagrid-cell');
    cells.tooltip('destroy');
    cells.tooltip({
        content: function () {
            return $(this).text();
        }
    });
    addPaginationToolTip(tableId);
    $('.easyui-searchbox').searchbox();
}

function setColumnFilter(parentId, tableId, fitColumns, data) {
    if (Number(data.total) > 0) {
        setOtherDataGridOptions(tableId);
    }
}

function reloadWithFilter(parentId, tableId, fitColumns, data) {
    var rowWithTotal = {};
    rowWithTotal.total = data.total;
    rowWithTotal.rows = data.rows;
    $('#' + tableId).datagrid('loadData', rowWithTotal);
    if (Number(data.total) > 0) {
        setColumnFilter(parentId, tableId, fitColumns, data);
    }
}

function addPaginationToolTip(tableId) {
    var pager = $("#" + tableId).datagrid('getPager');
    $(pager).find('a.l-btn').each(function () {
        $(this).tooltip('destroy');
    });
    $(pager).find('a.l-btn').each(function () {
        $(this).tooltip({content: function () {
                var cc = $(this).find('span.l-btn-icon').attr('class').split(' ');
                var icon = cc[1].split('-')[1];
                var toolTipContent = "";
                switch (icon) {
                    case "first":
                        toolTipContent = "First Page";
                        break;
                    case "prev":
                        toolTipContent = "Previous Page";
                        break;
                    case "next":
                        toolTipContent = "Next Page";
                        break;
                    case "last":
                        toolTipContent = "Last Page";
                        break;
                    case "load":
                        toolTipContent = "Refresh Page";
                        break;
                    case "csv":
                        toolTipContent = "Export As CSV";
                        break;
                    case "excel":
                        toolTipContent = "Export As Excel";
                        break;
                    case "xml":
                        toolTipContent = "Export As XML";
                        break;
                    case "pdf":
                        toolTipContent = "Export As PDF";
                        break;
                    case "add":
                        toolTipContent = "Add";
                        break;
                    case "edit":
                        toolTipContent = "Edit";
                        break;
                    case "remove":
                        toolTipContent = "Delete";
                        break;
                    case "save":
                        toolTipContent = "Update";
                        break;
                    case "copy":
                        toolTipContent = "Copy";
                        break;
                    case "cancel":
                        toolTipContent = "Abort";
                        break;
                    default:
                        break;
                }
                return toolTipContent;
            }
        });
    });
}

function createColumnMenu(parentId, tableId) {
    var cmenu = $('<div id="' + tableId + 'CMenu"/>').appendTo('body');
    cmenu.menu({
        onClick: function (item) {
            if (item.iconCls === 'icon-ok') {
                $('#' + tableId).datagrid('hideColumn', item.name);
                cmenu.menu('setIcon', {
                    target: item.target,
                    iconCls: 'icon-empty'
                });
                $('#' + tableId).datagrid('resize');
            } else {
                $('#' + tableId).datagrid('showColumn', item.name);
                cmenu.menu('setIcon', {
                    target: item.target,
                    iconCls: 'icon-ok'
                });
                $('#' + tableId).datagrid('resize');
            }
        }
    });
    var fields = $('#' + tableId).datagrid('getColumnFields');
    for (var i = 0; i < fields.length; i++) {
        var field = fields[i];
        var col = $('#' + tableId).datagrid('getColumnOption', field);
        if (!col.hidden === true) {
            cmenu.menu('appendItem', {
                text: col.title,
                name: field,
                iconCls: 'icon-ok'
            });
        }
    }
    return cmenu;
}

function endRowEditing(datagridId) {
    var editIndex = tableEditIndex[datagridId];
    if (editIndex === null || editIndex === "" || editIndex === undefined) {
        return true;
    }
    if ($('#' + datagridId).datagrid('validateRow', editIndex)) {
        var editors = $("#" + datagridId).datagrid('getEditors', editIndex);
        $.each(editors, function (i, ed) {
            if (ed.type === "combobox") {
                var field = ed.field;
                $('#' + datagridId).datagrid('getRows')[editIndex][field] = $(ed.target).combobox('getText');
            }
        });
        $('#' + datagridId).datagrid('endEdit', editIndex);
        tableEditIndex[datagridId] = undefined;
        return true;
    } else {
        return false;
    }
}

function onRowDoubleClick(index) {
    var datagridId = $(this).datagrid('options').id;
    var editIndex = tableEditIndex[datagridId];
    if (editIndex !== index) {
        if (endRowEditing(datagridId)) {
            $('#' + datagridId).datagrid('selectRow', index).datagrid('beginEdit', index);
            var editors = $("#" + datagridId).datagrid('getEditors', index);
            $.each(editors, function (i, ed) {
                if (ed.type === "combobox") {
                    var data = window[$(ed.target).combobox('options').functionToExec](datagridId);
                    $(ed.target).combobox('loadData', data);
                }
            });
            tableEditIndex[datagridId] = index;
        } else {
            $('#' + datagridId).datagrid('selectRow', editIndex);
        }
    }
}
