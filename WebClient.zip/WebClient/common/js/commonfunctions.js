/*$(document).bind("contextmenu", function (e) {
 e.preventDefault();
 });*/

String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

Number.prototype.countDecimals = function () {
    if (Math.floor(this.valueOf()) === this.valueOf())
        return 0;
    return this.toString().split(".")[1].length || 0;
};

//function escapeRegExp(str) {
//    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // $& means the whole matched string
//}
//
//function replaceAll(str, find, replace) {
//    return str.replace(new RegExp(find, 'g'), replace);
//}

function escapeRegExp(str) {
    return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1"); // $1 means the whole matched string
}

function replaceAll(str, find, replace) {
    return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}

$.fn.datebox.defaults.formatter = function (date) {
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    var d = date.getDate();
    return y + '-' + (m < 10 ? ('0' + m) : m) + '-' + (d < 10 ? ('0' + d) : d);
};

$.fn.datebox.defaults.parser = function (s) {
    if (!s)
        return new Date();
    var ss = s.split('-');
    var y = parseInt(ss[0], 10);
    var m = parseInt(ss[1], 10);
    var d = parseInt(ss[2], 10);
    if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
        return new Date(y, m - 1, d);
    } else {
        return new Date();
    }
};

$.extend($.fn.tabs.methods, {
    isDisabled: function (jq, which) {
        return jq.tabs('getTab', which).panel('options').tab.hasClass('tabs-disabled');
    }
});

$.extend($.fn.validatebox.methods, {
    required: function (jq, required) {
        return jq.each(function () {
            var opts = $(this).validatebox('options');
            opts.required = required !== undefined ? required : true;
            $(this).validatebox('validate');
        });
    }
});

$.extend($.fn.accordion.methods, {
    hidePanel: function (jq, which) {
        return jq.each(function () {
            var p = $(this).accordion('getPanel', which);
            p.panel('close').panel('header').removeClass('accordion-header');
            $(this).accordion('resize');
        });
    },
    showPanel: function (jq, which) {
        return jq.each(function () {
            var p = $(this).accordion('getPanel', which);
            p.panel('open').panel('header').addClass('accordion-header');
            $(this).accordion('resize');
        });
    }
});

$.extend($.fn.tabs.methods, {
    hideHeader: function (jq) {
        return jq.each(function () {
            var header = $(this).children('div.tabs-header');
            header.css('background-color', 'transparent');
            header.find('div.tabs-wrap').css('height', 0);
            $(this).tabs('resize');
        });
    }
});

$.extend($.fn.textbox.methods, {
    show: function (jq) {
        return jq.each(function () {
            $(this).next().show();
        });
    },
    hide: function (jq) {
        return jq.each(function () {
            $(this).next().hide();
        });
    }
});

$.extend($.fn.form.methods, {
    setDirty: function (jq) {
        return jq.each(function () {
            $(this).form("options").dirty = true;
        });
    }
});

function resizePortalLayout(portalId, width, height) {
    if ($('#' + portalId).length) {
        $("#" + portalId).portal('resize', {width: width, height: height});
        var panels = $("#" + portalId).portal('getPanels', 0);
        for (var i = 0; i < panels.length; i++) {
            panels[i].panel('resize');
        }
    }
}

$.extend($.fn.form.methods, {
    customload: function (jq, data) {
        return jq.each(function () {
            var target = this;
            for (var name in data) {
                var val = data[name];
                target.find("td[name=\"" + name + "\"]").val(val);
            }
        });
    }
});

$.extend($.fn.textbox.methods, {
    show: function (jq) {
        return jq.each(function () {
            $(this).next().show();
        });
    },
    hide: function (jq) {
        return jq.each(function () {
            $(this).next().hide();
        });
    }
});

function goToHome() {
    var appURL = serverURL + "/index.jsp";
    window.location = appURL;
}

function throwAjaxErrorToUser(jqXHR, textStatus, errorThrown) {
    var sessionTimeoutMsg = "Session Timeout";
    $.unblockUI();
    var win = $("body").children("div.messager-window").children("div.messager-body");
    if (win.length) {
        return;
    }
    if (jqXHR.status === 408) {
        $.messager.alert(infoLabel, sessionTimeoutMsg, 'info', function () {
            goToHome();
        });
    } else if (jqXHR.status === 500) {
        //Do Nothing
    } else if (jqXHR.status !== 200 && jqXHR.status !== 304) {
        $.messager.alert(infoLabel, jqXHR.statusText, 'info', function () {
            goToHome();
        });
    }
}

$.ajaxSetup({
    cache: false,
    timeout: 60000,
    type: "POST",
    data: {
        operationDoneBy: document.getElementById("commonfunctions").getAttribute("data-name") || $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'))
    },
    error: function (jqXHR, textStatus, errorThrown) {
        throwAjaxErrorToUser(jqXHR, textStatus, errorThrown);
    }
});

function logout() {
    $('#loggedInUser').tooltip('hide');
    var logoutURL = $.i18n.prop('SERVER_URL') + "/logout";
    var parameters = "requestType=Authentication&subRequestType=logout&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    jQuery.ajax({
        type: "POST",
        url: logoutURL,
        data: parameters,
        success: function (response) {
            goToHome();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            goToHome();
        }
    });
}

jQuery.fn.scenter = function (div) {
    this.css("position", "absolute");
    var position = div.position();
    this.css("top", Math.max(0, ((div.height() - this.outerHeight()) / 2) + position.top) + "px");
    this.css("left", Math.max(0, ((div.width() - this.outerWidth()) / 2) + position.left) + "px");
    return this;
};

jQuery.fn.center = function (div) {
    this.css("position", "absolute");
    var position = div.position();
    this.css("top", Math.max(0, ((div.height() - this.outerHeight()) / 3) + position.top) + "px");
    this.css("left", Math.max(0, ((div.width() - this.outerWidth()) / 2) + position.left) + "px");
    return this;
};

jQuery.fn.centerEM = function (div) {
    this.css("position", "absolute");
    var position = div.position();
    this.css("top", Math.max(0, ((div.height() - this.outerHeight()) / 3) + position.top) + "px");
    this.css("left", Math.max(0, ((div.width() - this.outerWidth()) / 2.5) + position.left) + "px");
    return this;
};

$.extend($.expr[":"], {
    "containsNC": function (elem, i, match, array) {
        return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
});

function IsValidJson(json) {
    try {
        JSON.parse(json);
    } catch (e) {
        return false;
    }
    return true;
}

function addValidationToElement(elementId) {
    $('#' + elementId).validatebox($('#' + elementId).data());
    $('#' + elementId).validatebox({
        tipOptions: {// the options to create tooltip
            showEvent: 'mouseenter',
            hideEvent: 'mouseleave',
            showDelay: 0,
            hideDelay: 0,
            zIndex: '',
            onShow: function () {
                if (!$(this).hasClass('validatebox-invalid')) {
                    if ($(this).tooltip('options').prompt) {
                        $(this).tooltip('update', $(this).tooltip('options').prompt);
                    } else {
                        $(this).tooltip('tip').hide();
                    }
                } else {
                    $(this).tooltip('tip').css({
                        color: '#000',
                        borderColor: '#CC9933',
                        backgroundColor: '#FFFFCC'
                    });
                }
            },
            onHide: function () {
                if (!$(this).tooltip('options').prompt) {
                    $(this).tooltip('destroy');
                }
            }
        }
    }).tooltip({
        position: 'right',
        content: function () {
            var opts = $(this).validatebox('options');
            return opts.prompt;
        },
        onShow: function () {
            $(this).tooltip('tip').css({
                color: '#000',
                borderColor: '#CC9933',
                backgroundColor: '#FFFFCC'
            });
        }
    });
}

function removeValidationFromElement(elementId) {
    $('#' + elementId).validatebox('destroy');
}

function changeuserpassword() {
    $('#loggedInUser').tooltip('hide');
    var dialogContent = '<form id="popUpDialogForm" class="popUpDialogForm" method="post" autocomplete="off">' +
        '<table><tr>' +
        '<th>' + $.i18n.prop('CURRENT_PASSWORD_LABEL') + '</th>' +
        '<td><input id="oldpassword" name="oldpassword" prompt="' + $.i18n.prop('CURRENT_PASSWORD_LABEL') + '" data-options="required: true,validType: \'charLength[8,36]\'"></td></tr>' +
        '<tr><th>' + $.i18n.prop('NEW_PASSWORD_LABEL') + '</th>' +
        '<td><input id="newpassword" name="newpassword" prompt="' + $.i18n.prop('NEW_PASSWORD_LABEL') + '" data-options="required: true,validType: \'charLength[8,36]\'"></td></tr>' +
        '<tr><th>' + $.i18n.prop('CONFIRM_PASSWORD_LABEL') + '</th>' +
        '<td><input id="confirmpassword" name="confirmpassword" prompt="' + $.i18n.prop('CONFIRM_PASSWORD_LABEL') + '" data-options="required: true,validType: [\'equals[\\\'#newpassword\\\']\', \'charLength[8,36]\']"></td></tr>' +
        '</table></form>';
    $("#popUpDialog").empty().append(dialogContent);
    $('#popUpDialog').dialog({
        cache: false,
        model: true,
        width: 400,
        height: 'auto',
        title: $.i18n.prop('CHANGE_PASSWORD_LABEL'),
        resizable: false,
        buttons: [{
                text: $.i18n.prop('UPDATE_LABEL'),
                iconCls: 'icon-edit',
                handler: function () {
                    var okBtn = $(this);
                    $('#popUpDialogForm').form('submit', {
                        url: $.i18n.prop('SERVER_URL') + "/changeuserpassword",
                        onSubmit: function (param) {
                            var isValid = $('#popUpDialogForm').form('validate');
                            if (isValid) {
                                $(okBtn).linkbutton('disable');
                                param.requestType = 'Authentication';
                                param.subRequestType = 'changeuserpassword';
                                param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                                param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                            }
                            return isValid;
                        },
                        success: function (data) {
                            $('#popUpDialog').dialog('close');
                            var replyFormat = eval('(' + data + ')');
                            updateStatusMessage(replyFormat, "");
                        },
                        onLoadError: function () {
                            $('#popUpDialog').dialog('close');
                        }
                    });
                }
            }, {
                text: 'Close',
                iconCls: 'icon-cancel',
                handler: function () {
                    $('#popUpDialog').dialog('close');
                }
            }]
    });
    $('#popUpDialog').dialog('open');
    $("#oldpassword").passwordbox();
    addValidationToElement("oldpassword");
    $("#newpassword").passwordbox();
    addValidationToElement("newpassword");
    $("#confirmpassword").passwordbox();
    addValidationToElement("confirmpassword");
}

function getDataFromServer(method, URL, parameters, dataType) {
    var text = "";
    parameters.operationDoneBy = document.getElementById("commonfunctions").getAttribute("data-name") || $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    $.ajax({
        type: method,
        data: parameters,
        url: URL,
        dataType: dataType,
        cache: false,
        async: false,
        success: function (data) {
            text = String(data).replace(/\\\\/g, "\\");
        }
    });
    return text;
}

function getHTMLContent(serverURL, parameters) {
    var content = "";
    $.ajax({
        type: "POST",
        data: parameters,
        url: serverURL,
        dataType: "html",
        cache: false,
        async: false,
        success: function (data) {
            content = data;
        }
    });
    return content;
}

function loadJSPFileIntoDiv(serverURL, parameters, appendToDiv) {
    var content = "";
    $.ajax({
        type: "POST",
        data: parameters,
        url: serverURL,
        dataType: "html",
        cache: false,
        async: false,
        success: function (data) {
            content = data;
            $("#" + appendToDiv).empty().append(content);
        }
    });
}

function generateElementBasedOnType(data, disabledKey) {
    var dataField = data.field;
    var formName = data.formname;
    if (formName === null || formName === "" || formName === undefined) {
        formName = dataField;
    }
    var element = "";
    var htmlOptions = "";
    var dataoptions = data.dataoptions || "";
    var validType = "";
    if (data.required) {
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "required:true";
    }
    if (data.tooltip) {
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "prompt:\'" + data.tooltip + "\'";
    }
    if (data.disabled) {
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "disabled:true";
        htmlOptions += ' value="' + $("#" + disabledKey + dataField).val() + '"';
    }
    if (data.readonly) {
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "readonly:true";
    }
    if (data.validtype) {
        var validTypes = data.validtype.split("^");
        if (validTypes.length === 1) {
            validType = "'" + data.validtype + "'";
        } else {
            for (var validtypeindex = 0; validtypeindex < validTypes.length; validtypeindex++) {
                if (validtypeindex === 0) {
                    validType += "[" + "\'" + validTypes[validtypeindex].replace(/'/g, "\\'") + "\'";
                } else {
                    validType += "," + "\'" + validTypes[validtypeindex].replace(/'/g, "\\'") + "\'";
                }
            }
            if (validType) {
                validType += "]";
            }
        }
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "validType:" + validType;
    }
    switch (data.datatype) {
        case "String":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Name":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Number":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-numberbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "NumberSpinner":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-numberspinner" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Email":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "URL":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Date":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-datebox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Time":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-timespinner" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Datetime":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-datetimebox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Radio":
            element += '<input id="' + dataField + '" name="' + formName + '" type="radio" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Checkbox":
            element += '<input id="' + dataField + '" name="' + formName + '" type="checkbox" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Password":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-passwordbox" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Label":
            element += '<label id="' + dataField + '" name="' + formName + '>' + data.title + '</label>';
            break;
        case "Phone":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Textarea":
            var selectedValue = $("#" + disabledKey + dataField).val() || "";
            element += '<textarea id="' + dataField + '" name="' + formName + '" ' + htmlOptions + ' data-options="' + dataoptions + '">' + selectedValue + '</textarea>';
            break;
        case "Combobox":
            element += '<input id="' + dataField + '" name="' + formName + '" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Domainname":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "IP":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Port":
            dataoptions += (dataoptions.length > 0 ? ',' : '') + "min:1,max:65535";
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-numberspinner" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Interval":
            dataoptions += (dataoptions.length > 0 ? ',' : '') + "min:1,max:" + $.jStorage.get("maxInterval");
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-numberspinner" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Double":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-numberbox" type="text" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "File":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-filebox" ' + htmlOptions + ' data-options="' + dataoptions + '" style="width:99%;"/>';
            break;
        case "Div":
            element += '<div id="' + dataField + '"></div>';
            break;
        default:
    }
    return element;
}

function insertAtCaret(areaId, text) {
    var txtarea = document.getElementById(areaId);
    var scrollPos = txtarea.scrollTop;
    var strPos = 0;
    var br = ((txtarea.selectionStart || txtarea.selectionStart === '0') ? "ff" : (document.selection ? "ie" : false));
    var range = "";
    if (br === "ie") {
        txtarea.focus();
        range = document.selection.createRange();
        range.moveStart('character', -txtarea.value.length);
        strPos = range.text.length;
    } else if (br === "ff") {
        strPos = txtarea.selectionStart;
    }
    var front = (txtarea.value).substring(0, strPos);
    var back = (txtarea.value).substring(strPos, txtarea.value.length);
    txtarea.value = front + text + back;
    strPos = strPos + text.length;
    if (br === "ie") {
        txtarea.focus();
        range = document.selection.createRange();
        range.moveStart('character', -txtarea.value.length);
        range.moveStart('character', strPos);
        range.moveEnd('character', 0);
        range.select();
    } else if (br === "ff") {
        txtarea.selectionStart = strPos;
        txtarea.selectionEnd = strPos;
        txtarea.focus();
    }
    txtarea.scrollTop = scrollPos;
}

function addContentToForm(formId, tableId) {
    //var columnFields = $.jStorage.get(tableId);
    var columnFields = $("#" + tableId).datagrid('getColumnFields');
    var formContent = "";
    var colSpanCnt = 0;
    for (var i = 0; i < columnFields.length; i++) {
        $.each(columnFields[i], function (index, data) {
            if (data.editable) {
                if (colSpanCnt % 2 === 0) {
                    formContent += '<tr>';
                }
                formContent += '<th>' + data.title + '</th>' + '<td>';
                formContent += generateElementBasedOnType(data, "");
                formContent += '</td>';
                if (colSpanCnt % 2 === 1) {
                    formContent += '</tr>';
                }
                colSpanCnt++;
            }
        });
    }
    $("#" + formId + " table tbody").empty().append(formContent);
    $("#" + formId).find('input, textarea').each(function (i, field) {
        if (!$('#' + field.id).prop('disabled') === true) {
            $('#' + field.id).validatebox($('#' + field.id).data());
        }
    });
}

function updateStatusMessage(statusObj, statusBarId) {
    var serverTime = statusObj.servertime;
    var status = statusObj.status.toLowerCase();
    var message = statusObj.message;
    var statusMsgWithTime = serverTime + " " + message.replace("\^", "-");
    var statusMessage = "";
    if (status === "info") {
        statusMessage = '<div class="statusMsg">' +
            '<div class="custommessager-icon custommessager-info"></div>' +
            '<div class="statusMsgBody"><span id="statusMsgBodySpan" class="statusMsgBodySpan">' +
            statusMsgWithTime + '</span></div>' + '</div>';
    } else if (status === "failure" || status === "error") {
        statusMessage = '<div class="statusMsg">' +
            '<div class="custommessager-icon custommessager-error"></div>' +
            '<div class="statusMsgBody"><span id="statusMsgBodySpan" class="statusMsgBodySpan">' +
            statusMsgWithTime + '</span></div>' + '</div>';
    } else if (status === "success") {
        statusMessage = '<div class="statusMsg">' +
            '<div class="custommessager-icon custommessager-info"></div>' +
            '<div class="statusMsgBody"><span id="statusMsgBodySpan" class="statusMsgBodySpan">' +
            statusMsgWithTime + '</span></div>' + '</div>';
    }
    $("#statusBar").html(statusMessage);
    if (statusBarId !== "" && statusBarId !== null && statusBarId !== undefined) {
        $("." + statusBarId + "StatusBar").html(statusMessage);
    }
}

function params_unserialize(p) {
    var ret = {}, seg = p.replace(/^.*\?/, '').split('&'), len = seg.length, i = 0, s;
    for (; i < len; i++) {
        if (!seg[i]) {
            continue;
        }
        s = seg[i].split('=');
        ret[s[0]] = s[1];
    }
    return ret;
}

function onChangeTheme(newTheme, oldTheme) {
    var themeURL = clientURL + '/easyui/themes/' + newTheme + '/easyui.css';
    $.jStorage.set("clientSelThemeName", newTheme);
    $.jStorage.set("clientSelThemeURL", themeURL);
    $("#clientTheme").attr("href", themeURL);
    setTimeout(function () {
        $(".liftgroup").css('stroke', $(".panel-header").css('border-top-color'));
        $(".liftgroup").css('fill', $(".panel-body").css('color'));
        $(".firegroup").css('stroke', $(".panel-header").css('border-top-color'));
        $(".firegroup").css('fill', $(".panel-body").css('color'));
        if (typeof meterValues !== 'undefined') {
            if (meterValues !== null && meterValues !== "" && meterValues !== undefined) {
                $.each(meterValues, function (key, value) {
                    cummEnergyMeterReading(key, value);
                });
            }
        }
    }, 100);
}

function checkNetConnection() {
    var isOnline = "";
    var r = Math.round(Math.random() * 10000);
    $.get("http://chakranetwork.in/", {subins: r}, function (d) {
        isOnline = true;
    }).error(function () {
        isOnline = false;
    });
    return isOnline;
}

function comboboxSearchOnSelect(comboboxId) {
    var cc = $("#" + comboboxId);
    if (cc !== null && cc !== "" && cc !== undefined) {
        cc.combobox('textbox').bind('keydown', function (e) {
            var s = String.fromCharCode(e.keyCode);
            var opts = cc.combobox('options');
            var data = cc.combobox('getData');
            var state = $.data(cc[0], 'combobox');
            for (var i = 0; i < data.length; i++) {
                var item = data[i];
                if (item[opts.textField].toLowerCase().substring(0, 1) === s.toLowerCase()) {
                    if (typeof state.index === 'undefined' || (typeof state.index !== 'undefined' && i > state.index)) {
                        cc.combobox('select', item[opts.valueField]);
                        state.index = i;
                        break;
                    }
                }
                if (i === data.length - 1 && typeof state.index !== 'undefined') {
                    state.index = undefined;
                    arguments.callee(e);
                }
            }
        });
    }
}

function showNEDetails(neRefId) {
    $("#" + neRefId + "AboutPanel").block();
    var refreshButtonId = neRefId + "AboutRefresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var neName = $.trim(getSelectedNeName());
    var neId = $.trim(getSelectedNeId());
    var neVersionNumber = $.trim(getSelectedNeVersionNumber());
    var ipAddress = $.trim(getSelectedNeIpaddress());
    var port = $.trim(getSelectedNePort());
    var uniqueId = $.trim(getSelectedUniqueId());
    var neDetails = "";
    if ($.trim(neName) !== null && $.trim(neName) !== "" && $.trim(neName) !== undefined) {
        neDetails += "<tr>" +
            "<th>" + $.i18n.prop('CONTROLLER_NAME_LABEL') + "</th>" +
            "<td>" + neName + "</td>" +
            "</tr>";
    }
    if ($.trim(neId) !== null && $.trim(neId) !== "" && $.trim(neId) !== undefined) {
        neDetails += "<tr>" +
            "<th>" + $.i18n.prop('CONTROLLER_ID_LABEL') + "</th>" +
            "<td>" + neId + "</td>" +
            "</tr>";
    }
    if ($.trim(neVersionNumber) !== null && $.trim(neVersionNumber) !== "" && $.trim(neVersionNumber) !== undefined) {
        neDetails += "<tr>" +
            "<th>" + $.i18n.prop('CONTROLLER_VERSION_LABEL') + "</th>" +
            "<td>" + neVersionNumber + "</td>" +
            "</tr>";
    }
    if ($.trim(ipAddress) !== null && $.trim(ipAddress) !== "" && $.trim(ipAddress) !== undefined) {
        neDetails += "<tr>" +
            "<th>" + $.i18n.prop('CONTROLLER_IP_ADDRESS_LABEL') + "</th>" +
            "<td>" + ipAddress + "</td>" +
            "</tr>";
    }
    if ($.trim(port) !== null && $.trim(port) !== "" && $.trim(port) !== undefined && $.trim(port) !== "0") {
        neDetails += "<tr>" +
            "<th>" + $.i18n.prop('CONTROLLER_PORT_LABEL') + "</th>" +
            "<td>" + port + "</td>" +
            "</tr>";
    }
    if ($.trim(uniqueId) !== null && $.trim(uniqueId) !== "" && $.trim(uniqueId) !== undefined) {
        neDetails += "<tr>" +
            "<th>" + $.i18n.prop('CONTROLLER_UNIQUE_ID_LABEL') + "</th>" +
            "<td>" + uniqueId + "</td>" +
            "</tr>";
    }
    $("#" + neRefId + "AboutForm table tbody").empty().append(neDetails);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + neRefId + "AboutPanel").unblock();
}

function showSubSystemDetails(neRefId) {
    $("#" + neRefId + "AboutPanel").block();
    var refreshButtonId = neRefId + "AboutRefresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var subSysName = $.trim(getSelectedSubSystemName());
    var subSysId = $.trim(getSelectedSubSystemId());
    var subSysRecdId = $.trim(getSelectedSubSystemRecordId());
    var subSysDisplayName = $.trim(getSelectedSubSystemDisplayName());
    var tenantDisplayName = $.trim(getSelectedTenantDisplayName());
    var subSystemDetails = "";
    if ($.trim(subSysName) !== null && $.trim(subSysName) !== "" && $.trim(subSysName) !== undefined) {
        subSystemDetails += "<tr>" +
            "<th>" + $.i18n.prop('SUBSYSTEM_NAME_LABEL') + "</th>" +
            "<td>" + subSysName + "</td>" +
            "</tr>";
    }
    if ($.trim(subSysId) !== null && $.trim(subSysId) !== "" && $.trim(subSysId) !== undefined) {
        subSystemDetails += "<tr>" +
            "<th>" + $.i18n.prop('SUBSYSTEM_ID_LABEL') + "</th>" +
            "<td>" + subSysId + "</td>" +
            "</tr>";
    }
    if ($.trim(subSysRecdId) !== null && $.trim(subSysRecdId) !== "" && $.trim(subSysRecdId) !== undefined) {
        subSystemDetails += "<tr>" +
            "<th>" + $.i18n.prop('SUBSYSTEM_RECORD_ID_LABEL') + "</th>" +
            "<td>" + subSysRecdId + "</td>" +
            "</tr>";
    }
    if ($.trim(subSysDisplayName) !== null && $.trim(subSysDisplayName) !== "" && $.trim(subSysDisplayName) !== undefined) {
        subSystemDetails += "<tr>" +
            "<th>" + $.i18n.prop('SUBSYSTEM_DISPLAY_NAME_LABEL') + "</th>" +
            "<td>" + subSysDisplayName + "</td>" +
            "</tr>";
    }
    if ($.trim(tenantDisplayName) !== null && $.trim(tenantDisplayName) !== "" && $.trim(tenantDisplayName) !== undefined) {
        subSystemDetails += "<tr>" +
            "<th>" + $.i18n.prop('SUBSYSTEM_TENANT_DISPLAY_NAME_LABEL') + "</th>" +
            "<td>" + tenantDisplayName + "</td>" +
            "</tr>";
    }
    $("#" + neRefId + "AboutForm table tbody").empty().append(subSystemDetails);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + neRefId + "AboutPanel").unblock();
}

function aboutBMS() {
    $("#aboutPanel").block();
    if ($("#aboutRefresh").length) {
        $("#aboutRefresh").linkbutton('disable');
    }
    var URL = $.i18n.prop('SERVER_URL') + "/AboutBMS";
    var parameters = "requestType=BMSMgmt&subRequestType=AboutBMS&key=ABOUT_BMS";
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    var formData = data.formdata;
    var bmsDetails = "";
    var bmsAppVersion = $.trim(formData.bmsAppVersion);
    var bmsDBVersion = $.trim(formData.bmsDBVersion);
    var serverIp = $.trim(formData.serverIp);
    var serverPort = $.trim(formData.serverPort);
    var resinVersion = $.trim(formData.resinVersion);
    var resinUpTime = $.trim(formData.resinUpTime);
    var javaVersion = $.trim(formData.javaVersion);
    var mysqlVersion = $.trim(formData.mysqlVersion);
    if ($.trim(bmsAppVersion) !== null && $.trim(bmsAppVersion) !== "" && $.trim(bmsAppVersion) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('APP_VERSION_LABEL') + "</th>" +
            "<td>" + bmsAppVersion + "</td>" +
            "</tr>";
    }
    if ($.trim(bmsDBVersion) !== null && $.trim(bmsDBVersion) !== "" && $.trim(bmsDBVersion) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('DB_VERSION_LABEL') + "</th>" +
            "<td>" + bmsDBVersion + "</td>" +
            "</tr>";
    }
    if ($.trim(serverIp) !== null && $.trim(serverIp) !== "" && $.trim(serverIp) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('SERVER_IP_LABEL') + "</th>" +
            "<td>" + serverIp + "</td>" +
            "</tr>";
    }
    if ($.trim(serverPort) !== null && $.trim(serverPort) !== "" && $.trim(serverPort) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('SERVER_PORT_LABEL') + "</th>" +
            "<td>" + serverPort + "</td>" +
            "</tr>";
    }
    if ($.trim(resinVersion) !== null && $.trim(resinVersion) !== "" && $.trim(resinVersion) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('RESIN_VERSION_LABEL') + "</th>" +
            "<td>" + resinVersion + "</td>" +
            "</tr>";
    }
    if ($.trim(resinUpTime) !== null && $.trim(resinUpTime) !== "" && $.trim(resinUpTime) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('RESIN_UPTIME_LABEL') + "</th>" +
            "<td>" + resinUpTime + "</td>" +
            "</tr>";
    }
    if ($.trim(javaVersion) !== null && $.trim(javaVersion) !== "" && $.trim(javaVersion) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('JAVA_VERSION_LABEL') + "</th>" +
            "<td>" + javaVersion + "</td>" +
            "</tr>";
    }
    if ($.trim(mysqlVersion) !== null && $.trim(mysqlVersion) !== "" && $.trim(mysqlVersion) !== undefined) {
        bmsDetails += "<tr>" +
            "<th>" + $.i18n.prop('MYSQL_VERSION_LABEL') + "</th>" +
            "<td>" + mysqlVersion + "</td>" +
            "</tr>";
    }
    //$("#aboutForm").form('clear');
    //$("#aboutForm").form('load', formData);
    $("#aboutForm table tbody").empty().append(bmsDetails);
    updateStatusMessage(data, "about");
    if ($("#aboutRefresh").length) {
        $("#aboutRefresh").linkbutton('enable');
    }
    $("#aboutPanel").unblock();
}
