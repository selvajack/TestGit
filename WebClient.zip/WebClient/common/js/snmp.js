function createSNMPForm(formId, formData) {
    var length = formData.row;
    var columnFields = formData.column;
    var len = columnFields.length;
    var row = formData.rows[0];
    var dialogContent = '<table align="center">';
    var editableCount = columnFields.length;
    var length = formData.column[0].length;
    console.log("length" + length);
    var colSpanCnt = 0;
    for (var j = 0; j < columnFields.length; j++) {
        $.each(columnFields[j], function (index, data) {
            if (data.editable) {
                if (length > 6) {
                    if (colSpanCnt % 2 === 0) {
                        dialogContent += '<tr>';
                    }
                } else {
                    dialogContent += '<tr>';
                }
                dialogContent += '<th>' + data.title + '</th>' + '<td>';
                dialogContent += generateElementBasedOnTypeForSNMP(data);
                dialogContent += '</td>';
                if (length > 6) {
                    if (colSpanCnt % 2 === 1) {
                        dialogContent += '</tr>';
                    }
                    colSpanCnt++;
                } else {
                    dialogContent += '</tr>';
                }
            }
        });
    }
    dialogContent += "</table>";
    $('#' + formId).empty().append(dialogContent);
    $('#' + formId).find('input, textarea').each(function (i, field) {
        var elementId = field.id;
        var dataOptions;
        var dataOptionObj = {};
        var a = $('#' + elementId).prop('disabled');
        if (!$('#' + elementId).prop('disabled') === true) {
            var b = $('#' + elementId).hasClass("easyui-numberbox");
            if ($('#' + elementId).hasClass("easyui-numberbox")) {
                $('#' + elementId).numberbox();
            } else if ($('#' + elementId).hasClass("easyui-datebox")) {
                dataOptions = $('#' + elementId).attr('data-options');
                dataOptionObj = {};
                $('#' + elementId).removeAttr('data-options');
                $.each(dataOptions.split(","), function (index, item) {
                    dataOptionObj[item.split(":")[0]] = item.split(":")[1];
                });
                $('#' + elementId).datebox({
                    editable: false
                });
                $('#' + elementId).datebox(dataOptionObj);
            } else if ($('#' + elementId).hasClass("easyui-datetimebox")) {
                $('#' + elementId).datetimebox({
                    editable: false
                });
            } else if ($('#' + elementId).hasClass("easyui-timespinner")) {
                $('#' + elementId).timespinner();
            } else if ($('#' + elementId).hasClass("easyui-numberspinner")) {
                $('#' + elementId).numberspinner();
            } else if ($('#' + elementId).hasClass("spinner")) {
                $('#' + elementId).spinner();
            } else if ($('#' + elementId).hasClass("easyui-textbox")) {
                $('#' + elementId).textbox();
            } else if ($('#' + elementId).hasClass("easyui-combobox")) {

                $('#' + elementId).combobox();
            } else if ($('#' + elementId).hasClass("easyui-Checkbox")) {

                $('#' + elementId).Checkbox();
            }

        }
    });
    if (row) {
        $('#templateConfigForm').form('load', row);
    }
    $('#' + formId + ' form:not(.filter) :input:visible:first').focus();
    $('#' + formId).form('validate');
}

function generateElementBasedOnTypeForSNMP(data, disabledKey) {
    var dataField = data.field;
    var formName = data.formname;
    if (formName === null || formName === "" || formName === undefined) {
        formName = dataField;
    }
    var element = "";
    var htmlOptions = "";
    if (data.validtype === 'None') {
        var dataoptions = "";
    }
    if (data.dataoptions === 'None') {

        var dataoptions = "";
    } else {
        var dataoptions = data.dataoptions || "";
    }
    var validType = "";
    if (data.required) {
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "required:true";
    }
    if (data.editable) {
        htmlOptions += ' type="text"';
    } else {
        htmlOptions += ' type="hidden"';
    }
    if (data.tooltip) {
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "prompt:\'" + data.tooltip + "\'";
    }
    if (data.disabled) {
        htmlOptions += ' disabled="disabled" value="' + $("#" + disabledKey + dataField).val() + '"';
    }
    if (data.readonly) {
        htmlOptions += ' readonly="readonly"';
    }
    if (data.validtype !== 'None') {
        var validTypes = data.validtype.split("^");
        if (validTypes.length === 1) {
            validType = "'" + data.validtype + "'";
        } else {
            for (var validtypeindex = 0; validtypeindex < validTypes.length; validtypeindex++) {
                if (validtypeindex === 0) {
                    validType += "[" + "\'" + validTypes[validtypeindex].replace(/'/g, "\\'") + "\'";
                } else {
                    validType += "," + "\'" + validTypes[validtypeindex].replace(/'/g, "\\'") + "\'";
                }
            }
            if (validType) {
                validType += "]";
            }
        }
        dataoptions += (dataoptions.length > 0 ? ',' : '') + "validType:" + validType;
    }
    if (data.datatype === "Combobox") {
        if (data.required === true) {
            dataoptions = "required:true";
        } else {
            dataoptions = "required:false";
        }
        dataoptions += ",cache:false,multiple:false,editable:false,selectOnNavigation:true,valueField:'value',textField:'text',data:";
        if (data.mapkeys.split(",").length === data.mapvalues.split(",").length) {
            var comboJson = "";
            $.each(data.mapkeys.split(","), function (i, obj) {
                comboJson += "{'text':'" + data.mapvalues.split(",")[i] + "','value':'" + data.mapkeys.split(",")[i] + "'},";
            });
            var jsonData = "[" + comboJson.substring(0, (comboJson.length) - 1) + "]";
            dataoptions += jsonData;// + jsonData + ')');
        }
    }
    switch (data.datatype) {
        case "String":
            element += '<input id="' + dataField + '_index" name="' + formName + '_index" class="easyui-numberspinner"  ' + htmlOptions + ' data-options="' + dataoptions + ',min:0,max:10,width:50"/>&nbsp;&nbsp;<input id="' + dataField + '" name="' + formName + '" class="easyui-textbox" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Number":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-numberbox"  ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "NumberSpinner":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-numberspinner"  ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Date":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-datebox"  ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Time":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-timespinner"  ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "DateTime":
            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-datetimebox" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        case "Combobox":

            element += '<input id="' + dataField + '" name="' + formName + '" class="easyui-combobox" ' + htmlOptions + ' data-options="' + dataoptions + '" />';
            break;
        case "Checkbox":
            element += '<input id="' + dataField + '" name="' + formName + '" type="checkbox" ' + htmlOptions + ' data-options="' + dataoptions + '"/>';
            break;
        default:
    }
    return element;
}

