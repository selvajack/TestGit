Number.prototype.fromCharCode = function () {
    return String.fromCharCode(this);
};

String.prototype.byte = function (val) {
    var a = [];
    for (var i = (val || 0), n = val === 0 ? 0 : this.length - 1; i <= n; i++)
        a.push(this.charCodeAt(i) & 0xFF);
    return a;
};

String.prototype.HiNibble = function (val) {
    var b = this.byte(val);
    var a = [];
    for (var i = 0, n = b.length - 1; i <= n; i++)
        a.push(b[i] >> 4);
    return a;
};

String.prototype.LoNibble = function (val) {
    var b = this.byte(val);
    var a = [];
    for (var i = 0, n = b.length - 1; i <= n; i++)
        a.push(b[i] & 0xF);
    return a;
};

function refreshFirePanelData(neRefId, operationId, subSystemType, subSystemVersion) {
    SingleFirePanelView(neRefId, operationId, subSystemType, subSystemVersion);
}

function refreshFireZoneData(neRefId, operationId, subSystemType, subSystemVersion) {
    SingleFireZonalView(neRefId, operationId, subSystemType, subSystemVersion);
}

function showFirePanelDataFromPush(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neId = neStatusDetls.neId;
    var neName = replyFormat.neName.toLowerCase();
    var operationId = replyFormat.operationId;
    var neRefId = replyFormat.neName.toLowerCase();
    var data = replyFormat.formdata;
    var node = getSelectedNode();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var formattedNEId = $.i18n.prop("NE_STR") + $.i18n.prop("TREE_DELIMITER") + neId;
    var statusBarId = neRefId + "FPS";
    if (formattedNEId === node.id) {
        loadFirePanel(neRefId + "FirePanel", data);
        updateStatusMessage(replyFormat, statusBarId);
    } else {
        dwrPushedDatas[subSystemKey] = replyFormat;
        updateStatusMessage(replyFormat, statusBarId);
    }
}

function showFireZoneDataFromPush(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neRefId = replyFormat.neName.toLowerCase();
    var neId = neStatusDetls.neId;
    var neName = replyFormat.neName.toLowerCase();
    var operationId = replyFormat.operationId;
    var node = getSelectedNode();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var formattedNEId = $.i18n.prop("NE_STR") + $.i18n.prop("TREE_DELIMITER") + neId;
    var statusBarId = neRefId + "FZS";
    if (formattedNEId === node.id) {
        loadFireZoneView(neRefId, replyFormat);
        updateStatusMessage(replyFormat, statusBarId);
    } else {
        dwrPushedDatas[subSystemKey] = replyFormat;
        updateStatusMessage(replyFormat, statusBarId);
    }
}

function loadFirePanel(fpId, data) {
    var clientURL = $.i18n.prop('CLIENT_URL');
    var fireContent = '<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="40%" height="100%" style="overflow:hidden" viewBox="0 0 100 100" preserveAspectRatio="none" zoomAndPan="magnify">' +
        '<g class="firegroup">' +
        '<rect x="0" y="0" width="100" height="100" stroke-width="1" fill="transparent"/>' +
        '<rect x="10" y="5" width="80" height="20" stroke="green" rx="2" ry="2" stroke-width="0.5" fill="transparent"/>' +
        '<text x="50" y="15" alignment-baseline="middle" text-anchor="middle" style="font-size:5px;font-weight:bold;font-style:normal;" stroke="transparent" stroke-width="0">NO FIRE</text>';
    if (data.fireacmainstatus === "12" || data.fireacmainstatus === 12) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/mainsok.gif" preserveAspectRatio="none" x="12" y="30" width="12" height="12" qtip-content="Mains(AC) Status - Mains Normal"/>' +
            '<text x="18" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">AC MAINS' +
            '<tspan x="18" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.fireacmainstatus === "25" || data.fireacmainstatus === 25) {
        fireContent += '<circle class="blinkCircle" cx="18" cy="36" r="8" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/fire/mainsfail.gif" preserveAspectRatio="none" x="12" y="30" width="12" height="12" qtip-content="Mains(AC) Status - Mains Failed"/>' +
            '<text x="18" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">AC MAINS' +
            '<tspan x="18" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.fireacmainstatus === "00" || data.fireacmainstatus === 0) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/mainsok.gif" preserveAspectRatio="none" x="12" y="30" width="12" height="12" qtip-content="Mains(AC) Status - Mains Normal"/>' +
            '<text x="18" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">AC MAINS' +
            '<tspan x="18" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/mainsgray.gif" preserveAspectRatio="none" x="12" y="30" width="12" height="12" qtip-content="Mains(AC) Status - Not Present"/>' +
            '<text x="18" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">AC MAINS' +
            '<tspan x="18" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    }
    if (data.firebatterystatus === "13" || data.firebatterystatus === 13) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/batteryok.gif" preserveAspectRatio="none" x="33" y="30" width="12" height="12" qtip-content="Battery Status - Battery Normal"/>' +
            '<text x="39" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">BATTERY' +
            '<tspan x="39" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.firebatterystatus === "26" || data.firebatterystatus === 26) {
        fireContent += '<circle class="blinkCircle" cx="39" cy="36" r="8" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/fire/batterylow.gif" preserveAspectRatio="none" x="33" y="30" width="12" height="12" qtip-content="Battery Status - Battery Low"/>' +
            '<text x="39" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">BATTERY' +
            '<tspan x="39" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.firebatterystatus === "27" || data.firebatterystatus === 27) {
        fireContent += '<circle class="blinkCircle" cx="39" cy="36" r="8" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/fire/batteryfail.gif" preserveAspectRatio="none" x="33" y="30" width="12" height="12" qtip-content="Battery Status - Battery Failed"/>' +
            '<text x="39" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">BATTERY' +
            '<tspan x="39" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.firebatterystatus === "00" || data.firebatterystatus === 0) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/batteryok.gif" preserveAspectRatio="none" x="33" y="30" width="12" height="12" qtip-content="Battery Status - Battery Normal"/>' +
            '<text x="39" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">BATTERY' +
            '<tspan x="39" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/batterygray.gif" preserveAspectRatio="none" x="33" y="30" width="12" height="12" qtip-content="Battery Status - Not Present"/>' +
            '<text x="39" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">BATTERY' +
            '<tspan x="39" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    }
    if (data.firechargerstatus === "14" || data.firechargerstatus === 14) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/chargerok.gif" preserveAspectRatio="none" x="54" y="30" width="12" height="12" qtip-content="Charger Status - Charger Normal"/>' +
            '<text x="60" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">CHARGER' +
            '<tspan x="60" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.firechargerstatus === "28" || data.firechargerstatus === 28) {
        fireContent += '<circle class="blinkCircle" cx="60" cy="36" r="8" stroke="yellow" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/fire/chargerfail.gif" preserveAspectRatio="none" x="54" y="30" width="12" height="12" qtip-content="Charger Status - Charger Failed"/>' +
            '<text x="60" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">CHARGER' +
            '<tspan x="60" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.firechargerstatus === "00" || data.firechargerstatus === 0) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/chargerok.gif" preserveAspectRatio="none" x="54" y="30" width="12" height="12" qtip-content="Charger Status - Charger Normal"/>' +
            '<text x="60" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">CHARGER' +
            '<tspan x="60" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/chargergray.gif" preserveAspectRatio="none" x="54" y="30" width="12" height="12" qtip-content="Charger Status - Not Present"/>' +
            '<text x="60" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">CHARGER' +
            '<tspan x="60" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    }
    if (data.fireevacuatestatus === "39" || data.fireevacuatestatus === 39) {
        fireContent += '<circle class="blinkCircle" cx="81" cy="36" r="8" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/fire/evacuate.gif" preserveAspectRatio="none" x="75" y="30" width="12" height="12" qtip-content="Evacuate Status - Evacuated"/>' +
            '<text x="81" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">EVACUATE' +
            '<tspan x="81" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.fireevacuatestatus === "11" || data.fireevacuatestatus === 11) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/evacuategray.gif" preserveAspectRatio="none" x="75" y="30" width="12" height="12" qtip-content="Evacuate Status - Normal"/>' +
            '<text x="81" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">EVACUATE' +
            '<tspan x="81" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/evacuategray.gif" preserveAspectRatio="none" x="75" y="30" width="12" height="12" qtip-content="Evacuate Status - Not Present"/>' +
            '<text x="81" y="48" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">EVACUATE' +
            '<tspan x="81" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    }
    if (data.fireackstatus === "41" || data.fireackstatus === 41) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/alarmack.gif" preserveAspectRatio="none" x="12" y="65" width="12" height="12" qtip-content="Acknowledge Status - Acknowledged"/>' +
            '<text x="18" y="81" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">ACK' +
            '<tspan x="18" y="85" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.fireackstatus === "11" || data.fireackstatus === 11) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/alarmackgray.gif" preserveAspectRatio="none" x="12" y="65" width="12" height="12" qtip-content="Acknowledge Status - Normal"/>' +
            '<text x="18" y="81" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">ACK' +
            '<tspan x="18" y="85" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/alarmackgray.gif" preserveAspectRatio="none" x="12" y="65" width="12" height="12" qtip-content="Acknowledge Status - Not Present"/>' +
            '<text x="18" y="81" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">ACK' +
            '<tspan x="18" y="85" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    }
    if (data.firesilencedstatus === "42" || data.firesilencedstatus === 42) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/silenced.gif" preserveAspectRatio="none" x="33" y="65" width="12" height="12" qtip-content="Silenced Status - Silenced"/>' +
            '<text x="39" y="81" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">SILENCED' +
            '<tspan x="39" y="85" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else if (data.firesilencedstatus === "11" || data.firesilencedstatus === 11) {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/silencedgray.gif" preserveAspectRatio="none" x="33" y="65" width="12" height="12" qtip-content="Silenced Status - Normal"/>' +
            '<text x="39" y="81" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">SILENCED' +
            '<tspan x="39" y="85" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    } else {
        fireContent += '<image xlink:href="' + clientURL + '/common/images/fire/silencedgray.gif" preserveAspectRatio="none" x="33" y="65" width="12" height="12" qtip-content="Silenced Status - Not Present"/>' +
            '<text x="39" y="81" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">SILENCED' +
            '<tspan x="39" y="85" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:3px;font-weight:bold;font-style:normal;">STATUS</tspan>' +
            '</text>';
    }
    fireContent += "</g></svg>";
    $("#" + fpId).empty().html(fireContent);
    $(".firegroup").css('stroke', $(".panel-header").css('border-top-color'));
    $(".firegroup").css('stroke-width', '0.3');
    $(".firegroup").css('fill', $(".panel-body").css('color'));
    $("#" + fpId + ' svg image').each(function () {
        $(this).qtip({
            overwrite: true,
            content: {
                text: $(this).attr('qtip-content')
            },
            show: {
                delay: 100
            },
            hide: {
                fixed: true
            }
        });
    });
}

function showFireStatus(neRefId, replyFormat) {
    var clientURL = $.i18n.prop('CLIENT_URL');
    var neName = getSelectedNeName();
    var operationId = replyFormat.operationId;
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var replyFormat1 = dwrPushedDatas[subSystemKey];
    if (replyFormat1 === null || replyFormat1 === "" || replyFormat1 === undefined) {
        replyFormat1 = replyFormat;
    }
    $.each(replyFormat1.rows, function (index, row) {
        var subSystemRecdId = row.firesensorsubsystemrecdid;
        var subSystemId = row.firesensorsubsystemid;
        var deviceStatus = row.firesensordevicestatus;
        var subSystemTypeId = row.firesensorsubsystemtypeid;
        var subSystemName = row.firesensorsubsystemname;
        var buildingName = replyFormat.buildingName;
        var floorName = replyFormat.floorName;
        var tenantName = row.firesensortenantname || "NA";
        var fireIconURL = "";
        var fireIconToolTip = "";
        if (deviceStatus === "1" || deviceStatus === 1) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smokefire.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heatfire.gif';
            }
            fireIconToolTip = '<b>Fire At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        } else if (deviceStatus === "11" || deviceStatus === 11) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smoke.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heat.gif';
            }
            fireIconToolTip = '<b>Fire Cleared At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        }
        $('#' + neRefId + "_" + subSystemRecdId).attr('xlink:href', fireIconURL);
        $('#' + neRefId + "_" + subSystemRecdId).attr('qtip-content', fireIconToolTip);
    });
    $("#" + neRefId + 'FireZone1 svg image').each(function () {
        $(this).qtip({
            overwrite: true,
            content: {
                text: $(this).attr('qtip-content')
            },
            show: {
                delay: 100
            },
            hide: {
                fixed: true
            }
        });
    });
}

function updateFireStatus(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neRefId = replyFormat.neName.toLowerCase();
    var neId = neStatusDetls.neId;
    var neName = replyFormat.neName.toLowerCase();
    var operationId = replyFormat.operationId;
    var node = getSelectedNode();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var formattedNEId = $.i18n.prop("NE_STR") + $.i18n.prop("TREE_DELIMITER") + neId;
    var statusBarId = neRefId + "FZS";
    if (formattedNEId === node.id) {
        showFireStatus(neRefId, replyFormat);
        updateStatusMessage(replyFormat, statusBarId);
    } else {
        dwrPushedDatas[subSystemKey] = replyFormat;
        updateStatusMessage(replyFormat, statusBarId);
    }
}

function updateFireClearedStatus(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neRefId = replyFormat.neName.toLowerCase();
    var neId = neStatusDetls.neId;
    var neName = replyFormat.neName.toLowerCase();
    var operationId = replyFormat.operationId;
    var node = getSelectedNode();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var formattedNEId = $.i18n.prop("NE_STR") + $.i18n.prop("TREE_DELIMITER") + neId;
    var statusBarId = neRefId + "FZS";
    if (formattedNEId === node.id) {
        showFireStatus(neRefId, replyFormat);
        updateStatusMessage(replyFormat, statusBarId);
    } else {
        dwrPushedDatas[subSystemKey] = replyFormat;
        updateStatusMessage(replyFormat, statusBarId);
    }
}

function showFireSensorStatus() {
    var subSystemArray = {};
    var t = null;
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        t = $('#networkTree');
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        t = $('#logicalTree');
    }

    var leafs = [];
    var liftLeafs = [];
    $.map(t.tree('getChildren'), function (node) {
        if (t.tree('isLeaf', node.target)) {
            leafs.push(node);
        }
    });
    $.each(leafs, function (index, leaf) {
        if (leaf.attributes !== null && leaf.attributes !== "" && leaf.attributes !== undefined) {
            if (leaf.attributes.subSystemType !== null && leaf.attributes.subSystemType !== "" && leaf.attributes.subSystemType !== undefined) {
                var subSystemName = leaf.attributes.subSystemType;
                if (subSystemName.toUpperCase() === "LIFT") {
                    liftLeafs.push(leaf);
                    if (!subSystemArray[subSystemName]) {
                        subSystemArray[subSystemName] = 1;
                    } else if (subSystemArray[subSystemName]) {
                        subSystemArray[subSystemName] += 1;
                    }
                }
            }
        }
    });
}

function loadFireZoneView(neRefId, replyFormat) {
    var neName = getSelectedNeName();
    //var loopCardNumber = replyFormat.loopCardNumber;
    var fireContent = '<div id="' + neRefId + 'FireZonePanel" class="firePanel easyui-panel" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'FireZone1" class="' + neRefId + 'FireZone1" style="width:99%;height:99%"></div>' +
        '</div>';
    $("#" + neRefId + "FZSView").empty().html(fireContent);
    var clientURL = $.i18n.prop('CLIENT_URL');
    var fireZoneContent = '<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="100%" height="100%" style="overflow:hidden" viewBox="0 0 100 100" preserveAspectRatio="none" zoomAndPan="magnify">' +
        '<g class="firegroup">';
    var currXPosition = 1;
    var currYPosition = 0;
    $.each(replyFormat.rows, function (index, row) {
        var subSystemRecdId = row.firesensorsubsystemrecdid;
        var subSystemId = row.firesensorsubsystemid;
        var deviceStatus = row.firesensordevicestatus;
        var subSystemTypeId = row.firesensorsubsystemtypeid;
        var subSystemName = row.firesensorsubsystemname;
        var buildingName = replyFormat.buildingName;
        var floorName = replyFormat.floorName;
        var tenantName = row.firesensortenantname || "NA";
        var textXPosition = (currXPosition + 3 / 2);
        var textYPosition = (currYPosition + 7);
        var fireIconURL = "";
        var fireIconToolTip = "";
        var fireText = ("000" + subSystemId).slice(-4);
        if (deviceStatus === "1" || deviceStatus === 1) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smokefire.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heatfire.gif';
            }
            fireIconToolTip = '<b>Fire At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        } else if (deviceStatus === "11" || deviceStatus === 11) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smoke.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heat.gif';
            }
            fireIconToolTip = '<b>No Fire At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        } else if (deviceStatus === "20" || deviceStatus === 20) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smokemissing.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heatmissing.gif';
            }
            fireIconToolTip = '<b>Device Missing At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        } else if (deviceStatus === "21" || deviceStatus === 21) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smokefault.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heatfault.gif';
            }
            fireIconToolTip = '<b>Device Fault At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        } else if (deviceStatus === "22" || deviceStatus === 22) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smokeconflict.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heatconflict.gif';
            }
            fireIconToolTip = '<b>Address Conflict At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        } else if (deviceStatus === "38" || deviceStatus === 38) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smokesupervisory.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heatsupervisory.gif';
            }
            fireIconToolTip = '<b>Supervisory At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        } else if (deviceStatus === "40" || deviceStatus === 40) {
            if (subSystemTypeId === "14" || subSystemTypeId === 14) {
                fireIconURL = clientURL + '/common/images/fire/smokeprealarm.gif';
            } else if (subSystemTypeId === "15" || subSystemTypeId === 15) {
                fireIconURL = clientURL + '/common/images/fire/heatprealarm.gif';
            }
            fireIconToolTip = '<b>Pre Alarm At</b>\n<table><tbody><tr><th>Building Name</th><td>' + buildingName + '</td></tr><tr><th>Floor Name</th><td>' + floorName + '</td></tr><tr><th>NE Name</th><td>' + neName + '</td></tr><tr><th>Subsystem Display Name</th><td>' + subSystemName + '</td></tr><tr><th>Tenant Display Name</th><td>' + tenantName + '</td></tr></tbody></table>';
        }
        fireZoneContent += '<image id="' + neRefId + '_' + subSystemRecdId + '" xlink:href="' + fireIconURL + '" preserveAspectRatio="none" x="' + currXPosition + '" y="' + currYPosition + '" width="3" height="6" qtip-content="' + fireIconToolTip + '"/>' +
            '<text x="' + textXPosition + '" y="' + textYPosition + '" alignment-baseline="middle" text-anchor="middle" style="font-size:1.5px;font-weight:bold;font-style:normal;" stroke="transparent">' + fireText + '</text>';
        currXPosition = currXPosition + 4;
        if (currXPosition > 96) {
            currXPosition = 1;
            currYPosition = currYPosition + 9;
        }
    });
    fireZoneContent += "</g></svg>";
    $("#" + neRefId + 'FireZone1').empty().html(fireZoneContent);
    $(".firegroup").css('stroke', $(".panel-header").css('border-top-color'));
    $(".firegroup").css('stroke-width', '0.3');
    $(".firegroup").css('fill', $(".panel-body").css('color'));
    $("#" + neRefId + 'FireZone1 svg image').each(function () {
        $(this).qtip({
            overwrite: true,
            content: {
                text: $(this).attr('qtip-content')
            },
            show: {
                delay: 100
            },
            hide: {
                fixed: true
            }
        });
    });
}

function getFireDataFromDevice(neRefId, operationId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var data = "";
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var neId = node.id.substring(3);
        var neName = node.text;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemName = node.text;
        var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandler";
        var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceData&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neId=" + neId + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&subSystemId=1&subSystem=Fire&operationType=GET&operationId=" + operationId + "&operationName=FIRE_DATA&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystemVersion=" + subSystemVersion;
        var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
        var replyFormatStr = replyFormat.toString();
        var replyFormatJson = $.trim(replyFormatStr).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/\\"/g, '"').replace(/\\\\"/g, '"').replace(/"{/g, "{").replace(/}"/g, "}");
        data = eval('(' + replyFormatJson + ')');
        updateStatusMessage(data, neRefId + "FPS");
    }
    return data;
}

function dec2hex(i) {
    var result = "0000";
    if (i >= 0 && i <= 15) {
        result = "000" + i.toString(16);
    }
    else if (i >= 16 && i <= 255) {
        result = "00" + i.toString(16);
    }
    else if (i >= 256 && i <= 4095) {
        result = "0" + i.toString(16);
    }
    else if (i >= 4096 && i <= 65535) {
        result = i.toString(16);
    }
    return result;
}

function getFirePanelReadings(neRefId) {
    var statusBarId = neRefId + "FPS";
    var neId = getSelectedNeId();
    var neName = getSelectedNeName();
    var URL = $.i18n.prop('SERVER_URL') + "/FirePanelMgr";
    var parameters = "requestType=DeviceMgr&subRequestType=refreshFirePanelReadings&QueryNum=3240&key=FIRE_PANEL_READING&Parm1=" + neId + "&neName=" + neName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, statusBarId);
    return data;
}

function SingleFirePanelView(neRefId, operationId, subSystemType, subSystemVersion) {
    $("#" + neRefId + "FPSView").block();
    var fireContent = '<div id="' + neRefId + 'FirePanel" class="firePanel easyui-panel" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'FirePanel" class="' + neRefId + 'FirePanel" style="width:99%;height:99%"></div>' +
        '</div>';
    $("#" + neRefId + "FPSView").empty().html(fireContent);
    var neName = getSelectedNeName();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var replyFormat = dwrPushedDatas[subSystemKey];
    if (replyFormat === null || replyFormat === "" || replyFormat === undefined) {
        replyFormat = getFirePanelReadings(neRefId);
    }
    var data = {
        fireacmainstatus: -1,
        firebatterystatus: -1,
        firechargerstatus: -1,
        firenac1status: -1,
        firenac2status: -1,
        fireevacuatestatus: -1,
        fireackstatus: -1,
        firesilencedstatus: -1
    };
    try {
        if (replyFormat.rows.length > 0) {
            data = replyFormat.rows[0];
        }
    } catch (err) {
        //Do Nothing
    }
    loadFirePanel(neRefId + "FirePanel", data);
    $(".firegroup").css('stroke', $(".panel-header").css('border-top-color'));
    $(".firegroup").css('stroke-width', '0.3');
    $(".firegroup").css('fill', $(".panel-body").css('color'));
    $("#" + neRefId + "FPSView").unblock();
}

function getFireZoneReadings(neRefId) {
    var statusBarId = neRefId + "FZS";
    var neId = getSelectedNeId();
    var neName = getSelectedNeName();
    var URL = $.i18n.prop('SERVER_URL') + "/FireSensorMgr";
    var parameters = "requestType=DeviceMgr&subRequestType=refreshFireSensorReadings&QueryNum=3242&key=FIRE_SENSOR_READING&Parm1=" + neId + "&neName=" + neName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, statusBarId);
    return data;
}

function SingleFireZonalView(neRefId, operationId, subSystemType, subSystemVersion) {
    $("#" + neRefId + "FZSView").block();
    var neName = getSelectedNeName();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var replyFormat = dwrPushedDatas[subSystemKey];
    if (replyFormat === null || replyFormat === "" || replyFormat === undefined) {
        replyFormat = getFireZoneReadings(neRefId);
    }
    loadFireZoneView(neRefId, replyFormat);
    $("#" + neRefId + "FZSView").unblock();
}
