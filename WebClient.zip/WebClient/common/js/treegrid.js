function toCallTooltipForTreeGrid(pager) {
    $(pager).find('a.l-btn').each(function () {
        $(this).tooltip('destroy');
    });
    $(pager).find('a.l-btn').each(function () {
        $(this).tooltip({
            content: function () {
                var cc = $(this).find('span.l-btn-icon').attr('class').split(' ');
                var icon = cc[1].split('-')[1];
                var toolTipContent = "";
                switch (icon) {
                    case "first":
                        toolTipContent = "First Page";
                        break;
                    case "prev":
                        toolTipContent = "Previous Page";
                        break;
                    case "next":
                        toolTipContent = "Next Page";
                        break;
                    case "last":
                        toolTipContent = "Last Page";
                        break;
                    case "load":
                        toolTipContent = "Refresh Page";
                        break;
                    case "csv":
                        toolTipContent = "Export As CSV";
                        break;
                    case "excel":
                        toolTipContent = "Export As Excel";
                        break;
                    case "xml":
                        toolTipContent = "Export As XML";
                        break;
                    case "pdf":
                        toolTipContent = "Export As PDF";
                        break;
                    case "add":
                        toolTipContent = "Add";
                        break;
                    case "edit":
                        toolTipContent = "Edit";
                        break;
                    case "remove":
                        toolTipContent = "Delete";
                        break;
                    case "save":
                        toolTipContent = "Update";
                        break;
                    case "copy":
                        toolTipContent = "Copy";
                        break;
                    default:
                        break;
                }
                return toolTipContent;
            }
        });
    });
}
function reloadWithFilterForTreeGrid(parentId, tableId, fitColumns, data) {
    $('#' + tableId).treegrid('loadData', data);
    toCallTooltipForTreeGrid(tableId);
    $('.easyui-searchbox').searchbox();
}

function reloadWithFilterForTreeGrid(parentId, tableId, fitColumns, data) {
    $('#' + tableId).treegrid('loadData', data);
    toCallTooltipForTreeGrid(tableId);
    $('.easyui-searchbox').searchbox();
}

function getTemplateDetails() {
    var neVersion = $('#configNeVersion').combobox('getValue') || -1;
    var agentType = $('#configAgentType').combobox('getValue') || -1;
    var URL = $.i18n.prop('SERVER_URL') + "/getTemplateListUsingAgentTypeAndNeVersion";
    var parameters = "requestType=NEManager&subRequestType=refreshConfigowManager&key=TEMPLATE_DETAILS&agenttype=" + agentType + "&neversion=" + neVersion + "&userName=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    var comboTreeData = JSON.parse(data.treedata.trim());
    $('#configTemplateName').combotreegrid({
        cache: false,
        data: comboTreeData,
        treeField: 'name',
        idField: 'name',
        showFooter: true,
        rownumbers: true,
        fitColumns: true,
        disabled: true,
        panelWidth: 500,
        multiple: true,
        unselectAll: true,
        labelPosition: 'top',
        columns: [[
                {field: 'name', title: 'NE Name', width: '40%'},
                {field: 'templatenames', title: 'Template Name', width: '20%'},
                {field: 'agenttypename', title: 'Agent Type', width: '20%'},
                {field: 'neversion', title: 'NE Version', width: '20%'}
            ]],
        selectOnNavigation: true
    });
    comboboxSearchOnSelect("configTemplateName");
}
/*
function loadTemplateTreeBasedonSelectedRows(neVersion, agentType, templateName) {
    var URL = $.i18n.prop('SERVER_URL') + "/getTemplateListUsingAgentTypeAndNeVersion";
    var parameters = "requestType=DownloadNowManager&subRequestType=refreshDownloadNowManager&key=SOFTWARE_DOWNLOAD_NOW&agenttype=" + agentType + "&neversion=" + neVersion + "&tempdetlname=" + templateName + "&userName=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    var treeData = JSON.parse(data.treedata.trim());
    updateStatusMessage(data, "tempDetailsConfigListView");
    $('#templateConfigNowTable').treegrid({
        cache: false,
        data: treeData,
        treeField: 'name',
        idField: 'id',
        showFooter: true,
        rownumbers: true,
        fitColumns: true,
        searchbox: true,
        checkbox: true,
        unselectAll: true
    });
    $('span.tree-checkbox').removeClass('tree-checkbox1').addClass('tree-checkbox0');
    var pager = $('#templateConfigNowTable').treegrid('getPager');
    pager.pagination({
        total: treeData.length,
        pageSize: Number(20),
        showRefresh: false,
        pageList: [10, 20, 30, 40, 50, 100],
        buttons: [{
                iconCls: 'icon-add',
                handler: function () {
                    var treeData = $('#templateConfigNowTable').treegrid('getCheckedNodes');
                    if (treeData.length !== 0 && treeData.length !== null && treeData.length !== undefined) {
                        var title = $.i18n.prop('ADD_TEMPLATE_CONFIG');
                        var message = $.i18n.prop('ENTER_TEMPLATE_TAG');
                        var label = $.i18n.prop('ENTER_TEMPLATE_TAG');
                        var URL = $.i18n.prop('SERVER_URL') + "/configTemplateManagement";
                        var parentId = "tempDetailsConfigList";
                        var treegridId = "templateConfigNowTable";
                        var dialogContent = '<form id="popUpDialogForm" class="popUpDialogForm" method="post" autocomplete="off">'
                                + '<input type="hidden" id="templateconfigpriority" name="templateconfigpriority" value="0"/>'
                                + '<table><tr><th>Tag</th>'
                                + '<td><input class="easyui-textbox" id="templateconfigtag" name="templateconfigtag" style="width:150px"/></td><tr>'
                                + '<tr><th>Priority</th>'
                                + '<td><input class="easyui-textbox" id="templateconfigpriority" name="templateconfigpriority" style="width:150px"/></td><tr>'
                                + '<tr><th>TTL(in seconds)</th>'
                                + '<td><input class="easyui-numberspinner" id="templateconfigttl" name="templateconfigttl" style="width:150px" required/></td><tr>'
                                + '</table></form>';
                        var requestParams = "requestType=ThreadDetails&subRequestType=addThreadDetails";
                        customAddDataToServer(dialogContent, "Add", title, treegridId, parentId, URL, requestParams);
                    } else {
                        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('CHECK_MSG'), 'info');
                    }
                }
            }]
    });
    $('.easyui-searchbox').searchbox();
}
*/
function customAddDataToServer(formContent, label, title, treegridId, parentId, URL, requestParams) {
    requestParams += "&operationDoneBy=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var parameters = $.deserialize(requestParams);
    $("#popUpDialog").empty().append(formContent);
    var iconClass = "icon-add";
    var iconText = "Add";
    if (label !== "Add") {
        var iconClass = "icon-update";
        var iconText = "Update";
    }
    $('#popUpDialog').dialog({
        cache: false,
        shadow: false,
        model: true,
        width: 500,
        height: 'auto',
        title: title,
        resizable: false,
        buttons: [{
                text: iconText,
                iconCls: iconClass,
                handler: function () {
                    var okBtn = $(this);
                    $('#popUpDialogForm').form('submit', {
                        url: URL,
                        onSubmit: function (param) {
                            var isValid = $('#popUpDialogForm').form('validate');
                            if (isValid) {
                                $(okBtn).linkbutton('disable');
                                if (parameters) {
                                    $.each(parameters, function (key, value) {
                                        if (key !== null && key !== '' && key !== undefined) {
                                            param[key] = value;
                                        }
                                    });
                                }
                                $("#popUpDialogForm input:checkbox").each(function () {
                                    if ($(this).prop('checked') === true) {
                                        $(this).val('1');
                                        param[$(this).attr('name')] = 1;
                                    } else {
                                        $(this).val('0');
                                        param[$(this).attr('name')] = 0;
                                    }
                                });
                                $("#popUpDialogForm input:disabled").each(function () {
                                    var key = $(this).attr('name');
                                    if (key !== null && key !== '' && key !== undefined) {
                                        param[key] = $(this).val();
                                    }
                                });
                                if (treegridId === "templateConfigNowTable") {
                                    var selAgentName = [];
                                    var selTempName = [];
                                    var treeData = $('#' + treegridId).treegrid('getCheckedNodes');
                                    for (i = 0; i < treeData.length; i++) {
                                        if (treeData[i].agenttypename !== "" && treeData[i].agenttypename !== undefined && treeData[i].agenttypename !== null) {
                                            selAgentName.push(treeData[i].agenttypename);
                                            selTempName.push(treeData[i].templatenames);
                                        }
                                    }
                                    param['templateconfigselagentname'] = selAgentName;
                                    param['templateconfigseltemplate'] = selTempName;
                                }
                            }
                            return isValid;
                        },
                        success: function (data) {
//                            if (refreshParams.subRequestType === "refreshAgent") {
//                                var pager = $('#' + parentTableId).datagrid('getPager');
//                                pager.pagination('options').onBeforeRefresh();
//                                                } else {
//                                                    reloadDataFromServer(parentId, datagridId, refreshURL, refreshParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title, deviceAttributes);
//                            }
                            $('#popUpDialog').dialog('close');
                            var replyFormat = eval('(' + data + ')');
                            updateStatusMessage(replyFormat, parentId);
                            //reloadTree();
                        },
                        onLoadError: function () {
                            $('#popUpDialog').dialog('close');
                        }
                    });
                }
            }, {
                text: 'Close',
                iconCls: 'icon-cancel',
                handler: function () {
                    $('#popUpDialog').dialog('close');
                }
            }]
    });
    callEasyuiFunctionForPopUp(treegridId);
    if ($('#templateconfigpriority').length) {
        priorityList('templateconfigpriority');
    }
    $('#popUpDialog').dialog('open');
    $('#popUpDialog').dialog('center');
}
