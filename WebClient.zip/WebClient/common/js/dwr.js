function updateNEState(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neId = $.i18n.prop('NE_STR') + $.i18n.prop('TREE_DELIMITER') + neStatusDetls.neId;
    var neStatus = neStatusDetls.status;
    updateNodeStatus(neId, neStatus);
}

function processGetHandlerNotification(replyFormat) {
    showMeterDataFromPush(replyFormat);
}

function processGetHandlerForSetNotification(replyFormat) {
    getDataForSetFromPush(replyFormat);
}

function processSetHandlerNotification(replyFormat) {
    setDataFromPush(replyFormat);
}

function processFirePanelStatus(replyFormat) {
    showFirePanelDataFromPush(replyFormat);
}

function processLoopCardStatus(replyFormat) {
    showFireZoneDataFromPush(replyFormat);
}

function processFireStatus(replyFormat) {
    updateFireStatus(replyFormat);
}

function processFireClearedStatus(replyFormat) {
    updateFireClearedStatus(replyFormat);
}

function dwrNotification(replyFormatStr) {
    var replyFormatJson = $.trim(replyFormatStr).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/\\\\"/g, '"').replace(/"{/g, "{").replace(/}"/g, "}");
    var replyFormat = eval('(' + replyFormatJson + ')');
    var operationName = replyFormat.operationname;
    if (operationName !== null && operationName !== "" && operationName !== undefined) {
        if (operationName === "addUser_Notification" || operationName === "editUser_Notification" || operationName === "delUser_Notification") {
            updateStatusMessage(replyFormat, "usersList");
        } else if (operationName === "editUserDefaultNePrivileges_Notification") {
            updateStatusMessage(replyFormat, "userDefaultNePrivilegesList");
        } else if (operationName === "editUserGuiPrivileges_Notification") {
            updateStatusMessage(replyFormat, "userGuiPrivilegesList");
        } else if (operationName === "editUserNePrivileges_Notification") {
            updateStatusMessage(replyFormat, "userNePrivilegesList");
        } else if (operationName === "addProfile_Notification" || operationName === "editProfile_Notification" || operationName === "delProfile_Notification") {
            updateStatusMessage(replyFormat, "profileList");
        } else if (operationName === "editAppsInProfiles_Notification") {
            updateStatusMessage(replyFormat, "profileAppsList");
        } else if (operationName === "addBuilding_Notification" || operationName === "delBuilding_Notification") {
            updateStatusMessage(replyFormat, "buildingDetailsList");
        } else if (operationName === "editBuilding_Notification") {
            treeReloadFlag = true;
            updateStatusMessage(replyFormat, "buildingDetailsList");
        } else if (operationName === "addFloor_Notification" || operationName === "delFloor_Notification") {
            updateStatusMessage(replyFormat, "floorDetailsList");
        } else if (operationName === "editFloor_Notification") {
            treeReloadFlag = true;
            updateStatusMessage(replyFormat, "floorDetailsList");
        } else if (operationName === "addGroup_Notification" || operationName === "delGroup_Notification") {
            updateStatusMessage(replyFormat, "groupDetailsList");
        } else if (operationName === "editGroup_Notification") {
            treeReloadFlag = true;
            updateStatusMessage(replyFormat, "groupDetailsList");
        } else if (operationName === "addNe_Notification" || operationName === "editNe_Notification" || operationName === "delNe_Notification") {
            treeReloadFlag = true;
            updateStatusMessage(replyFormat, "neDetailsList");
        } else if (operationName === "addSubSystem_Notification" || operationName === "editSubSystem_Notification" || operationName === "delSubSystem_Notification") {
            treeReloadFlag = true;
            updateStatusMessage(replyFormat, "subSystemDetailsList");
        } else if (operationName === "addTenant_Notification" || operationName === "editTenant_Notification") {
            updateStatusMessage(replyFormat, "tenantDetailsList");
        } else if (operationName === "delTenant_Notification") {
            treeReloadFlag = true;
            updateStatusMessage(replyFormat, "tenantDetailsList");
        } else if (operationName === "addTenantAssociation_Notification" || operationName === "editTenantAssociation_Notification" || operationName === "delTenantAssociation_Notification") {
            treeReloadFlag = true;
            updateStatusMessage(replyFormat, "tenantAssociationList");
        } else if (operationName === "addIpCam_Notification" || operationName === "editIpCam_Notification" || operationName === "delIpCam_Notification" || operationName === "copyIpCam_Notification") {
            ipCamTreeReloadFlag = true;
            updateStatusMessage(replyFormat, "ipCamList");
        } else if (operationName === "editCamAssociation_Notification") {
            ipCamTreeReloadFlag = true;
            updateStatusMessage(replyFormat, "ipCamAsscList");
        } else if (operationName === "NEConnected_Notification" || operationName === "NEDisConnected_Notification") {
            updateNEState(replyFormat);
            updateStatusMessage(replyFormat, "");
        } else if (operationName === "getDeviceData_Notification" || operationName === "getNEData_Notification") {
            processGetHandlerNotification(replyFormat);
        } else if (operationName === "getDeviceDataForSet_Notification" || operationName === "getNEDataForSet_Notification") {
            processGetHandlerForSetNotification(replyFormat);
        } else if (operationName === "setDeviceData_Notification" || operationName === "setNEData_Notification") {
            processSetHandlerNotification(replyFormat);
        } else if (operationName === "FirePanelStatus") {
            processFirePanelStatus(replyFormat);
        } else if (operationName === "LoopcardStatus") {
            processLoopCardStatus(replyFormat);
        } else if (operationName === "NotifyFireAlarm") {
            processFireStatus(replyFormat);
        } else if (operationName === "NotifyFireAlarmCleared") {
            processFireClearedStatus(replyFormat);
        }
    }
    //servertime, status, message, username, data, operationId, operationName
    //addUser, editUser, delUser
    //editUserDefaultNePrivileges
    //editUserGuiPrivileges
    //editUserNePrivileges
    //addProfile, editProfile, delProfile
    //editAppsInProfiles
    //addBuilding, editBuilding, delBuilding
    //addFloor, editFloor, delFloor
    //addGroup, editGroup, delGroup
    //addNe, editNe, delNe
    //addSubSystem, editSubSystem, delSubSystem
    //addTenant, editTenant, delTenant
    //addTenantAssociation, editTenantAssociation, delTenantAssociation
}
