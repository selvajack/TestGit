var gauges = {};
var meterValues = {};
var dwrPushedDatas = {};
var neViews = {};

function enableCombobox(comboboxId) {
    $("#" + comboboxId).combobox('enable');
    $("#" + comboboxId).combobox('enableValidation');
    $("#" + comboboxId).combobox('validate');
}

function disableCombobox(comboboxId) {
    $("#" + comboboxId).combobox('disableValidation');
    $("#" + comboboxId).combobox('validate');
    $("#" + comboboxId).combobox('disable');
}

function enableNumberSpinner(numberSpinnerId) {
    $("#" + numberSpinnerId).numberspinner('enable');
    $("#" + numberSpinnerId).numberspinner('enableValidation');
    $("#" + numberSpinnerId).numberspinner('validate');
}

function disableNumberSpinner(numberSpinnerId) {
    $("#" + numberSpinnerId).numberspinner('disableValidation');
    $("#" + numberSpinnerId).numberspinner('validate');
    $("#" + numberSpinnerId).numberspinner('disable');
}

function getChartMinData(chartData) {
    var minValue = 0;
    if (chartData[0].y !== null) {
        return minValue = chartData[0].y;
    } else {
        for (i = 0; i <= chartData.length - 1; i++) {
            minValue = chartData[i].y;
            if (minValue !== null) {
                return minValue;
                break;
            }
        }
        return minValue = 0;
    }
}

function getChartMaxData(chartData) {
    var maxValue = 0;
    if (chartData[chartData.length - 1].y !== null) {
        return maxValue = chartData[chartData.length - 1].y;
    } else {
        for (i = chartData.length - 1; i >= 0; i--) {
            maxValue = chartData[i].y;
            if (maxValue !== null) {
                return maxValue;
                break;
            }
        }
        return maxValue = 0;
    }
}

function addEnergyComboboxToPanel(comboboxId, energyMeterId) {
    $("#" + comboboxId).combobox({
        url: $.i18n.prop('CLIENT_URL') + $.i18n.prop('ENERGY_UNITS_URL'),
        valueField: 'value',
        textField: 'label',
        cache: false,
        selectOnNavigation: false,
        required: false,
        multiple: false,
        editable: false,
        onChange: function (newValue, oldValue) {
            if (newValue !== null && newValue !== undefined && newValue !== '' && oldValue !== null && oldValue !== undefined && oldValue !== '') {
                var value = meterValues[energyMeterId];
                cummEnergyMeterReading(energyMeterId, value);
            }
        }
    });
    comboboxSearchOnSelect(comboboxId);
}

function addWelcomePageUnitsDetails(neName) {
    var subSystemArray = {};
    var polledData = $.jStorage.get(neName + "DiagPkt");
    if (polledData) {
        if (parseInt(polledData.statusCode) === 0) {
            $.each(polledData.diagData, function () {
                $.each(this, function (key, val) {
                    if (key === "subSystemName") {
                        if (!subSystemArray[val]) {
                            subSystemArray[val] = 1;
                        } else if (subSystemArray[val]) {
                            subSystemArray[val] += 1;
                        }
                    }
                });
            });
        }
    }
    $.each(subSystemArray, function (key, val) {
        var columnId = neName + key.toUpperCase() + "Units";
        $("#" + columnId).html(val);
    });
}

function addUnitDetails(neName, neVersionNumber) {
    var subSystemArray = {};
    var selectedNodeData = getSelectedNodeData();
    if (selectedNodeData !== null && selectedNodeData !== "" && selectedNodeData !== undefined) {
        $(selectedNodeData).each(function (idx, obj) {
            $.each(this.children, function (cindex, cobj) {
                var subSystemName = cobj.attributes.subSystemType;
                if (!subSystemArray[subSystemName]) {
                    subSystemArray[subSystemName] = 1;
                } else if (subSystemArray[subSystemName]) {
                    subSystemArray[subSystemName] += 1;
                }
            });
        });
    }
    var formId = neName.toLowerCase() + "WelcomePageForm";
    var formContent = "";
    var subSystemTypes = neVersionsWithEntityTypeArray[neVersionNumber];
    if (subSystemTypes !== null && subSystemTypes !== undefined && subSystemTypes !== '') {
        $.each(subSystemTypes.split(","), function (index, value) {
            var selectedVal = subSystemArray[value] || 0;
            formContent += "<tr>" +
                    "<th>" + $.i18n.prop(value.replace("EL Measure", "ELM").replace("Inverter", "").replace(/\s+/g, "").toUpperCase() + "_UNITS_LABEL") + "</th>" +
                    "<td>" + selectedVal + "</td>" +
                    "</tr>";
        });
    }
    $("#" + formId + " > table > tbody").empty();
    $("#" + formId + " > table > tbody").append(formContent);
}

function elmPowerGauge(name, value, size) {
    var formattedValue = value;
    var label = $.i18n.prop('POWER_LABEL');
    var min = 0;
    var max = 100;
    var majorTicks = 11;
    if (value >= 1000000) {
        formattedValue = (value / 1000000).toFixed(6);
        label = $.i18n.prop('POWER_LABEL_IN_MW');
    } else if (value >= 1000) {
        formattedValue = (value / 1000).toFixed(4);
        label = $.i18n.prop('POWER_LABEL_IN_KW');
    }
    if (Number(formattedValue) <= 10) {
        max = 10;
    } else if (Number(formattedValue) > 11 && Number(formattedValue) <= 100) {
        max = 100;
    } else if (Number(formattedValue) > 101 && Number(formattedValue) <= 500) {
        max = 500;
    } else if (Number(formattedValue) > 501 && Number(formattedValue) <= 1000) {
        max = 1000;
    }
    var config = {
        size: size,
        label: label,
        min: min,
        max: max,
        majorTicks: majorTicks,
        minorTicks: 5
    };
    gauges[name] = new Gauge(name, config);
    gauges[name].render();
    if (isNaN(formattedValue)) {
        gauges[name].redraw("NA");
    } else {
        gauges[name].redraw(formattedValue);
    }
}

function powerGauge(name, min, max, value, majorTicks, minorTicks, size) {
    var config = {
        size: size,
        label: $.i18n.prop('POWER_LABEL'),
        min: undefined !== min ? min : 0,
        max: undefined !== max ? max : 100,
        majorTicks: majorTicks,
        minorTicks: minorTicks
    };
    gauges[name] = new Gauge(name, config);
    gauges[name].render();
    if (isNaN(value)) {
        gauges[name].redraw("NA");
    } else {
        gauges[name].redraw(value);
    }
}

function voltageGauge(name, min, max, value, majorTicks, minorTicks, size) {
    var config = {
        size: size,
        label: $.i18n.prop('VOLTAGE_LABEL'),
        min: undefined !== min ? min : 0,
        max: undefined !== max ? max : 100,
        majorTicks: majorTicks,
        minorTicks: minorTicks
    };
    gauges[name] = new Gauge(name, config);
    gauges[name].render();
    if (isNaN(value)) {
        gauges[name].redraw("NA");
    } else {
        gauges[name].redraw(value);
    }
}

function currentGauge(name, min, max, value, majorTicks, minorTicks, size) {
    var config = {
        size: size,
        label: $.i18n.prop('CURRENT_LABEL'),
        min: undefined !== min ? min : 0,
        max: undefined !== max ? max : 100,
        majorTicks: majorTicks,
        minorTicks: minorTicks
    };
    gauges[name] = new Gauge(name, config);
    gauges[name].render();
    if (isNaN(value)) {
        gauges[name].redraw("NA");
    } else {
        gauges[name].redraw(value);
    }
}

function cummEnergyMeterReading(cummEnergyMeterId, value) {
    var comboBoxId = $("#" + cummEnergyMeterId).parent().parent().find('div.panel-tool').find('input.easyui-combobox').attr('id');
    var floatFormat = value.toString().split(".");
    var numberCount = floatFormat[0].length;
    var sprintfFormat = "%0" + numberCount + "d";
    if (floatFormat.length > 1) {
        var decimalCount = floatFormat[1].length;
        var total = numberCount + decimalCount;
        sprintfFormat = "%0" + total + "." + decimalCount + "f";
    }
    var formattedValue = sprintf(sprintfFormat, value);
    var canvasContext = document.getElementById(cummEnergyMeterId);
    canvasContext.width = $("#" + cummEnergyMeterId).width();
    canvasContext.height = $("#" + cummEnergyMeterId).height();
    var context = canvasContext.getContext("2d");
    context.fillStyle = '#FFFFFF';
    context.clearRect(0, 0, canvasContext.width, canvasContext.height);
    context.font = "50px bold Arial, sans-serif";
    context.fillStyle = "#000000";
    context.textBaseline = 'middle';
    context.textAlign = "center";
    var x = Math.round(canvasContext.width / 2);
    var y = Math.round(canvasContext.height / 2);
    if (isNaN(formattedValue)) {
        context.fillText("NA", x, y);
    } else {
        var selUnit = $("#" + comboBoxId).combobox('getValue');
        if (selUnit === "kWh") {
            formattedValue = (formattedValue / 1000).toFixed(2);
        } else if (selUnit === "MWh") {
            formattedValue = (formattedValue / 1000000).toFixed(2);
        }
        context.fillText(formattedValue, x, y);
    }
}

function temperatureGauge(name, min, max, value, majorTicks, minorTicks, size) {
    var config = {
        size: size,
        label: $.i18n.prop('TEMPERATURE_LABEL') + "\\u00B0" + "C",
        min: undefined !== min ? min : 0,
        max: undefined !== max ? max : 100,
        majorTicks: majorTicks,
        minorTicks: minorTicks
    };
    gauges[name] = new Gauge(name, config);
    gauges[name].render();
    if (isNaN(value)) {
        gauges[name].redraw("NA");
    } else {
        gauges[name].redraw(value);
    }
}

function batteryStatus(batteryStatusId, value) {
    if ($("#" + batteryStatusId).length) {
        var batteryStatusContent = "";
        if (value === 1 || value === "1") {
            batteryStatusContent = '<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="100%" height="100%" style="overflow:hidden" fill="transparent" viewBox="0 0 100 50" preserveAspectRatio="none" zoomAndPan="magnify">' +
                    '<rect x="25" y="12.5" width="50" height="25" stroke="black" stroke-width="1" fill="#00A000"/>' +
                    '<rect x="75" y="20" width="3" height="10" stroke="black" stroke-width="1" fill="#00A000"/>' +
                    '<text x="50" y="25" alignment-baseline="middle" text-anchor="middle" style="font-size:8px;font-weight:bold;font-family:Battery;" fill="black">&#xE800; Charging</text>' +
                    '</svg>';
        } else if (value === 0 || value === "0") {
            batteryStatusContent = '<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="100%" height="100%" style="overflow:hidden" fill="transparent" viewBox="0 0 100 50" preserveAspectRatio="none" zoomAndPan="magnify">' +
                    '<rect x="25" y="12.5" width="50" height="25" stroke="black" stroke-width="1" fill="#FF7C14"/>' +
                    '<rect x="75" y="20" width="3" height="10" stroke="black" stroke-width="1" fill="#FF7C14"/>' +
                    '<text x="50" y="25" alignment-baseline="middle" text-anchor="middle" style="font-size:8px;font-weight:bold;font-family:Battery;" fill="black">Discharging</text>' +
                    '</svg>';
        } else if (value === 2 || value === "2") {
            batteryStatusContent = '<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="100%" height="100%" style="overflow:hidden" fill="transparent" viewBox="0 0 100 50" preserveAspectRatio="none" zoomAndPan="magnify">' +
                    '<rect x="25" y="12.5" width="50" height="25" stroke="black" stroke-width="1" fill="#BDBDBD"/>' +
                    '<rect x="75" y="20" width="3" height="10" stroke="black" stroke-width="1" fill="#BDBDBD"/>' +
                    '<text x="50" y="25" alignment-baseline="middle" text-anchor="middle" style="font-size:12px;font-weight:bold;font-family:Battery;" fill="black">Idle</text>' +
                    '</svg>';
        } else {
            batteryStatusContent = '<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="100%" height="100%" style="overflow:hidden" fill="transparent" viewBox="0 0 100 50" preserveAspectRatio="none" zoomAndPan="magnify">' +
                    '<rect x="25" y="12.5" width="50" height="25" stroke="black" stroke-width="1" fill="#FFFFFF"/>' +
                    '<rect x="75" y="20" width="3" height="10" stroke="black" stroke-width="1" fill="#FFFFFF"/>' +
                    '<text x="50" y="25" alignment-baseline="middle" text-anchor="middle" style="font-size:12px;font-weight:bold;font-family:Battery;" fill="black">NA</text>' +
                    '</svg>';
        }
        $("#" + batteryStatusId).append(batteryStatusContent);
    }
}

function clearGuageMeter(parentId, childId) {
    if ($("#" + parentId).length) {
        $("#" + parentId).panel('clear');
        $("#" + parentId).append('<span id="' + childId + '"/>');
    }
}

function clearEnergyMeter(parentId, childId) {
    if ($("#" + parentId).length) {
        $("#" + parentId).panel('clear');
        $("#" + parentId).append('<canvas id="' + childId + '"/>');
    }
}

function clearBattery(parentId, childId) {
    if ($("#" + parentId).length) {
        $("#" + parentId).panel('clear');
        $("#" + parentId).append('<div id="' + childId + '" class="battery"></div>');
    }
}

function resizePortal(portalId, width, height) {
    try {
        if ($("#" + portalId).length) {
            //$("#" + portalId).portal('resize', {width: width, height: height});
            $("#" + portalId).portal('resize');
            var calHeight = Math.floor(height - 4);
            var portalReadingId = portalId.replace("Readings", "Reading");
            for (var i = 1; i < 11; i++) {
                if ($("#" + portalReadingId + i).length) {
                    $("#" + portalReadingId + i).height(calHeight);
                }
            }
        }
    } catch (e) {
//Do Nothing
    }
}

function getDataFromDevice(operationName, operationId, subSystemType, subSystemVersion, neRefId) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var data = "";
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var subSystemId = node.attributes.subSystemId;
        var neId = node.attributes.neId;
        var neName = node.attributes.neName;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemName = node.text;
        var subSystemTypeId = node.attributes.subSystemTypeId;
        var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandler";
        var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceData&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neId=" + neId + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&subSystemId=" + subSystemId + "&subSystem=" + subSystemType + "&operationType=GET&operationId=" + operationId + "&operationName=" + operationName + "&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystemVersion=" + subSystemVersion + "&neRefId=" + $.trim(neRefId) + "&subSystemTypeId=" + subSystemTypeId;
        var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
        var replyFormatStr = replyFormat.toString();
        var replyFormatJson = $.trim(replyFormatStr).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/\\"/g, '"').replace(/\\\\"/g, '"').replace(/"{/g, "{").replace(/}"/g, "}");
        data = eval('(' + replyFormatJson + ')');
    }
    return data;
}

function getDeviceDataFromServer(operationName, operationId, subSystemType, subSystemVersion, neRefId) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var data = "";
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var neId = node.attributes.neId;
        var subSystemRecordId = node.attributes.subSystemRecordId;
        var URL = $.i18n.prop('SERVER_URL') + "/getDBHandler";
        var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceData&QueryNum=3218&key=ELM_POLLED_DATA&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&Parm1=" + neId + "&Parm2=" + subSystemRecordId + "&operationType=GET&operationId=" + operationId + "&operationName=" + operationName + "&typeWithVersion=" + typeWithVersion + "&subSystemVersion=" + subSystemVersion + "&neRefId=" + $.trim(neRefId);
        var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
        var replyFormatStr = replyFormat.toString();
        var replyFormatJson = $.trim(replyFormatStr).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/\\"/g, '"').replace(/\\\\"/g, '"').replace(/"{/g, "{").replace(/}"/g, "}");
        data = eval('(' + replyFormatJson + ')');
    }
    return data;
}

function showReadings(operationId, neRefId, type, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var refreshButtonId = neRefId + type + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var formId = neRefId + type + "Form";
    var statusBarId = neRefId + type;
    var replyFormat = getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId + type);
    $("#" + formId).form('clear');
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            var formData = deviceData.data[0];
            if (!$.isEmptyObject(formData)) {
                $('#' + formId).form('load', formData);
                if (formData.sysDate !== null && formData.sysDate !== "" && formData.sysDate !== undefined) {
                    var systemDateTime = formData.sysDate + " 00:00:00";
                    if (formData.sysTime !== null && formData.sysTime !== "" && formData.sysTime !== undefined) {
                        systemDateTime = formData.sysDate + " " + formData.sysTime;
                    }
                    if ($("#" + neRefId + "ReadingDateTime").length) {
                        $("#" + neRefId + "ReadingDateTime").datetimebox('setValue', systemDateTime);
                    }
                }
            }
        }
    } catch (err) {
        $("#" + neRefId + type + "Update").linkbutton('disable');
    }
    updateStatusMessage(replyFormat, statusBarId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + formId).form('options').dirtyFields = [];
    if ($("#" + neRefId + type + "Update").length) {
        $("#" + neRefId + type + "Update").linkbutton('disable');
    }
    $("#" + neRefId + type + "Layout").unblock();
}

/********************************************** Get Handler For Set Operation *****************************************************/
function updateConfigFormData(formId, subSystemKey, replyFormat, statusBarId, neRefId) {
    var updateButtonId = formId.replace("Form", "Update");
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    $("#" + formId).form('clear');
    try {
        var deviceData = $.parseJSON(replyFormat.devicedata);
        if (parseInt(deviceData.statusCode) === 0) {
            var formData = deviceData.data[0];
            if (!$.isEmptyObject(formData)) {
                if (formData.device_sysDate !== null && formData.device_sysDate !== "" && formData.device_sysDate !== undefined) {
                    var systemDateTime = formData.device_sysDate + " 00:00:00";
                    if (formData.device_sysTime !== null && formData.device_sysTime !== "" && formData.device_sysTime !== undefined) {
                        systemDateTime = formData.device_sysDate + " " + formData.device_sysTime;
                    }
                    if ($("#" + neRefId + "SystemDateTime").length) {
                        $("#" + neRefId + "SystemDateTime").datetimebox('setValue', systemDateTime);
                    }
                }
                if (formData.device_ctrlDate !== null && formData.device_ctrlDate !== "" && formData.device_ctrlDate !== undefined) {
                    var ctrlDateTime = formData.device_ctrlDate + " 00:00:00";
                    if (formData.device_ctrlTime !== null && formData.device_ctrlTime !== "" && formData.device_ctrlTime !== undefined) {
                        ctrlDateTime = formData.device_ctrlDate + " " + formData.device_ctrlTime;
                    }
                    if ($("#" + neRefId + "SystemCurrentDateTime").length) {
                        $("#" + neRefId + "SystemCurrentDateTime").textbox('setValue', ctrlDateTime);
                    }
                }
                if (formData.device_controlMode !== null && formData.device_controlMode !== "" && formData.device_controlMode !== undefined) {
                    formData.device_controlMode = formData.device_controlMode.toString().substr(-1);
                }
                $("#" + formId).form('load', formData);
            }
            delete dwrPushedDatas[subSystemKey];
        }
    } catch (e) {
        if ($("#" + updateButtonId).length) {
            $("#" + updateButtonId).linkbutton('disable');
        }
    }
    $("#" + formId).form('options').dirtyFields = [];
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    updateStatusMessage(replyFormat, statusBarId);
}

function getDataForSetFromPush(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neName = neStatusDetls.neName;
    var neId = neStatusDetls.neId;
    var neRefId = $.trim(neStatusDetls.neRefId);
    var operationId = replyFormat.operationid;
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    var formattedNodeId = $.i18n.prop("NE_STR") + $.i18n.prop("TREE_DELIMITER") + neId;
    if (neStatusDetls.subSystemName !== null && neStatusDetls.subSystemName !== "" && neStatusDetls.subSystemName !== undefined) {
        var subSystemType = neStatusDetls.subSystemName;
        var subSystemId = neStatusDetls.subSystemId;
        var subSystemRecordId = neStatusDetls.subSystemRecordId;
        if (subSystemType !== null && subSystemType !== "" && subSystemType !== undefined && subSystemType !== "GOACTRL") {
            if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
                subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
            }
            formattedNodeId = $.i18n.prop("SUB_SYSTEM_STR") + $.i18n.prop("TREE_DELIMITER") + subSystemId;
        }
    }
    var node = getSelectedNode();
    var formId = neRefId + "Form";
    var statusBarId = neRefId;
    if (formattedNodeId === node.id) {
        updateConfigFormData(formId, subSystemKey, replyFormat, statusBarId, neRefId);
    } else {
        dwrPushedDatas[subSystemKey] = replyFormat;
        updateStatusMessage(replyFormat, statusBarId);
    }
}

function getNEData(operationType, operationId, neRefId, type, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var refreshButtonId = neRefId + type + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var node = getSelectedNode();
    var neName = node.text;
    var neVersion = node.attributes.neVersionNumber;
    var typeWithVersion = node.attributes.neVersionNumber;
    var neTypeName = node.attributes.neTypeName;
    var subSystemName = node.text;
    if ($.trim(subSystemType) !== null && $.trim(subSystemType) !== "" && $.trim(subSystemType) !== undefined) {
        typeWithVersion = subSystemType;
        if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
            typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
        }
        subSystemName = subSystemType;
    } else {
        subSystemType = "LCM";
    }
    var agentId = node.attributes.agentId;
    var agentIp = node.attributes.agentIp;
    var agentPort = node.attributes.agentPort;
    var agentUserId = node.attributes.agentUserId;
    var agentMobileNumber = node.attributes.agentMobileNumber;
    var subSystemRecordId = node.attributes.subSystemRecordId;
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var formId = neRefId + type + "Form";
    var statusBarId = neRefId + type;
    var polledData = dwrPushedDatas[subSystemKey];
    if (polledData === null || polledData === "" || polledData === undefined) {
        var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandler";
        var parameters = "requestType=ElectricalMeters&subRequestType=getNEData&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&operationType=" + operationType + "&operationId=" + operationId + "&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystem=" + subSystemType + "&subSystemId=128&operationName=" + operationType + "&neRefId=" + $.trim(neRefId + type) + "&subSystemTypeId=0";
        var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
        var data = eval('(' + replyFormat.replace(/\\\\u0000/g, "") + ')');
        polledData = data;
    }
    updateConfigFormData(formId, subSystemKey, polledData, statusBarId, neRefId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + neRefId + type + "Layout").unblock();
}

function getNEDataForSet(operationType, operationName, operationId, neRefId, type, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var refreshButtonId = neRefId + type + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
//    var updateButtonId = neRefId + type + "Update";
//    if ($("#" + updateButtonId).length) {
//        $("#" + updateButtonId).linkbutton('disable');
//    }
    var node = getSelectedNode();
    var neName = node.text;
    var neVersion = node.attributes.neVersionNumber;
    var neTypeName = node.attributes.neTypeName;
    var typeWithVersion = node.attributes.neVersionNumber;
    var subSystemName = node.text;
    if ($.trim(subSystemType) !== null && $.trim(subSystemType) !== "" && $.trim(subSystemType) !== undefined) {
        typeWithVersion = subSystemType;
        if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
            typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
        }
        subSystemName = subSystemType;
    } else {
        subSystemType = "LCM";
    }
    var subSystemTypeId = 0;
    if (subSystemType === "VFD") {
        subSystemTypeId = 9;
    }
    var agentId = node.attributes.agentId;
    var agentIp = node.attributes.agentIp;
    var agentPort = node.attributes.agentPort;
    var agentUserId = node.attributes.agentUserId;
    var agentMobileNumber = node.attributes.agentMobileNumber;
    var subSystemRecordId = node.attributes.subSystemRecordId;
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var formId = neRefId + type + "Form";
    var statusBarId = neRefId + type;
    var polledData = dwrPushedDatas[subSystemKey];
    if (polledData === null || polledData === "" || polledData === undefined) {
        var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandlerForSet";
        var parameters = "requestType=ElectricalMeters&subRequestType=getNEDataForSet&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&operationType=" + operationType + "&operationId=" + operationId + "&operationName=" + operationName + "&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystem=" + subSystemType + "&subSystemId=128" + "&neRefId=" + $.trim(neRefId + type) + "&subSystemTypeId=" + subSystemTypeId;
        var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
        var data = eval('(' + replyFormat.replace(/\\\\u0000/g, "") + ')');
        polledData = data;
    }
    updateConfigFormData(formId, subSystemKey, polledData, statusBarId, neRefId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + neRefId + type + "Layout").unblock();
}

function getDataFromDeviceForSet(operationName, operationId, neRefId, type, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var refreshButtonId = neRefId + type + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var subSystemId = node.attributes.subSystemId;
        var neId = node.attributes.neId;
        var neName = node.attributes.neName;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemRecordId = node.attributes.subSystemRecordId;
        var subSystemTypeId = node.attributes.subSystemTypeId;
        var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
        if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
            subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
        }
        var formId = neRefId + type + "Form";
        var statusBarId = neRefId + type;
        var polledData = dwrPushedDatas[subSystemKey];
        if (polledData === null || polledData === "" || polledData === undefined) {
            var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandlerForSet";
            var subSystemName = node.text;
            var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceDataForSet&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neId=" + neId + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&subSystemId=" + subSystemId + "&subSystem=" + subSystemType + "&operationType=GET&operationId=" + operationId + "&operationName=" + operationName + "&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystemVersion=" + subSystemVersion + "&neRefId=" + $.trim(neRefId + type) + "&subSystemTypeId=" + subSystemTypeId;
            var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
            var data = eval('(' + replyFormat + ')');
            polledData = data;
        }
        updateConfigFormData(formId, subSystemKey, polledData, statusBarId, neRefId);
    }
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + neRefId + type + "Layout").unblock();
}
/********************************************** Get Handler For Set Operation *****************************************************/

/********************************************** Set Handler ***********************************************************************/
function setDataFromPush(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neRefId = neStatusDetls.neRefId;
    var statusBarId = neRefId;
    updateStatusMessage(replyFormat, statusBarId);
}

function configureDeviceData(operationName, operationId, neRefId, type, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var message;
    var updateButtonId = neRefId + type + "Update";
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var subSystemId = node.attributes.subSystemId;
        var neId = node.attributes.neId;
        var neName = node.attributes.neName;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemTypeId = node.attributes.subSystemTypeId;
        var formId = neRefId + type + "Form";
        var statusBarId = neRefId + type;
        var URL = $.i18n.prop('SERVER_URL') + "/setHandler";
        var dirtyFields = $("#" + formId).form('options').dirtyFields;
        if (dirtyFields.length > 0) {
            $("#" + formId).form('submit', {
                url: URL,
                onSubmit: function (param) {
                    var isValid = $("#" + formId).form('validate');
                    if (isValid) {
                        param.requestType = 'ElectricalMeters';
                        param.subRequestType = 'setDeviceData';
                        param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                        param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                        param.neId = neId;
                        param.neName = neName;
                        param.neVersion = neVersion;
                        param.neTypeName = neTypeName;
                        param.agentId = agentId;
                        param.ipAddress = agentIp;
                        param.port = agentPort;
                        param.subSystemId = subSystemId;
                        param.subSystem = subSystemType;
                        param.managedObjectInstance = subSystemId;
                        param.managedObjectClass = subSystemType;
                        param.operationName = operationName;
                        param.operationType = 'SET';
                        param.operationId = operationId;
                        param.uniqueId = agentUserId;
                        param.mobileNumber = agentMobileNumber;
                        param.subSystemName = node.text;
                        param.typeWithVersion = typeWithVersion;
                        param.subSystemVersion = subSystemVersion;
                        param.subSystemTypeId = subSystemTypeId;
                        param.managedObjectInstance = subSystemType + "-" + subSystemId;
                        param.neRefId = $.trim(neRefId + type);
                        $("#" + formId + " input.switchbutton-value").each(function () {
                            var selInpName = $(this).attr('name');
                            var selVal = $('input[name="' + selInpName + '"]:checked').val();
                            if (selVal === 1 || selVal === "1" || selVal === "on") {
                                $(this).val(1);
                            } else {
                                $(this).val(0);
                                param[$(this).attr('name')] = 0;
                            }
                        });
                        $("#" + formId + " input:checkbox").each(function () {
                            if ($(this).prop('checked') === true) {
                                $(this).val('1');
                            } else {
                                $(this).val('0');
                                param[$(this).attr('name')] = 0;
                            }
                        });
                        var onOffLoad1Elem = dirtyFields.filter(function (v) {
                            return v.id === neRefId + 'OnOffLoad1';
                        });
                        var onOffLoad2Elem = dirtyFields.filter(function (v) {
                            return v.id === neRefId + 'OnOffLoad2';
                        });
                        if ($(onOffLoad1Elem).attr('id') === neRefId + 'OnOffLoad1' && $(onOffLoad2Elem).attr('id') === neRefId + 'OnOffLoad2') {
                            //Do Nothing
                        } else if ($(onOffLoad1Elem).attr('id') === neRefId + 'OnOffLoad1') {
                            if ($("#" + formId + " input[name='device_onOffNormalLine']").length) {
                                param.device_onOffNormalLine = $("#" + formId + " input[name='device_onOffNormalLine']").val();
                            }
                        } else if ($(onOffLoad2Elem).attr('id') === neRefId + 'OnOffLoad2') {
                            if ($("#" + formId + " input[name='device_onOffEmergencyLine']").length) {
                                param.device_onOffEmergencyLine = $("#" + formId + " input[name='device_onOffEmergencyLine']").val();
                            }
                        }
                    }
                    return isValid;
                },
                success: function (data) {
                    var configStatus = eval('(' + data + ')');
                    updateStatusMessage(configStatus, statusBarId);
                }
            });
        } else {
            message = $.i18n.prop('NO_CHANGE_MESSAGE');
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
        }
    } else {
        message = $.i18n.prop('NO_CHANGE_MESSAGE');
        $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
    }
    /* if ($("#" + updateButtonId).length) {
     $("#" + updateButtonId).linkbutton('enable');
     } */
    $("#" + neRefId + type + "Layout").unblock();
}

function configureNEData(operationType, operationName, operationId, neRefId, type, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var updateButtonId = neRefId + type + "Update";
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    var node = getSelectedNode();
    var neName = node.text;
    var neVersion = node.attributes.neVersionNumber;
    var neTypeName = node.attributes.neTypeName;
    var typeWithVersion = node.attributes.neVersionNumber;
    if ($.trim(subSystemType) !== null && $.trim(subSystemType) !== "" && $.trim(subSystemType) !== undefined) {
        typeWithVersion = subSystemType;
        if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
            typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
        }
    } else {
        subSystemType = "LCM";
    }
    var agentId = node.attributes.agentId;
    var agentIp = node.attributes.agentIp;
    var agentPort = node.attributes.agentPort;
    var agentUserId = node.attributes.agentUserId;
    var agentMobileNumber = node.attributes.agentMobileNumber;
    var formId = neRefId + type + "Form";
    var statusBarId = neRefId + type;
    var dirtyFields = $("#" + formId).form('options').dirtyFields;
    if (dirtyFields.length > 0) {
        var URL = $.i18n.prop('SERVER_URL') + "/setHandler";
        $("#" + formId).form('submit', {
            url: URL,
            onSubmit: function (param) {
                var isValid = $("#" + formId).form('validate');
                if (isValid) {
                    param.requestType = 'ElectricalMeters';
                    param.subRequestType = 'setControllerData';
                    param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                    param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                    param.neName = neName;
                    param.neVersion = neVersion;
                    param.neTypeName = neTypeName;
                    param.agentId = agentId;
                    param.ipAddress = agentIp;
                    param.port = agentPort;
                    param.operationName = operationName;
                    param.operationType = operationType;
                    param.operationId = operationId;
                    param.uniqueId = agentUserId;
                    param.mobileNumber = agentMobileNumber;
                    param.subSystem = subSystemType;
                    param.subSystemId = 128;
                    param.typeWithVersion = typeWithVersion;
                    param.managedObjectInstance = subSystemType + "-128";
                    param.subSystemTypeId = 0;
                    param.neRefId = $.trim(neRefId + type);
                    if ($("#" + neRefId + "EnergyReset").length) {
                        param.device_energyReset = $("#" + neRefId + "EnergyReset").val();
                    }
                    if ($("#" + neRefId + "RestartController").length) {
                        param.device_resetGOA = $("#" + neRefId + "EnergyReset").val();
                    }
                    if (operationName === "CONTROLLER_DATETIME_CONFIGURATION") {
                        if ($("#" + neRefId + "SystemDate").length) {
                            param.device_sysDate = $("#" + neRefId + "SystemDate").val();
                        }
                        if ($("#" + neRefId + "SystemTime").length) {
                            param.device_sysTime = $("#" + neRefId + "SystemTime").val();
                        }
                    }
                }
                return isValid;
            },
            success: function (data) {
                var configStatus = eval('(' + data + ')');
                updateStatusMessage(configStatus, statusBarId);
            }
        });
    } else {
        var message = $.i18n.prop('NO_CHANGE_MESSAGE');
        $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
    }
    /* if ($("#" + updateButtonId).length) {
     $("#" + updateButtonId).linkbutton('enable');
     } */
    $("#" + neRefId + type + "Layout").unblock();
}

function modbusSoftRestart(operationId, neRefId) {
    $.messager.confirm($.i18n.prop('CONFIRM_TITLE'), $.i18n.prop('CONTROLLER_SOFT_RESTART_CONFIRM_MSG'), function (r) {
        if (r) {
            configureNEData('SET', 'CONTROLLER_SOFT_RESTART', operationId, neRefId, 'SRConfig', 'MODBUSCTRL', ' ');
        }
    });
}
/********************************************** Set Handler ***********************************************************************/

/********************************************** GOA Meter Get Operation ***********************************************************/
/********************************************** RBM Meter Get Operation ***********************************************************/
/*function RBMUsageDetails(neRefId) {
 var chartData, min, max;
 var chart = chartArray[neRefId + "SRC"];
 if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
 var totalEnergy = "None";
 if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
 if (chart.series.length > 0) {
 $(chart.series).each(function () {
 if (this.name === "Cumulative Energy") {
 chartData = this.data;
 if (chartData.length > 0) {
 min = getChartMaxData(chartData);
 max = getChartMaxData(chartData);
 totalEnergy = (max - min).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
 }
 }
 });
 }
 }
 $("#" + neRefId + "TotalEnergy").html(totalEnergy);
 } else {
 $("#" + neRefId + "TotalEnergy").html("None");
 }
 }
 
 function showStaticRBMValues(neRefId, calSize) {
 powerGauge(neRefId + "PowerLoad1", 0, 500, "NA", 11, 5, calSize);
 powerGauge(neRefId + "PowerLoad2", 0, 500, "NA", 11, 5, calSize);
 voltageGauge(neRefId + "InstantVoltage", 0, 56, "NA", 15, 5, calSize);
 currentGauge(neRefId + "CurrentLoad1", 0, 15, "NA", 11, 5, calSize);
 currentGauge(neRefId + "CurrentLoad2", 0, 15, "NA", 11, 5, calSize);
 var cummEnergyMeterId = neRefId + "CummEnergy";
 meterValues[cummEnergyMeterId] = "NA";
 cummEnergyMeterReading(cummEnergyMeterId, "NA");
 }
 
 function clearRBMData(neRefId) {
 var powerGauge1PanelId = neRefId + "PowerLoad1Panel";
 var powerGauge1Id = neRefId + "PowerLoad1";
 var powerGauge2PanelId = neRefId + "PowerLoad2Panel";
 var powerGauge2Id = neRefId + "PowerLoad2";
 var currentGauge1PanelId = neRefId + "CurrentLoad1Panel";
 var currentGauge1Id = neRefId + "CurrentLoad1";
 var currentGauge2PanelId = neRefId + "CurrentLoad2Panel";
 var currentGauge2Id = neRefId + "CurrentLoad2";
 var voltageGaugePanelId = neRefId + "InstantVoltagePanel";
 var voltageGaugeId = neRefId + "InstantVoltage";
 var cummEnergyPanelId = neRefId + "CummEnergyPanel";
 var cummEnergyMeterId = neRefId + "CummEnergy";
 clearGuageMeter(powerGauge1PanelId, powerGauge1Id);
 clearGuageMeter(powerGauge2PanelId, powerGauge2Id);
 clearGuageMeter(currentGauge1PanelId, currentGauge1Id);
 clearGuageMeter(currentGauge2PanelId, currentGauge2Id);
 clearGuageMeter(voltageGaugePanelId, voltageGaugeId);
 clearEnergyMeter(cummEnergyPanelId, cummEnergyMeterId);
 }
 
 function clearAndShowRBMDefault(neRefId, calSize) {
 clearRBMData(neRefId);
 showStaticRBMValues(neRefId, calSize);
 }
 
 function updateRBMData(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
 $.blockUI();
 var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
 if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
 subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
 }
 var powerGauge1Id = neRefId + "PowerLoad1";
 var powerGauge2Id = neRefId + "PowerLoad2";
 var currentGauge1Id = neRefId + "CurrentLoad1";
 var currentGauge2Id = neRefId + "CurrentLoad2";
 var voltageGaugeId = neRefId + "InstantVoltage";
 var cummEnergyMeterId = neRefId + "CummEnergy";
 var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
 try {
 var deviceData = replyFormat.devicedata;
 if (parseInt(deviceData.statusCode) === 0) {
 clearRBMData(neRefId);
 var data = deviceData.data[0];
 powerGauge(powerGauge1Id, 0, 500, parseFloat(data.powerLoad1), 11, 5, calSize);
 powerGauge(powerGauge2Id, 0, 500, parseFloat(data.powerLoad2), 11, 5, calSize);
 voltageGauge(voltageGaugeId, 0, 56, parseFloat(data.instantVoltage), 15, 5, calSize);
 currentGauge(currentGauge1Id, 0, 15, parseFloat(data.instantCurrent1), 11, 5, calSize);
 currentGauge(currentGauge2Id, 0, 15, parseFloat(data.instantCurrent2), 11, 5, calSize);
 var cummEnergyVal = parseFloat(data.cummEnergy);
 meterValues[cummEnergyMeterId] = cummEnergyVal;
 cummEnergyMeterReading(cummEnergyMeterId, cummEnergyVal);
 delete dwrPushedDatas[subSystemKey];
 } else {
 clearAndShowRBMDefault(neRefId, calSize, subSystemKey);
 }
 } catch (err) {
 clearAndShowRBMDefault(neRefId, calSize, subSystemKey);
 }
 updateStatusMessage(replyFormat, statusBarId);
 $.unblockUI();
 }*/

function RBMUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var loadEnergy = "None";
        var goaEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Output Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            loadEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                    if (this.name === "GOA Input DC Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            goaEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "LoadEnergy").html(loadEnergy);
        $("#" + neRefId + "GoaEnergy").html(goaEnergy);
    } else {
        $("#" + neRefId + "LoadEnergy").html("None");
        $("#" + neRefId + "GoaEnergy").html("None");
    }
}

function showStaticRBMValues(neRefId, calSize) {
    powerGauge(neRefId + "InstantLoadPower", 0, 500, "NA", 11, 5, calSize);
    powerGauge(neRefId + "InstantGoaPower", 0, 500, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "InstantLoadVoltage", 0, 56, "NA", 15, 5, calSize);
    currentGauge(neRefId + "InstantLoadCurrent", 0, 15, "NA", 11, 5, calSize);
    var loadCummEnergyMeterId = neRefId + "LoadCummEnergy";
    meterValues[loadCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(loadCummEnergyMeterId, "NA");
    var goaCummEnergyMeterId = neRefId + "GoaCummEnergy";
    meterValues[goaCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(goaCummEnergyMeterId, "NA");
}

function clearRBMData(neRefId) {
    var powerGauge1PanelId = neRefId + "InstantLoadPowerPanel";
    var powerGauge1Id = neRefId + "InstantLoadPower";
    var powerGauge2PanelId = neRefId + "InstantGoaPowerPanel";
    var powerGauge2Id = neRefId + "InstantGoaPower";
    var currentGaugePanelId = neRefId + "InstantLoadCurrentPanel";
    var currentGaugeId = neRefId + "InstantLoadCurrent";
    var voltageGaugePanelId = neRefId + "InstantLoadVoltagePanel";
    var voltageGaugeId = neRefId + "InstantLoadVoltage";
    var cummEnergyPanel1Id = neRefId + "LoadCummEnergyPanel";
    var cummEnergyMeter1Id = neRefId + "LoadCummEnergy";
    var cummEnergyPanel2Id = neRefId + "GoaCummEnergyPanel";
    var cummEnergyMeter2Id = neRefId + "GoaCummEnergy";
    clearGuageMeter(powerGauge1PanelId, powerGauge1Id);
    clearGuageMeter(powerGauge2PanelId, powerGauge2Id);
    clearGuageMeter(currentGaugePanelId, currentGaugeId);
    clearGuageMeter(voltageGaugePanelId, voltageGaugeId);
    clearEnergyMeter(cummEnergyPanel1Id, cummEnergyMeter1Id);
    clearEnergyMeter(cummEnergyPanel2Id, cummEnergyMeter2Id);
}

function clearAndShowRBMDefault(neRefId, calSize) {
    clearRBMData(neRefId);
    showStaticRBMValues(neRefId, calSize);
}

function updateRBMData(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var powerGauge1Id = neRefId + "InstantLoadPower";
    var powerGauge2Id = neRefId + "InstantGoaPower";
    var currentGaugeId = neRefId + "InstantLoadCurrent";
    var voltageGaugeId = neRefId + "InstantLoadVoltage";
    var loadCummEnergyMeterId = neRefId + "LoadCummEnergy";
    var goaCummEnergyMeterId = neRefId + "GoaCummEnergy";
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            clearRBMDData(neRefId);
            var data = deviceData.data[0];
            powerGauge(powerGauge1Id, 0, 500, parseFloat(data.instantLoadPower), 11, 5, calSize);
            powerGauge(powerGauge2Id, 0, 500, parseFloat(data.instantGoaPower), 11, 5, calSize);
            voltageGauge(voltageGaugeId, 0, 56, parseFloat(data.instantLoadVoltage), 15, 5, calSize);
            currentGauge(currentGaugeId, 0, 15, parseFloat(data.instantLoadCurrent), 11, 5, calSize);
            var cummEnergyVal1 = parseFloat(data.loadEnergy);
            meterValues[loadCummEnergyMeterId] = cummEnergyVal1;
            cummEnergyMeterReading(loadCummEnergyMeterId, cummEnergyVal1);
            var cummEnergyVal2 = parseFloat(data.goaEnergy);
            meterValues[goaCummEnergyMeterId] = cummEnergyVal2;
            cummEnergyMeterReading(goaCummEnergyMeterId, cummEnergyVal2);
            delete dwrPushedDatas[subSystemKey];
        } else {
            clearAndShowRBMDefault(neRefId, calSize, subSystemKey);
        }
    } catch (err) {
        clearAndShowRBMDefault(neRefId, calSize, subSystemKey);
    }
    updateStatusMessage(replyFormat, statusBarId);
}
/********************************************** RBM Meter Get Operation ***********************************************************/

/********************************************** RBMD Meter Get Operation **********************************************************/
function RBMDUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var loadEnergy = "None";
        var dpauEnergy = "None";
        var goaEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Output Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            loadEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                    if (this.name === "DC Input Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            dpauEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                    if (this.name === "GOA Input DC Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            goaEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "LoadEnergy").html(loadEnergy);
        $("#" + neRefId + "DpauEnergy").html(dpauEnergy);
        $("#" + neRefId + "GoaEnergy").html(goaEnergy);
    } else {
        $("#" + neRefId + "LoadEnergy").html("None");
        $("#" + neRefId + "DpauEnergy").html("None");
        $("#" + neRefId + "GoaEnergy").html("None");
    }
}

function showStaticRBMDValues(neRefId, calSize) {
    powerGauge(neRefId + "InstantLoadPower", 0, 500, "NA", 11, 5, calSize);
    powerGauge(neRefId + "InstantDpauPower", 0, 500, "NA", 11, 5, calSize);
    powerGauge(neRefId + "InstantGoaPower", 0, 500, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "InstantLoadVoltage", 0, 56, "NA", 15, 5, calSize);
    voltageGauge(neRefId + "InstantDpauVoltage", 0, 56, "NA", 15, 5, calSize);
    currentGauge(neRefId + "InstantLoadCurrent", 0, 15, "NA", 11, 5, calSize);
    currentGauge(neRefId + "InstantDpauCurrent", 0, 15, "NA", 11, 5, calSize);
    var loadCummEnergyMeterId = neRefId + "LoadCummEnergy";
    meterValues[loadCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(loadCummEnergyMeterId, "NA");
    var dpauCummEnergyMeterId = neRefId + "DpauCummEnergy";
    meterValues[dpauCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(dpauCummEnergyMeterId, "NA");
    var goaCummEnergyMeterId = neRefId + "GoaCummEnergy";
    meterValues[goaCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(goaCummEnergyMeterId, "NA");
}

function clearRBMDData(neRefId) {
    var powerGauge1PanelId = neRefId + "InstantLoadPowerPanel";
    var powerGauge1Id = neRefId + "InstantLoadPower";
    var powerGauge2PanelId = neRefId + "InstantDpauPowerPanel";
    var powerGauge2Id = neRefId + "InstantDpauPower";
    var powerGauge3PanelId = neRefId + "InstantGoaPowerPanel";
    var powerGauge3Id = neRefId + "InstantGoaPower";
    var currentGauge1PanelId = neRefId + "InstantLoadCurrentPanel";
    var currentGauge1Id = neRefId + "InstantLoadCurrent";
    var currentGauge2PanelId = neRefId + "InstantDpauCurrentPanel";
    var currentGauge2Id = neRefId + "InstantDpauCurrent";
    var voltageGaugePanel1Id = neRefId + "InstantLoadVoltagePanel";
    var voltageGauge1Id = neRefId + "InstantLoadVoltage";
    var voltageGaugePanel2Id = neRefId + "InstantDpauVoltagePanel";
    var voltageGauge2Id = neRefId + "InstantDpauVoltage";
    var cummEnergyPanel1Id = neRefId + "LoadCummEnergyPanel";
    var cummEnergyMeter1Id = neRefId + "LoadCummEnergy";
    var cummEnergyPanel2Id = neRefId + "DpauCummEnergyPanel";
    var cummEnergyMeter2Id = neRefId + "DpauCummEnergy";
    var cummEnergyPanel3Id = neRefId + "GoaCummEnergyPanel";
    var cummEnergyMeter3Id = neRefId + "GoaCummEnergy";
    clearGuageMeter(powerGauge1PanelId, powerGauge1Id);
    clearGuageMeter(powerGauge2PanelId, powerGauge2Id);
    clearGuageMeter(powerGauge3PanelId, powerGauge3Id);
    clearGuageMeter(currentGauge1PanelId, currentGauge1Id);
    clearGuageMeter(currentGauge2PanelId, currentGauge2Id);
    clearGuageMeter(voltageGaugePanel1Id, voltageGauge1Id);
    clearGuageMeter(voltageGaugePanel2Id, voltageGauge2Id);
    clearEnergyMeter(cummEnergyPanel1Id, cummEnergyMeter1Id);
    clearEnergyMeter(cummEnergyPanel2Id, cummEnergyMeter2Id);
    clearEnergyMeter(cummEnergyPanel3Id, cummEnergyMeter3Id);
}

function clearAndShowRBMDDefault(neRefId, calSize) {
    clearRBMDData(neRefId);
    showStaticRBMDValues(neRefId, calSize);
}

function updateRBMDData(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var powerGauge1Id = neRefId + "InstantLoadPower";
    var powerGauge2Id = neRefId + "InstantDpauPower";
    var powerGauge3Id = neRefId + "InstantGoaPower";
    var currentGauge1Id = neRefId + "InstantLoadCurrent";
    var currentGauge2Id = neRefId + "InstantDpauCurrent";
    var voltageGauge1Id = neRefId + "InstantLoadVoltage";
    var voltageGauge2Id = neRefId + "InstantDpauVoltage";
    var loadCummEnergyMeterId = neRefId + "LoadCummEnergy";
    var dpauCummEnergyMeterId = neRefId + "DpauCummEnergy";
    var goaCummEnergyMeterId = neRefId + "GoaCummEnergy";
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            clearRBMDData(neRefId);
            var data = deviceData.data[0];
            powerGauge(powerGauge1Id, 0, 500, parseFloat(data.instantLoadPower), 11, 5, calSize);
            powerGauge(powerGauge2Id, 0, 500, parseFloat(data.instantDpauPower), 11, 5, calSize);
            powerGauge(powerGauge3Id, 0, 500, parseFloat(data.instantGoaPower), 11, 5, calSize);
            voltageGauge(voltageGauge1Id, 0, 56, parseFloat(data.instantLoadVoltage), 15, 5, calSize);
            voltageGauge(voltageGauge2Id, 0, 56, parseFloat(data.instantDpauVoltage), 15, 5, calSize);
            currentGauge(currentGauge1Id, 0, 15, parseFloat(data.instantLoadCurrent), 11, 5, calSize);
            currentGauge(currentGauge2Id, 0, 15, parseFloat(data.instantDpauCurrent), 11, 5, calSize);
            var cummEnergyVal1 = parseFloat(data.loadEnergy);
            meterValues[loadCummEnergyMeterId] = cummEnergyVal1;
            cummEnergyMeterReading(loadCummEnergyMeterId, cummEnergyVal1);
            var cummEnergyVal2 = parseFloat(data.dpauEnergy);
            meterValues[dpauCummEnergyMeterId] = cummEnergyVal2;
            cummEnergyMeterReading(dpauCummEnergyMeterId, cummEnergyVal2);
            var cummEnergyVal3 = parseFloat(data.goaEnergy);
            meterValues[goaCummEnergyMeterId] = cummEnergyVal3;
            cummEnergyMeterReading(goaCummEnergyMeterId, cummEnergyVal3);
            delete dwrPushedDatas[subSystemKey];
        } else {
            clearAndShowRBMDDefault(neRefId, calSize, subSystemKey);
        }
    } catch (err) {
        clearAndShowRBMDDefault(neRefId, calSize, subSystemKey);
    }
    updateStatusMessage(replyFormat, statusBarId);
}
/********************************************** RBMD Meter Get Operation **********************************************************/

/********************************************** DCMeter Meter Get Operation **********************************************************/
function DC_METERUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var loadEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Output Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            loadEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "LoadEnergy").html(loadEnergy);
    } else {
        $("#" + neRefId + "LoadEnergy").html("None");
    }
}

function showStaticDC_MeterValues(neRefId, calSize) {
    powerGauge(neRefId + "InstantLoadPower", 0, 500, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "InstantLoadVoltage", 0, 56, "NA", 15, 5, calSize);
    currentGauge(neRefId + "InstantLoadCurrent", 0, 15, "NA", 11, 5, calSize);
    var loadCummEnergyMeterId = neRefId + "LoadCummEnergy";
    meterValues[loadCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(loadCummEnergyMeterId, "NA");
}

function clearDC_MeterData(neRefId) {
    var powerGauge1PanelId = neRefId + "InstantLoadPowerPanel";
    var powerGauge1Id = neRefId + "InstantLoadPower";
    var currentGauge1PanelId = neRefId + "InstantLoadCurrentPanel";
    var currentGauge1Id = neRefId + "InstantLoadCurrent";
    var voltageGaugePanel1Id = neRefId + "InstantLoadVoltagePanel";
    var voltageGauge1Id = neRefId + "InstantLoadVoltage";
    var cummEnergyPanel1Id = neRefId + "LoadCummEnergyPanel";
    var cummEnergyMeter1Id = neRefId + "LoadCummEnergy";
    clearGuageMeter(powerGauge1PanelId, powerGauge1Id);
    clearGuageMeter(currentGauge1PanelId, currentGauge1Id);
    clearGuageMeter(voltageGaugePanel1Id, voltageGauge1Id);
    clearEnergyMeter(cummEnergyPanel1Id, cummEnergyMeter1Id);
}

function clearAndShowDC_MeterDefault(neRefId, calSize) {
    clearDC_MeterData(neRefId);
    showStaticDC_MeterValues(neRefId, calSize);
}

function updateDC_MeterData(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var powerGauge1Id = neRefId + "InstantLoadPower";
    var currentGauge1Id = neRefId + "InstantLoadCurrent";
    var voltageGauge1Id = neRefId + "InstantLoadVoltage";
    var loadCummEnergyMeterId = neRefId + "LoadCummEnergy";
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            clearDC_MeterData(neRefId);
            var data = deviceData.data[0];
            powerGauge(powerGauge1Id, 0, 500, parseFloat(data.instantLoadPower), 11, 5, calSize);
            voltageGauge(voltageGauge1Id, 0, 56, parseFloat(data.instantLoadVoltage), 15, 5, calSize);
            currentGauge(currentGauge1Id, 0, 15, parseFloat(data.instantLoadCurrent), 11, 5, calSize);
            var cummEnergyVal1 = parseFloat(data.loadEnergy);
            meterValues[loadCummEnergyMeterId] = cummEnergyVal1;
            cummEnergyMeterReading(loadCummEnergyMeterId, cummEnergyVal1);
            delete dwrPushedDatas[subSystemKey];
        } else {
            clearAndShowDC_MeterDefault(neRefId, calSize, subSystemKey);
        }
    } catch (err) {
        clearAndShowDC_MeterDefault(neRefId, calSize, subSystemKey);
    }
    updateStatusMessage(replyFormat, statusBarId);
}
/********************************************** DCMeter Meter Get Operation **********************************************************/


/********************************************** SMC Meter Get Operation ***********************************************************/
function SMCUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalInputEnergy = "None";
        var totalOutputEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Output Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalOutputEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                    if (this.name === "Input Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalInputEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "TotalIEnergy").html(totalInputEnergy);
        $("#" + neRefId + "TotalOEnergy").html(totalOutputEnergy);
    } else {
        $("#" + neRefId + "TotalIEnergy").html("None");
        $("#" + neRefId + "TotalOEnergy").html("None");
    }
}

function showStaticSMCValues(neRefId, calSize) {
    powerGauge(neRefId + "IPower", 0, 6000, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "IVoltage", 0, 300, "NA", 11, 5, calSize);
    currentGauge(neRefId + "ICurrent", 0, 20, "NA", 11, 5, calSize);
    var inputCummEnergyMeterId = neRefId + "ICummEnergy";
    meterValues[inputCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(inputCummEnergyMeterId, "NA");
    powerGauge(neRefId + "OPower", 0, 3000, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "OVoltage", 0, 56, "NA", 15, 5, calSize);
    currentGauge(neRefId + "OCurrent", 0, 60, "NA", 11, 5, calSize);
    var outputCummEnergyMeterId = neRefId + "OCummEnergy";
    meterValues[outputCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(outputCummEnergyMeterId, "NA");
}

function clearSMCData(neRefId) {
    var inputPowerGaugePanelId = neRefId + "IPowerPanel";
    var inputPowerGaugeId = neRefId + "IPower";
    var outputPowerGaugePanelId = neRefId + "OPowerPanel";
    var outputPowerGaugeId = neRefId + "OPower";
    var inputCurrentGaugePanelId = neRefId + "ICurrentPanel";
    var inputCurrentGaugeId = neRefId + "ICurrent";
    var outputCurrentGaugePanelId = neRefId + "OCurrentPanel";
    var outputCurrentGaugeId = neRefId + "OCurrent";
    var inputVoltageGaugePanelId = neRefId + "IVoltagePanel";
    var inputVoltageGaugeId = neRefId + "IVoltage";
    var outputVoltageGaugePanelId = neRefId + "OVoltagePanel";
    var outputVoltageGaugeId = neRefId + "OVoltage";
    var inputCummEnergyPanelId = neRefId + "ICummEnergyPanel";
    var inputCummEnergyMeterId = neRefId + "ICummEnergy";
    var outputCummEnergyPanelId = neRefId + "OCummEnergyPanel";
    var outputCummEnergyMeterId = neRefId + "OCummEnergy";
    clearGuageMeter(inputPowerGaugePanelId, inputPowerGaugeId);
    clearGuageMeter(outputPowerGaugePanelId, outputPowerGaugeId);
    clearGuageMeter(inputCurrentGaugePanelId, inputCurrentGaugeId);
    clearGuageMeter(outputCurrentGaugePanelId, outputCurrentGaugeId);
    clearGuageMeter(inputVoltageGaugePanelId, inputVoltageGaugeId);
    clearGuageMeter(outputVoltageGaugePanelId, outputVoltageGaugeId);
    clearEnergyMeter(inputCummEnergyPanelId, inputCummEnergyMeterId);
    clearEnergyMeter(outputCummEnergyPanelId, outputCummEnergyMeterId);
}

function clearAndShowSMCDefault(neRefId, calSize) {
    clearSMCData(neRefId);
    showStaticSMCValues(neRefId, calSize);
}

function updateSMCData(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var inputPowerGaugeId = neRefId + "IPower";
    var outputPowerGaugeId = neRefId + "OPower";
    var inputCurrentGaugeId = neRefId + "ICurrent";
    var outputCurrentGaugeId = neRefId + "OCurrent";
    var inputVoltageGaugeId = neRefId + "IVoltage";
    var outputVoltageGaugeId = neRefId + "OVoltage";
    var inputCummEnergyMeterId = neRefId + "ICummEnergy";
    var outputCummEnergyMeterId = neRefId + "OCummEnergy";
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            clearSMCData(neRefId);
            var data = deviceData.data[0];
            powerGauge(inputPowerGaugeId, 0, 6000, parseFloat(data.ipPower / 10), 11, 5, calSize);
            voltageGauge(inputVoltageGaugeId, 0, 300, parseFloat(data.ipVoltage), 11, 5, calSize);
            currentGauge(inputCurrentGaugeId, 0, 20, parseFloat(data.ipCurrent / 10), 11, 5, calSize);
            var inputCummEnergyVal = parseFloat(data.ipEnergy);
            meterValues[inputCummEnergyMeterId] = inputCummEnergyVal;
            cummEnergyMeterReading(inputCummEnergyMeterId, inputCummEnergyVal);
            powerGauge(outputPowerGaugeId, 0, 3000, parseFloat(data.power), 11, 5, calSize);
            voltageGauge(outputVoltageGaugeId, 0, 56, parseFloat(data.voltage), 15, 5, calSize);
            currentGauge(outputCurrentGaugeId, 0, 60, parseFloat(data.current), 11, 5, calSize);
            var outputCummEnergyVal = parseFloat(data.energy);
            meterValues[outputCummEnergyMeterId] = outputCummEnergyVal;
            cummEnergyMeterReading(outputCummEnergyMeterId, outputCummEnergyVal);
            delete dwrPushedDatas[subSystemKey];
        } else {
            clearAndShowSMCDefault(neRefId, calSize);
        }
    } catch (err) {
        clearAndShowSMCDefault(neRefId, calSize);
    }
    updateStatusMessage(replyFormat, statusBarId);
}
/********************************************** SMC Meter Get Operation ***********************************************************/

/********************************************** DPAU Meter Get Operation **********************************************************/
function DPAUUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalInputEnergy = "None";
        var totalOutputEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Output Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalOutputEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                    if (this.name === "Input Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalInputEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "TotalIEnergy").html(totalInputEnergy);
        $("#" + neRefId + "TotalOEnergy").html(totalOutputEnergy);
    } else {
        $("#" + neRefId + "TotalIEnergy").html("None");
        $("#" + neRefId + "TotalOEnergy").html("None");
    }
}

function showStaticDPAUValues(neRefId, calSize) {
    powerGauge(neRefId + "IPower", 0, 5000, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "IVoltage", 0, 250, "NA", 11, 5, calSize);
    currentGauge(neRefId + "ICurrent", 0, 20, "NA", 11, 5, calSize);
    var inputCummEnergyMeterId = neRefId + "ICummEnergy";
    meterValues[inputCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(inputCummEnergyMeterId, "NA");
    powerGauge(neRefId + "OPower", 0, 3000, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "OVoltage", 0, 56, "NA", 15, 5, calSize);
    currentGauge(neRefId + "OCurrent", 0, 60, "NA", 11, 5, calSize);
    var outputCummEnergyMeterId = neRefId + "OCummEnergy";
    meterValues[outputCummEnergyMeterId] = "NA";
    cummEnergyMeterReading(outputCummEnergyMeterId, "NA");
}

function clearDPAUData(neRefId) {
    var inputPowerGaugePanelId = neRefId + "IPowerPanel";
    var inputPowerGaugeId = neRefId + "IPower";
    var outputPowerGaugePanelId = neRefId + "OPowerPanel";
    var outputPowerGaugeId = neRefId + "OPower";
    var inputCurrentGaugePanelId = neRefId + "ICurrentPanel";
    var inputCurrentGaugeId = neRefId + "ICurrent";
    var outputCurrentGaugePanelId = neRefId + "OCurrentPanel";
    var outputCurrentGaugeId = neRefId + "OCurrent";
    var inputVoltageGaugePanelId = neRefId + "IVoltagePanel";
    var inputVoltageGaugeId = neRefId + "IVoltage";
    var outputVoltageGaugePanelId = neRefId + "OVoltagePanel";
    var outputVoltageGaugeId = neRefId + "OVoltage";
    var inputCummEnergyPanelId = neRefId + "ICummEnergyPanel";
    var inputCummEnergyMeterId = neRefId + "ICummEnergy";
    var outputCummEnergyPanelId = neRefId + "OCummEnergyPanel";
    var outputCummEnergyMeterId = neRefId + "OCummEnergy";
    clearGuageMeter(inputPowerGaugePanelId, inputPowerGaugeId);
    clearGuageMeter(outputPowerGaugePanelId, outputPowerGaugeId);
    clearGuageMeter(inputCurrentGaugePanelId, inputCurrentGaugeId);
    clearGuageMeter(outputCurrentGaugePanelId, outputCurrentGaugeId);
    clearGuageMeter(inputVoltageGaugePanelId, inputVoltageGaugeId);
    clearGuageMeter(outputVoltageGaugePanelId, outputVoltageGaugeId);
    clearEnergyMeter(inputCummEnergyPanelId, inputCummEnergyMeterId);
    clearEnergyMeter(outputCummEnergyPanelId, outputCummEnergyMeterId);
}

function clearAndShowDPAUDefault(neRefId, calSize) {
    clearDPAUData(neRefId);
    showStaticDPAUValues(neRefId, calSize);
}

function updateDPAUData(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var inputPowerGaugeId = neRefId + "IPower";
    var outputPowerGaugeId = neRefId + "OPower";
    var inputCurrentGaugeId = neRefId + "ICurrent";
    var outputCurrentGaugeId = neRefId + "OCurrent";
    var inputVoltageGaugeId = neRefId + "IVoltage";
    var outputVoltageGaugeId = neRefId + "OVoltage";
    var inputCummEnergyMeterId = neRefId + "ICummEnergy";
    var outputCummEnergyMeterId = neRefId + "OCummEnergy";
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            clearDPAUData(neRefId);
            var data = deviceData.data[0];
            powerGauge(inputPowerGaugeId, 0, 5000, parseFloat(data.ipPower), 11, 5, calSize);
            voltageGauge(inputVoltageGaugeId, 0, 250, parseFloat(data.ipVoltage), 11, 5, calSize);
            currentGauge(inputCurrentGaugeId, 0, 20, parseFloat(data.ipCurrent), 11, 5, calSize);
            var inputCummEnergyVal = parseFloat(data.ipEnergy);
            meterValues[inputCummEnergyMeterId] = inputCummEnergyVal;
            cummEnergyMeterReading(inputCummEnergyMeterId, inputCummEnergyVal);
            powerGauge(outputPowerGaugeId, 0, 3000, parseFloat(data.power), 11, 5, calSize);
            voltageGauge(outputVoltageGaugeId, 0, 56, parseFloat(data.voltage), 15, 5, calSize);
            currentGauge(outputCurrentGaugeId, 0, 60, parseFloat(data.current), 11, 5, calSize);
            var outputCummEnergyVal = parseFloat(data.energy);
            meterValues[outputCummEnergyMeterId] = outputCummEnergyVal;
            cummEnergyMeterReading(outputCummEnergyMeterId, outputCummEnergyVal);
            delete dwrPushedDatas[subSystemKey];
        } else {
            clearAndShowDPAUDefault(neRefId, calSize);
        }
    } catch (err) {
        clearAndShowDPAUDefault(neRefId, calSize);
    }
    updateStatusMessage(replyFormat, statusBarId);
}
/********************************************** DPAU Meter Get Operation **********************************************************/

/********************************************** BCM Meter Get Operation ***********************************************************/
function BCMUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalChargingEnergy = "None";
        var totalDischargingEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Charging Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalChargingEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                    if (this.name === "Discharging Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalDischargingEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "TotalCEnergy").html(totalChargingEnergy);
        $("#" + neRefId + "TotalDCEnergy").html(totalDischargingEnergy);
    } else {
        $("#" + neRefId + "TotalCEnergy").html("None");
        $("#" + neRefId + "TotalDCEnergy").html("None");
    }
}

function showStaticBCMValues(neRefId, calSize) {
    clearBCMData(neRefId);
    powerGauge(neRefId + "Power", 0, 3000, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "Voltage", 0, 56, "NA", 15, 5, calSize);
    currentGauge(neRefId + "Current", 0, 60, "NA", 11, 5, calSize);
    meterValues[neRefId + "CCummEnergy"] = "NA";
    cummEnergyMeterReading(neRefId + "CCummEnergy", "NA");
    meterValues[neRefId + "DCCummEnergy"] = "NA";
    cummEnergyMeterReading(neRefId + "DCCummEnergy", "NA");
    batteryStatus(neRefId + "BatteryStatus", 3);
}

function clearBCMData(neRefId) {
    var powerGaugePanelId = neRefId + "PowerPanel";
    var powerGaugeId = neRefId + "Power";
    var currentGaugePanelId = neRefId + "CurrentPanel";
    var currentGaugeId = neRefId + "Current";
    var voltageGaugePanelId = neRefId + "VoltagePanel";
    var voltageGaugeId = neRefId + "Voltage";
    var cCummEnergyPanelId = neRefId + "CCummEnergyPanel";
    var cCummEnergyMeterId = neRefId + "CCummEnergy";
    var dcCummEnergyPanelId = neRefId + "DCCummEnergyPanel";
    var dcCummEnergyMeterId = neRefId + "DCCummEnergy";
    var batteryPanelId = neRefId + "BatteryStatusPanel";
    var batteryStatusId = neRefId + "BatteryStatus";
    clearGuageMeter(powerGaugePanelId, powerGaugeId);
    clearGuageMeter(currentGaugePanelId, currentGaugeId);
    clearGuageMeter(voltageGaugePanelId, voltageGaugeId);
    clearEnergyMeter(cCummEnergyPanelId, cCummEnergyMeterId);
    clearEnergyMeter(dcCummEnergyPanelId, dcCummEnergyMeterId);
    clearBattery(batteryPanelId, batteryStatusId);
}

function clearAndShowBCMDefault(neRefId, calSize) {
    clearBCMData(neRefId);
    showStaticBCMValues(neRefId, calSize);
}

function updateBCMData(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var powerGaugeId = neRefId + "Power";
    var currentGaugeId = neRefId + "Current";
    var voltageGaugeId = neRefId + "Voltage";
    var cCummEnergyMeterId = neRefId + "CCummEnergy";
    var dcCummEnergyMeterId = neRefId + "DCCummEnergy";
    var batteryStatusId = neRefId + "BatteryStatus";
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            clearBCMData(neRefId);
            var data = deviceData.data[0];
            powerGauge(powerGaugeId, 0, 3000, parseFloat(data.power), 11, 5, calSize);
            voltageGauge(voltageGaugeId, 0, 56, parseFloat(data.voltage), 15, 5, calSize);
            currentGauge(currentGaugeId, 0, 60, parseFloat(data.current), 11, 5, calSize);
            var cCummEnergyVal = parseFloat(data.cummEnergyCharging);
            meterValues[cCummEnergyMeterId] = cCummEnergyVal;
            cummEnergyMeterReading(cCummEnergyMeterId, cCummEnergyVal);
            var dcCummEnergyVal = parseFloat(data.cummEnergyDischarging);
            meterValues[dcCummEnergyMeterId] = dcCummEnergyVal;
            cummEnergyMeterReading(dcCummEnergyMeterId, dcCummEnergyVal);
            if (data.battIdleState === 1 || data.battIdleState === "1") {
                batteryStatus(batteryStatusId, parseFloat(2));
            } else {
                //batteryStatus(batteryStatusId, parseFloat(data.battStatus));
                batteryStatus(batteryStatusId, parseFloat(data.battStatusCD));
            }
            delete dwrPushedDatas[subSystemKey];
        } else {
            clearAndShowBCMDefault(neRefId, calSize);
        }
    } catch (err) {
        clearAndShowBCMDefault(neRefId, calSize);
    }
    updateStatusMessage(replyFormat, statusBarId);
}

function showStaticBCM_002Values(neRefId, calSize) {
    clearBCMData(neRefId);
    powerGauge(neRefId + "CPower", 0, 3000, "NA", 11, 5, calSize);
    powerGauge(neRefId + "DCPower", 0, 3000, "NA", 11, 5, calSize);
    voltageGauge(neRefId + "Voltage", 0, 56, "NA", 15, 5, calSize);
    currentGauge(neRefId + "Current", 0, 60, "NA", 11, 5, calSize);
    meterValues[neRefId + "CCummEnergy"] = "NA";
    cummEnergyMeterReading(neRefId + "CCummEnergy", "NA");
    meterValues[neRefId + "DCCummEnergy"] = "NA";
    cummEnergyMeterReading(neRefId + "DCCummEnergy", "NA");
    batteryStatus(neRefId + "BatteryStatus", 3);
}

function clearBCM_002Data(neRefId) {
    var cPowerGaugePanelId = neRefId + "CPowerPanel";
    var cPowerGaugeId = neRefId + "CPower";
    var dcPowerGaugePanelId = neRefId + "DCPowerPanel";
    var dcPowerGaugeId = neRefId + "DCPower";
    var currentGaugePanelId = neRefId + "CurrentPanel";
    var currentGaugeId = neRefId + "Current";
    var voltageGaugePanelId = neRefId + "VoltagePanel";
    var voltageGaugeId = neRefId + "Voltage";
    var cCummEnergyPanelId = neRefId + "CCummEnergyPanel";
    var cCummEnergyMeterId = neRefId + "CCummEnergy";
    var dcCummEnergyPanelId = neRefId + "DCCummEnergyPanel";
    var dcCummEnergyMeterId = neRefId + "DCCummEnergy";
    var batteryPanelId = neRefId + "BatteryStatusPanel";
    var batteryStatusId = neRefId + "BatteryStatus";
    clearGuageMeter(cPowerGaugePanelId, cPowerGaugeId);
    clearGuageMeter(dcPowerGaugePanelId, dcPowerGaugeId);
    clearGuageMeter(currentGaugePanelId, currentGaugeId);
    clearGuageMeter(voltageGaugePanelId, voltageGaugeId);
    clearEnergyMeter(cCummEnergyPanelId, cCummEnergyMeterId);
    clearEnergyMeter(dcCummEnergyPanelId, dcCummEnergyMeterId);
    clearBattery(batteryPanelId, batteryStatusId);
}

function clearAndShowBCM_002Default(neRefId, calSize) {
    clearBCM_002Data(neRefId);
    showStaticBCM_002Values(neRefId, calSize);
}

function updateBCM_002Data(neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId) {
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var cPowerGaugeId = neRefId + "CPower";
    var dcPowerGaugeId = neRefId + "DCPower";
    var currentGaugeId = neRefId + "Current";
    var voltageGaugeId = neRefId + "Voltage";
    var cCummEnergyMeterId = neRefId + "CCummEnergy";
    var dcCummEnergyMeterId = neRefId + "DCCummEnergy";
    var batteryStatusId = neRefId + "BatteryStatus";
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            clearBCMData(neRefId);
            var data = deviceData.data[0];
            powerGauge(cPowerGaugeId, 0, 3000, parseFloat(data.chargingPower), 11, 5, calSize);
            powerGauge(dcPowerGaugeId, 0, 3000, parseFloat(data.dischargingPower), 11, 5, calSize);
            voltageGauge(voltageGaugeId, 0, 56, parseFloat(data.voltage), 15, 5, calSize);
            currentGauge(currentGaugeId, 0, 60, parseFloat(data.current), 11, 5, calSize);
            var cCummEnergyVal = parseFloat(data.cummEnergyCharging);
            meterValues[cCummEnergyMeterId] = cCummEnergyVal;
            cummEnergyMeterReading(cCummEnergyMeterId, cCummEnergyVal);
            var dcCummEnergyVal = parseFloat(data.cummEnergyDischarging);
            meterValues[dcCummEnergyMeterId] = dcCummEnergyVal;
            cummEnergyMeterReading(dcCummEnergyMeterId, dcCummEnergyVal);
            if (data.battIdleState === 1 || data.battIdleState === "1") {
                batteryStatus(batteryStatusId, parseFloat(2));
            } else {
                batteryStatus(batteryStatusId, parseFloat(data.battStatusCD));
            }
            delete dwrPushedDatas[subSystemKey];
        } else {
            clearAndShowBCM_002Default(neRefId, calSize);
        }
    } catch (err) {
        clearAndShowBCM_002Default(neRefId, calSize);
    }
    updateStatusMessage(replyFormat, statusBarId);
}
/********************************************** BCM Meter Get Operation ***********************************************************/
function showMeterDataFromPush(replyFormat) {
    var neStatusDetls = replyFormat.nestatusdetails;
    var neName = neStatusDetls.neName;
    var subSystemType = neStatusDetls.subSystemType;
    var subSystemId = neStatusDetls.subSystemId;
    var subSystemRecordId = neStatusDetls.subSystemRecordId;
    var subSystemVersion = neStatusDetls.subSystemVersion;
    var operationId = replyFormat.operationid;
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    $("#" + neRefId + "ReadingLayout").block();
    var node = getSelectedNode();
    var formattedSubSystemId = $.i18n.prop("SUB_SYSTEM_STR") + $.i18n.prop("TREE_DELIMITER") + subSystemId;
    var statusBarId = neRefId + "Reading";
    var meterFunction = "update" + typeWithVersion.replace("_150", "").replace("_500", "") + "Data";
    if (formattedSubSystemId === node.id) {
        window[meterFunction](neName, neRefId, subSystemRecordId, replyFormat, statusBarId);
    } else {
        dwrPushedDatas[subSystemKey] = replyFormat;
        updateStatusMessage(replyFormat, statusBarId);
    }
    $("#" + neRefId + "ReadingLayout").unblock();
}

function showMeterData(operationId) {
    var neName = getSelectedNeName();
    var subSystemType = getSelectedSubSystemType();
    var subSystemId = getSelectedSubSystemId();
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    $("#" + neRefId + "ReadingLayout").block();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemId;
    var statusBarId = neRefId + "Reading";
    var replyFormat = dwrPushedDatas[subSystemKey];
    if (replyFormat === null || replyFormat === "" || replyFormat === undefined) {
        replyFormat = getDataFromDevice(subSystemType + "_POLLED_DATA", operationId);
    }
    var meterFunction = "update" + subSystemType.toUpperCase() + "Data";
    if (subSystemType.indexOf($.i18n.prop('NE_DELIMITER')) > -1) {
        meterFunction = "update" + subSystemType.split($.i18n.prop('NE_DELIMITER'))[0] + "Data";
    }
    window[meterFunction](neName, subSystemType, subSystemId, replyFormat, statusBarId);
    $("#" + neRefId + "ReadingLayout").unblock();
}

function showMeterData(operationId, neRefId, subSystemType, subSystemVersion) {
    $("#" + neRefId + "ReadingLayout").block();
    var refreshButtonId = neRefId + "Reading" + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var neName = getSelectedNeName();
    var subSystemRecordId = getSelectedSubSystemRecordId();
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    var statusBarId = neRefId + "Reading";
    var replyFormat = dwrPushedDatas[subSystemKey];
    if (replyFormat === null || replyFormat === "" || replyFormat === undefined) {
        replyFormat = getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion);
    }
    var meterFunction = "update" + typeWithVersion.replace("_150", "").replace("_500", "").replace("_L", "") + "Data";
    window[meterFunction](neName, neRefId, subSystemRecordId, replyFormat, statusBarId, operationId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + neRefId + "ReadingLayout").unblock();
}
/********************************************** GOA Meter Get Operation ***********************************************************/

/********************************************** AC Meter Get Operation ****************************************************/
function ELMUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Cumulative Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                            return;
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "TotalEnergy").html(totalEnergy);
    } else {
        $("#" + neRefId + "TotalEnergy").html("None");
    }
}

function showStaticELMValues(neRefId, calSize) {
    var cummEnergyMeterId = neRefId + "CummEnergy";
    elmPowerGauge(neRefId + "Power", "NA", calSize);
    meterValues[cummEnergyMeterId] = "NA";
    cummEnergyMeterReading(cummEnergyMeterId, "NA");
}

function showELMData(operationId, neRefId, subSystemType, subSystemVersion) {
    var refreshButtonId = neRefId + "ReadingRefresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var statusBarId = neRefId + "Reading";
    var powerGaugePanelId = neRefId + "PowerPanel";
    var powerGaugeId = neRefId + "Power";
    var cummEnergyPanelId = neRefId + "CummEnergyPanel";
    var cummEnergyMeterId = neRefId + "CummEnergy";
    clearGuageMeter(powerGaugePanelId, powerGaugeId);
    clearEnergyMeter(cummEnergyPanelId, cummEnergyMeterId);
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    var replyFormat = getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId + "Reading");
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            var data = deviceData.data[0];
            elmPowerGauge(powerGaugeId, parseFloat(data.wattsTotal), calSize);
            var cummEnergyVal = parseFloat(data.wHReceived);
            meterValues[cummEnergyMeterId] = cummEnergyVal;
            cummEnergyMeterReading(cummEnergyMeterId, cummEnergyVal);
        } else {
            showStaticELMValues(neRefId, calSize);
        }
    } catch (err) {
        showStaticELMValues(neRefId, calSize);
    }
    updateStatusMessage(replyFormat, statusBarId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
}

function SCHNEIDERUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Cumulative Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                            return;
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "TotalEnergy").html(totalEnergy);
    } else {
        $("#" + neRefId + "TotalEnergy").html("None");
    }
}
/********************************************** AC Meter Get Operation ****************************************************/
/*********************************************** Modbus Intermittent Connection Meter ******************************************************/
function showStaticEICValues(neRefId, calSize) {
    var cummEnergyMeterId = neRefId + "CummEnergy";
    elmPowerGauge(neRefId + "Power", "NA", calSize);
    meterValues[cummEnergyMeterId] = "NA";
    cummEnergyMeterReading(cummEnergyMeterId, "NA");
}

function showEICData(operationId, neRefId, subSystemType, subSystemVersion) {
    var refreshButtonId = neRefId + "ReadingRefresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var statusBarId = neRefId + "Reading";
    var powerGaugePanelId = neRefId + "PowerPanel";
    var powerGaugeId = neRefId + "Power";
    var cummEnergyPanelId = neRefId + "CummEnergyPanel";
    var cummEnergyMeterId = neRefId + "CummEnergy";
    clearGuageMeter(powerGaugePanelId, powerGaugeId);
    clearEnergyMeter(cummEnergyPanelId, cummEnergyMeterId);
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    var replyFormat = getDeviceDataFromServer(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId + "Reading");
    try {
        if (parseInt(replyFormat.statusCode) === 0) {
            var data = replyFormat.formdata;
            elmPowerGauge(powerGaugeId, parseFloat(data.acmeterpower), calSize);
            var cummEnergyVal = parseFloat(data.acmeterenergy);
            meterValues[cummEnergyMeterId] = cummEnergyVal;
            cummEnergyMeterReading(cummEnergyMeterId, cummEnergyVal);
        } else {
            showStaticEICValues(neRefId, calSize);
        }
    } catch (err) {
        showStaticEICValues(neRefId, calSize);
    }
    updateStatusMessage(replyFormat, statusBarId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
}
/*********************************************** Modbus Intermittent Connection Meter ******************************************************/

/********************************************** GOA Metere Set Operation **********************************************************/
function setOverVoltage(overVoltageId, voltageId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + overVoltageId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + overVoltageId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 1,
        precision: 2,
        editable: false,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue && newValue !== '' && newValue !== null && newValue !== undefined) {
                var voltOptions = $("#" + voltageId).numberspinner('options');
                setVoltage(voltageId, voltOptions.min, newValue);
            }

        }
    });
    if (prvValue) {
        $("#" + overVoltageId).numberspinner('setValue', prvValue);
    }
}

function setUnderVoltage(underVoltageId, voltageId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + underVoltageId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + underVoltageId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: false,
        onChange: function (newValue, oldValue) {
            if (newValue !== oldValue && newValue !== '' && newValue !== null && newValue !== undefined) {
                var voltOptions = $("#" + voltageId).numberspinner('options');
                setVoltage(voltageId, newValue, voltOptions.max);
            }
        }
    });
    if (prvValue) {
        $("#" + underVoltageId).numberspinner('setValue', prvValue);
    }
}

function setVoltage(voltageId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + voltageId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + voltageId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: false
    });
    if (prvValue) {
        $("#" + voltageId).numberspinner('setValue', prvValue);
    }
}

function setCurrent(currentId, min, max) {
    $("#" + currentId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: false
    });
}
/********************************************** GOA Metere Set Operation **********************************************************/

/********************************************** BTU Meter Get Operation ***********************************************************/
function showStaticBTUValues(neRefId, calSize) {
    var volumetricFlowRateId = neRefId + "VolumetricFlowRate";
    var netHeatRateId = neRefId + "NetHeatRate";
    var flowTotalId = neRefId + "FlowTotal";
    var netHeatTotalId = neRefId + "NetHeatTotal";
    /* var flowTotal32bitId = neRefId + "FlowTotal32bit";
     var netHeatTotal32bitId = neRefId + "NetHeatTotal32bit"; */
    temperatureGauge(neRefId + "InletTemp", 0, 100, 30.0, 11, 5, calSize);
    temperatureGauge(neRefId + "OutletTemp", 0, 100, 31.0, 11, 5, calSize);
    meterValues[volumetricFlowRateId] = parseFloat("100.0");
    cummEnergyMeterReading(volumetricFlowRateId, parseFloat("100.0"));
    meterValues[netHeatRateId] = parseFloat("0010.0");
    cummEnergyMeterReading(netHeatRateId, parseFloat("0010.0"));
    meterValues[flowTotalId] = parseFloat("0000010.0");
    cummEnergyMeterReading(flowTotalId, parseFloat("0000010.0"));
    meterValues[netHeatTotalId] = parseFloat("0000001.0");
    cummEnergyMeterReading(netHeatTotalId, parseFloat("0000001.0"));
}

function showBTUSubSystemData() {
    var neName = getSelectedNeName();
    var subSystemType = getSelectedSubSystemType();
    var subSystemId = getSelectedSubSystemId();
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    var inletTempId = neRefId + "InletTemp";
    var outletTempId = neRefId + "OutletTemp";
    var volumetricFlowRateId = neRefId + "VolumetricFlowRate";
    var netHeatRateId = neRefId + "NetHeatRate";
    var flowTotalId = neRefId + "FlowTotal";
    var netHeatTotalId = neRefId + "NetHeatTotal";
    /*var flowTotal32bitId = neRefId + "FlowTotal32bit";
     var netHeatTotal32bitId = neRefId + "NetHeatTotal32bit"; */
    var calSize = Math.round(($("#" + neRefId + "Readings").height() / 3));
    try {
        var deviceData = getDataFromDevice();
        if (parseInt(deviceData.statusCode) === 0) {
            var data = deviceData.data[0];
            temperatureGauge(inletTempId, 0, 100, parseFloat(data.inletTemp), 11, 5, calSize);
            temperatureGauge(outletTempId, 0, 100, parseFloat(data.outletTemp), 11, 5, calSize);
            var volumetricFlowRateVal = parseFloat(data.volumetricFlowRate);
            meterValues[volumetricFlowRateId] = volumetricFlowRateVal;
            cummEnergyMeterReading(volumetricFlowRateId, volumetricFlowRateVal);
            var netHeatRateVal = parseFloat(data.netHeatRate);
            meterValues[netHeatRateId] = netHeatRateVal;
            cummEnergyMeterReading(netHeatRateId, netHeatRateVal);
            var flowTotalVal = parseFloat(data.flowTotal);
            meterValues[flowTotalId] = flowTotalVal;
            cummEnergyMeterReading(flowTotalId, flowTotalVal);
            var netHeatTotalVal = parseFloat(data.netHeatTotal);
            meterValues[netHeatTotalId] = netHeatTotalVal;
            cummEnergyMeterReading(netHeatTotalId, netHeatTotalVal);
        } else {
            showStaticBTUValues(neRefId, calSize);
        }
    } catch (err) {
        showStaticBTUValues(neRefId, calSize);
    }
}
/********************************************** BTU Meter Get Operation ***********************************************************/

/************************************************* Report Operation ***************************************************************/
/************************************************* Cascademic Report Operation ****************************************************/
function GASUsageDetails() {
    var neName = getSelectedNeName();
    var subSystemType = getSelectedSubSystemType();
    var subSystemId = getSelectedSubSystemId();
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    var rowCount = $("#" + neRefId + "SRD").datagrid('getRows').length || 0;
    if (rowCount > 0) {
        var rowMin = $("#" + neRefId + "SRD").datagrid('getRows')[rowCount - 1];
        var rowMax = $("#" + neRefId + "SRD").datagrid('getRows')[0];
        var flowTotalizer = (rowMax.casgastotaliser - rowMin.casgastotaliser).toFixed(2) + " " + $.i18n.prop('GAS_FLOW_TOTALIZER_UNIT');
        $("#" + neRefId + "FlowTotalizer").html(flowTotalizer);
    } else {
        $("#" + neRefId + "FlowTotalizer").html("None");
    }
}

function WaterUsageDetails() {
    var neName = getSelectedNeName();
    var subSystemType = getSelectedSubSystemType();
    var subSystemId = getSelectedSubSystemId();
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    var rowCount = $("#" + neRefId + "SRD").datagrid('getRows').length || 0;
    if (rowCount > 0) {
        var rowMin = $("#" + neRefId + "SRD").datagrid('getRows')[rowCount - 1];
        var rowMax = $("#" + neRefId + "SRD").datagrid('getRows')[0];
        var flowTotalizer = (rowMax.caswtrtotaliser - rowMin.caswtrtotaliser).toFixed(2) + " " + $.i18n.prop('WATER_FLOW_TOTALIZER_UNIT');
        $("#" + neRefId + "FlowTotalizer").html(flowTotalizer);
    } else {
        $("#" + neRefId + "FlowTotalizer").html("None");
    }
}

function refreshCASStatData() {
    var neName = getSelectedNeName();
    var subSystemType = getSelectedSubSystemType();
    var subSystemTypeMod = subSystemType.toUpperCase();
    var subSystemId = getSelectedSubSystemId();
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    var energyFunction = subSystemType + "UsageDetails";
    if (subSystemType.indexOf($.i18n.prop('NE_DELIMITER')) > -1) {
        energyFunction = subSystemType.split($.i18n.prop('NE_DELIMITER'))[0] + "UsageDetails";
    }
    if ($("#" + neRefId + "SRForm").form('validate')) {
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemId&Parm13=" + neRefId + "SRStartTime&Parm14=" + neRefId + "SREndTime";
        getChartDataFromServer(subSystemTypeMod + "_STATISTICS_DATA", neRefId + "SRC", neRefId + "SRCT", subSystemTypeMod + "_STATS_CHARTDATA", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "SRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        if (typeof window[energyFunction] === "function") {
            window[energyFunction]();
        }
    }
}
/************************************************* Cascademic Report Operation ****************************************************/
function refreshStatData(neRefId, subSystemType, subSystemVersion) {
    $.blockUI();
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var energyFunction = subSystemType.replace("_150", "").replace("_500", "").replace("_L", "") + "UsageDetails";
    if ($("#" + neRefId + "SRForm").form('validate')) {
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "SRStartTime&Parm14=" + neRefId + "SREndTime";
        getChartDataFromServer(typeWithVersion + "_STATISTICS_DATA", neRefId + "SRC", subSystemType + "_STATS_CHARTDATA", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "SRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        if (typeof window[energyFunction] === "function") {
            window[energyFunction](neRefId);
        }
    }
    $.unblockUI();
}

/************************************************* Inverter Report Operation ***************************************************************/
function refreshInverterStatData() {
    $.blockUI();
    var neName = getSelectedNeName();
    var subSystemType = getSelectedSubSystemType();
    var subSystemTypeMod = subSystemType.replace(/\s+/g, "").toUpperCase();
    var subSystemId = getSelectedSubSystemId();
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    if ($("#" + neRefId + "SRForm").form('validate')) {
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemId&Parm13=" + neRefId + "SRStartTime&Parm14=" + neRefId + "SREndTime";
        getChartDataFromServer(subSystemTypeMod + "_STATS_DATA", neRefId + "SRC", subSystemTypeMod + "_STATS_CHARTDATA", 3301, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "SRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
    }
    $.unblockUI();
}

function refreshInverterNEStatData(neName) {
    $.blockUI();
    var neNameMod = neName.toLowerCase();
    if ($("#" + neNameMod + "NESForm").form('validate')) {
        var additionalReqParams = "Parm11=" + neNameMod + "NESNeId&Parm12=" + neNameMod + "NESStartTime&Parm13=" + neNameMod + "NESEndTime";
        getChartDataFromServer("SUMMARY_REPORT", neNameMod + "NESC", "SUMMARY_CHARTDATA", 3301, "", "", additionalReqParams);
    }
    $.unblockUI();
}

function refreshKacoStatData() {
    $.blockUI();
    var neName = getSelectedNeName();
    var subSystemType = getSelectedSubSystemType();
    var subSystemTypeMod = subSystemType.replace(/\s+/g, "").toUpperCase();
    var subSystemId = getSelectedSubSystemId();
    var neRefId = neName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.toLowerCase();
    if ($("#" + neRefId + "SRForm").form('validate')) {
        var additionalReqParams = "Parm11=" + neRefId + "SubSystemId&Parm12=" + neRefId + "SRStartTime&Parm13=" + neRefId + "SREndTime";
        if (subSystemId === "8" || subSystemId === "9" || subSystemId === "12") {
            getChartDataFromServer(subSystemTypeMod + "_STRING_STATISTICS_DATA", neRefId + "SRC", subSystemTypeMod + "_STATS_CHARTDATA", 3301, "", "", additionalReqParams);
        } else if (subSystemId === "10" || subSystemId === "11") {
            getChartDataFromServer(subSystemTypeMod + "_STATISTICS_DATA", neRefId + "SRC", subSystemTypeMod + "_STATS_CHARTDATA", 3301, "", "", additionalReqParams);
        } else {
            getChartDataFromServer(subSystemTypeMod + "_STATS_DATA", neRefId + "SRC", subSystemTypeMod + "_STATS_CHARTDATA", 3301, "", "", additionalReqParams);
        }
        var pager = $("#" + neRefId + "SRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
    }
    $.unblockUI();
}
/************************************************* Inverter Report Operation ***************************************************************/
function scrollVerticalCenter(id) {
    var scrollableDivJ = $("#" + id);
    scrollableDivJ.scrollTop("1000000"); //scroll to max
    var scrollHeight = scrollableDivJ.prop("scrollHeight");
    var diff = (scrollHeight - scrollableDivJ.scrollTop()) / 2;
    var middle = scrollHeight / 2 - diff;
    scrollableDivJ.scrollTop(middle);
}

function scrollHorizontalCenter(id) {
    var scrollableDivJ = $("#" + id);
    scrollableDivJ.scrollLeft("1000000"); //scroll to max
    var scrollWidth = scrollableDivJ.prop("scrollWidth");
    var diff = (scrollWidth - scrollableDivJ.scrollLeft()) / 2;
    var middle = scrollWidth / 2 - diff;
    scrollableDivJ.scrollLeft(middle);
}

function getMICDataFromDB() {
    var data = "";
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var Id = node.id;
        var neId = Id.substring(3);
        var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
        var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceData&QueryNum=4011&key=ELM_POLLED_DATA&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&Parm1=" + neId + "&operationType=GET";
        var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
        data = eval('(' + replyFormat + ')');
    }
    return data;
}

function getDGMode(keyWithEnum) {
    var key = keyWithEnum.toString().split('').pop();
    var modeKey = $.i18n.prop('DG_MODE_KEYS');
    var modeValues = $.i18n.prop('DG_MODE_VALUES').split(",");
    var modeKeyValues = {};
    $.each(modeKey.split(","), function (index, item) {
        modeKeyValues[item] = modeValues[index];
    });
    return modeKeyValues[key];
}

function getDGState(key) {
    var stateKey = $.i18n.prop('DG_STATE_KEYS');
    var stateValues = $.i18n.prop('DG_STATE_VALUES').split(",");
    var stateKeyValues = {};
    $.each(stateKey.split(","), function (index, item) {
        stateKeyValues[item] = stateValues[index];
    });
    return stateKeyValues[key];
}

function loadNEStatusDetails() {
    $.blockUI();
    var selectedNode = "";
    var treeId = "";
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        treeId = "networkTree";
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        treeId = "logicalTree";
    }
    var neName = getSelectedNeName();
    neName = neName.replace(/\s+/g, "").toLowerCase();
    var neStatusId = neName.replace(/\s+/g, "").toLowerCase() + "NeStatus";
    var toolTipContent = {};
    $jit.ST.Plot.NodeTypes.implement({
        'stroke-rect': {
            'render': function (node, canvas) {
                var width = node.getData('width'),
                        height = node.getData('height'),
                        pos = this.getAlignedPos(node.pos.getc(true), width, height),
                        posX = pos.x + width / 2,
                        posY = pos.y + height / 2;
                this.nodeHelper.rectangle.render('fill', {x: posX, y: posY}, width, height, canvas);
                this.nodeHelper.rectangle.render('stroke', {x: posX, y: posY}, width, height, canvas);
            }
        }
    });
    var parentWidth = $("#" + neName + "NESView").width();
    var parentHeight = $("#" + neName + "NESView").height();
    $("#" + neStatusId).empty();
    var st = new $jit.ST({
        injectInto: neStatusId, //id of viz container element
        type: '2D', //'3D'
        width: 5000,
        height: 5000,
        constrained: false,
        levelsToShow: 2, //set max levels to show. Useful when used with the request method for requesting trees of specific depth 
        offsetX: 0,
        offsetY: parentHeight / 3,
        transition: $jit.Trans.Quart.easeInOut,
        levelDistance: 50,
        orientation: 'top',
        align: 'center',
        Navigation: {//enable panning
            enable: true,
            panning: true, //true, 'avoid nodes'
            zooming: 20 //false, 20
        },
        Node: {//set node and edge styles set overridable=true for styling individual nodes or edges
            type: 'stroke-rect',
            overridable: true,
            autoHeight: false,
            autoWidth: false,
            width: 100,
            height: 40,
            align: 'center',
            CanvasStyles: {//canvas specific styles
                fillStyle: '#FFFFFF',
                strokeStyle: '#49B6F1',
                lineWidth: 2
            }
        },
        Edge: {
            type: 'bezier',
            overridable: true,
            color: '#000',
            lineWidth: 1,
            CanvasStyles: {
                shadowColor: '#ccc',
                shadowBlur: 10
            }
        },
        Label: {
            style: 'bold',
            size: '12px',
            color: '#000'
        },
        onCreateLabel: function (label, node) { //This method is called on DOM label creation. Use this method to add event handlers and styles to your node.
            label.id = node.id;
            if (node.data !== null && node.data !== "" && node.data !== undefined) {
                if (node.data.type !== null && node.data.type !== "" && node.data.type !== undefined) {
                    if (node.data.type === "Sub-System-Data") {
                        label.innerHTML = node.name;
                    } else {
                        label.innerHTML = '<span class="node-label">' + node.name + '</span>';
                    }
                }
            } else {
                label.innerHTML = node.name;
            }
            //label.innerHTML = node.name;
            label.onclick = function () {
                //st.onClick(node.id);
            };
            var style = label.style; //set label styles
            //style.cursor = 'pointer';
            style.color = '#000';
            style.fontSize = '12px';
            style.fontWeight = 'bold';
            style.textAlign = 'center';
        },
        onPlaceLabel: function (label, node) {
            var style = label.style;
            style.width = node.getData('width') + 'px';
            style.height = node.getData('height') + 'px';
        },
        onAfterPlotNode: function (node) {
            if (node.data.$color !== undefined && node.data.$color !== null && node.data.$color !== "") {
                node.setCanvasStyle('strokeStyle', node.data.$color);
            }
            var nodeId = node.id;
            if (node.data !== null && node.data !== "" && node.data !== undefined) {
                if (node.data.type !== null && node.data.type !== "" && node.data.type !== undefined) {
                    if (node.data.type === "NE" || node.data.type === "Sub-System") {
                        var titleContent = '<table>' +
                                '<tbody>' +
                                '<tr>' +
                                '<th>Status </th>' +
                                '<td>' + node.data.status + '</td>' +
                                '</tr>' +
                                '</tbody>' +
                                '</table>';
                        toolTipContent[nodeId] = titleContent;
                    }
                }
            }
        },
        onAfterPlotLine: function (adj) {
            if (adj.nodeTo.data.$color !== undefined && adj.nodeTo.data.$color !== null && adj.nodeTo.data.$color !== "") {
                adj.data.$color = adj.nodeTo.data.$color;
                adj.data.$lineWidth = 1;
            }
            //if (adj.nodeFrom.data.$color !== undefined && adj.nodeFrom.data.$color !== null && adj.nodeFrom.data.$color !== "") {
            //    adj.data.$color = adj.nodeFrom.data.$color;
            //    adj.data.$lineWidth = 1;
            //}
        },
        onComplete: function () {
            $("#" + neStatusId + " div.node").each(function () {
                var nodeId = $(this).attr('id');
                if (!$("#" + nodeId).attr("title")) {
                    $("#" + nodeId).attr('title', toolTipContent[nodeId]);
                    $("#" + nodeId).tooltip();
                }
            });
        }
    });
    if (treeId !== undefined && treeId !== null && treeId !== "") {
        selectedNode = $('#' + treeId).tree('getSelected');
        if (selectedNode !== undefined && selectedNode !== null && selectedNode !== "") {
            if (selectedNode.attributes !== undefined && selectedNode.attributes !== null && selectedNode.attributes !== "") {
                if (selectedNode.attributes.type === "Sub-System") {
                    selectedNode = $('#' + treeId).tree('getParent', selectedNode.target);
                }
            }
            var selectedNodeData = $('#' + treeId).tree('getData', selectedNode.target);
            var jitNode = {};
            if (selectedNodeData.attributes !== undefined && selectedNodeData.attributes !== null && selectedNodeData.attributes !== "") {
                var selNeVersion = selectedNodeData.attributes.neVersionNumber;
                var data = {
                    rows: [],
                    total: 0
                };
                /*if (selNeVersion.indexOf("MIC") > -1) {
                 data = getMICDataFromDB();
                 } else */
                if (selNeVersion.indexOf("VIC") > -1 || selNeVersion.indexOf("MIC") > -1) {
                    //Do Nothing
                } else {
                    var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getAllSubSystemData";
                    var parameters = "requestType=ElectricalMeters&subRequestType=getAllSubSystemData&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neName=" + getSelectedNeName() + "&key=ALL_METER_DATA";
                    var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
                    data = eval('(' + replyFormat + ')');
                }
                $(selectedNodeData).each(function (idx, obj) {
                    var children = [];
                    jitNode.id = obj.id.toString();
                    jitNode.name = obj.text.toString();
                    jitNode.class = "NENode";
                    jitNode.data = obj.attributes;
                    if (obj.attributes.status !== undefined && obj.attributes.status !== null && obj.attributes.status !== "") {
                        if (obj.attributes.status === "Success") {
                            jitNode.data.$color = "#00A000";
                        } else if (obj.attributes.status === "Failure") {
                            jitNode.data.$color = "#CC0033";
                        } else {
                            jitNode.data.$color = "#CEE7EA";
                            jitNode.data.status = "Indeterminate";
                        }
                    }
                    $.each(this.children, function (cindex, cobj) {
                        var cNode = {};
                        cNode.id = cobj.text.toString().replace(/ /g, '') + "-" + cobj.id.toString();
                        cNode.name = cobj.text.toString();
                        cNode.class = "SubSystemNode";
                        cNode.data = cobj.attributes;
                        cNode.children = [];
                        if (cobj.attributes.subSystemStatus !== undefined && cobj.attributes.subSystemStatus !== null && cobj.attributes.subSystemStatus !== "") {
                            if (cobj.attributes.subSystemStatus === 0 || cobj.attributes.subSystemStatus === "0" || cobj.attributes.subSystemStatus === "Success") {
                                cNode.data.$color = "#00A000";
                                cNode.data.status = "Success";
                            } else if (cobj.attributes.subSystemStatus === 1 || cobj.attributes.subSystemStatus === "1" || cobj.attributes.subSystemStatus === "Failure") {
                                cNode.data.$color = "#CC0033";
                                cNode.data.status = "Failure";
                            } else {
                                cNode.data.$color = "#CEE7EA";
                                cNode.data.status = "Indeterminate";
                            }
                        }
                        if (data.rows.length > 0) {
                            $.each(data.rows, function (index, row) {
                                var dataNode = {};
                                dataNode.id = obj.text.toString() + "-" + cobj.text.toString() + "-" + cobj.attributes.subSystemId;
                                dataNode.name = cobj.text.toString();
                                dataNode.class = "DataNode";
                                var subSystemTypeMod = cobj.attributes.subSystemType.replace("EL Measure", "ELM");
                                if (row.subSystemId === cobj.attributes.subSystemId && row.subSystemType === subSystemTypeMod) {
                                    dataNode.data = row;
                                    dataNode.data.type = "Sub-System-Data";
                                    var nodeName = '<table cellspacing="2"><tbody>';
                                    if (row.subSystemName === "Solar") {
                                        nodeName += '<tr><th>Peak Power</th><td>' + row.solarpower + ' (W)</td></tr>';
                                        nodeName += '<tr><th>Energy</th><td>' + row.solarenergy + ' (Wh)</td></tr>';
                                    }
                                    if (row.subSystemName === "Grid") {
                                        nodeName += '<tr><th>Peak Power</th><td>' + row.gridpower + ' (W)</td></tr>';
                                        nodeName += '<tr><th>Energy</th><td>' + row.gridenergy + ' (Wh)</td></tr>';
                                    }
                                    if (row.subSystemName === "Battery") {
                                        if (row.batterystate === 0 || row.batterystate === "0") {
                                            nodeName += '<tr><th>Current State</th><td>Discharging</td></tr>';
                                        } else if (row.batterystate === 1 || row.batterystate === "1") {
                                            nodeName += '<tr><th>Current State</th><td>Charging</td></tr>';
                                        } else if (row.batterystate === 2 || row.batterystate === "2") {
                                            nodeName += '<tr><th>Current State</th><td>Idle</td></tr>';
                                        } else {
                                            nodeName += '<tr><th>Current State</th><td>NA</td></tr>';
                                        }
                                        nodeName += '<tr><th>Charging Energy</th><td>' + row.batterychargingenergy + ' (Wh)</td></tr>';
                                        nodeName += '<tr><th>Discharging Energy</th><td>' + row.batterydischargingenergy + ' (Wh)</td></tr>';
                                    }
                                    if (row.subSystemName === "DG") {
                                        nodeName += '<tr><th>Power</th><td>' + row.totalPower + ' (W)</td></tr>';
                                        nodeName += '<tr><th>Energy</th><td>' + row.realEnergy + ' (MWh)</td></tr>';
                                        nodeName += '<tr><th>Mode</th><td>' + getDGMode(row.controlMode) + '</td></tr>';
                                        nodeName += '<tr><th>State</th><td>' + getDGState(row.stateDisplay) + '</td></tr>';
                                    }
                                    if (row.subSystemName === "OG") {
                                        nodeName += '<tr><th>Power</th><td>' + row.activePower + ' (W)</td></tr>';
                                        nodeName += '<tr><th>Energy</th><td>' + (row.activeEnergy / 1000000) + ' (MWh)</td></tr>';
                                    }
                                    $.each(row, function (key, value) {
                                        if (key === "vfdReadingFreq") {
                                            nodeName += '<tr><th>Frequency</th><td>' + value + ' (Hz)</td></tr>';
                                        } else if (key === "vfdReadingPower") {
                                            nodeName += '<tr><th>Power</th><td>' + value + ' (KW)</td></tr>';
                                        } else if (key === "vfdReadingRetAirtemp") {
                                            nodeName += '<tr><th>Return Air</th><td>' + value + ' (°C)</td></tr>';
                                        } else if (key === "vavReadingVavstatus") {
                                            if (value === "0" || value === 0) {
                                                nodeName += '<tr><th>Status</th><td>OFF</td></tr>';
                                            } else {
                                                nodeName += '<tr><th>Status</th><td>ON</td></tr>';
                                            }
                                        } else if (key === "vavReadingSettemp") {
                                            nodeName += '<tr><th>Set Temp.</th><td>' + value + ' (°C)</td></tr>';
                                        } else if (key === "vavReadingAmbtemp") {
                                            nodeName += '<tr><th>Ambient Temp.</th><td>' + value + ' (°C)</td></tr>';
                                        } else if (key === "wHReceived") {
                                            nodeName += '<tr><th>Energy</th><td>' + (value / 1000) + ' (kWh)</td></tr>';
                                        } else if (key === "wattsTotal") {
                                            nodeName += '<tr><th>Power</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "power") {
                                            nodeName += '<tr><th>Power</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "powerLoad1") {
                                            nodeName += '<tr><th>Emergency Line Power</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "powerLoad2") {
                                            nodeName += '<tr><th>Normal Line Power</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "instantLoadPower") {
                                            nodeName += '<tr><th>Power</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "instantDpauPower") {
                                            nodeName += '<tr><th>Power From Local Grid</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "instantGoaPower") {
                                            nodeName += '<tr><th>Power From Inv.Less 2500</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "measuredPower") {
                                            nodeName += '<tr><th>Power</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "measuredCurrent") {
                                            nodeName += '<tr><th>Current</th><td>' + value + ' (A)</td></tr>';
                                        } else if (key === "measuredVoltage") {
                                            nodeName += '<tr><th>Voltage</th><td>' + value + ' (V)</td></tr>';
                                        } else if (key === "totalActivePower") {
                                            nodeName += '<tr><th>Power</th><td>' + value + ' (W)</td></tr>';
                                        } else if (key === "forwardActiveEnergy") {
                                            nodeName += '<tr><th>Energy</th><td>' + (value / 1000) + ' (kWh)</td></tr>';
                                        } else if (key === "activeEnergyDelivered") {
                                            nodeName += '<tr><th>Energy</th><td>' + (value / 1000) + ' (kWh)</td></tr>';
                                        }
                                    });
                                    nodeName += '</tbody></table>';
                                    dataNode.name = nodeName;
                                    dataNode.data.$width = 175;
                                    dataNode.data.$height = 110;
                                    if (cobj.attributes.subSystemStatus !== undefined && cobj.attributes.subSystemStatus !== null && cobj.attributes.subSystemStatus !== "") {
                                        if (cobj.attributes.subSystemStatus === 0 || cobj.attributes.subSystemStatus === "0" || cobj.attributes.subSystemStatus === "Success") {
                                            dataNode.data.$color = "#00A000";
                                            dataNode.data.status = "Success";
                                        } else if (cobj.attributes.subSystemStatus === 1 || cobj.attributes.subSystemStatus === "1" || cobj.attributes.subSystemStatus === "Failure") {
                                            dataNode.data.$color = "#CC0033";
                                            dataNode.data.status = "Failure";
                                        } else {
                                            dataNode.data.$color = "#CEE7EA";
                                            dataNode.data.status = "Indeterminate";
                                        }
                                    }
                                    if (data.rows.length > 0) {
                                        cNode.data.$color = "#00A000";
                                        cNode.data.status = "Success";
                                        cNode.children.push(dataNode);
                                    }
                                    return false;
                                }
                            });
                        }
                        children.push(cNode);
                    });
                    jitNode.children = children;
                });
                st.loadJSON(jitNode); //load json data
                st.compute(); //compute node positions and layout
                st.geom.translate(new $jit.Complex(-200, 0), "current"); //optional: make a translation of the tree
                st.onClick(st.root); //emulate a click on the root node.
                //$("#" + neName + "NESView").scrollLeft(300);
                //$("#" + neName + "NESView").scrollTop(parentHeight / 2);
                scrollVerticalCenter(neName + "NESView");
                scrollHorizontalCenter(neName + "NESView");
                neViews[neName + "NESView"] = st;
            }
        }
    }
    $.unblockUI();
}

function showVFDData(operationId, type, neRefId, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var refreshButtonId = neRefId + type + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var updateButtonId = neRefId + type + "Update";
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var replyFormat = "";
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var subSystem = subSystemType;
        var subSystemId = "128";
        var neId = node.attributes.neId;
        var neName = node.attributes.neName;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemName = node.text;
        var subSystemTypeId = node.attributes.subSystemTypeId;
        var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandler";
        var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceData&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neId=" + neId + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&subSystemId=" + subSystemId + "&subSystem=" + subSystem + "&operationType=GET&operationId=" + operationId + "&operationName=VFD_POLLED_DATA&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystemVersion=" + subSystemVersion + "&subSystemTypeId=" + subSystemTypeId;
        replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
        var replyFormatStr = replyFormat.toString();
        var replyFormatJson = $.trim(replyFormatStr).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/\\"/g, '"').replace(/\\\\"/g, '"').replace(/"{/g, "{").replace(/}"/g, "}");
        replyFormat = eval('(' + replyFormatJson + ')');
    }
    var formId = neRefId + type + "Form";
    var statusBarId = neRefId + type;
    $("#" + formId).form('clear');
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            var data = deviceData.data[0];
            if (!$.isEmptyObject(data)) {
                $('#' + formId).form('load', data);
            }
        }
    } catch (err) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    updateStatusMessage(replyFormat, statusBarId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + formId).form('options').dirtyFields = [];
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    $("#" + neRefId + type + "Layout").unblock();
}

function showVFDAndVAVData(operationId, type, neRefId, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var refreshButtonId = neRefId + type + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var updateButtonId = neRefId + type + "Update";
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    var formId = neRefId + type + "Form";
    var statusBarId = neRefId + type;
    var replyFormat = getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId + type);
    $("#" + formId).form('clear');
    try {
        var deviceData = replyFormat.devicedata;
        if (parseInt(deviceData.statusCode) === 0) {
            var data = deviceData.data[0];
            if (!$.isEmptyObject(data)) {
                $('#' + formId).form('load', data);
            }
        }
    } catch (err) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    updateStatusMessage(replyFormat, statusBarId);
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $("#" + formId).form('options').dirtyFields = [];
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    $("#" + neRefId + type + "Layout").unblock();
}

function refreshVFDVAVStatData(neRefId) {
    if ($("#" + neRefId + "SRForm").form('validate')) {
        $.blockUI();
        var refreshButtonId = neRefId + "SRRefresh";
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('disable');
        }
        var additionalReqParams = "Parm1=" + neRefId + "NESNeId&Parm2=" + neRefId + "SRFieldName&Parm3=" + neRefId + "SRStartTime&Parm4=" + neRefId + "SREndTime&Parm5=" + neRefId + "GDT&Parm6=" + neRefId + "TN&Parm7=" + neRefId + "SRSubSysName&Parm8=" + neRefId + "TAG";
        var URL = $.i18n.prop('SERVER_URL') + "/getGraphDataFromDB";
        getChartDataFromServerUsingURL(URL, "VAV_STATISTICS_DATA", neRefId + "SRC", "VAV_STATS_DATA", "3225", additionalReqParams);
        var tableURL = $.i18n.prop('CLIENT_URL') + "/common/jsp/tablefw.jsp";
        var parameters = {};
        parameters.parentId = neRefId + "SRDV";
        parameters.tableId = neRefId + "SRD";
        parameters.URL = $.i18n.prop('SERVER_URL') + "/getTableDataFromDB";
        parameters.parameters = "requestType=ElectricalMeters&subRequestType=refreshVAVStatsData&QueryNum=3225&key=VAV_STATS_DATA&exportType=SUB_SYSTEMS_DATA";
        parameters.additionalReqParams = "Parm1=" + neRefId + "NESNeId&Parm2=" + neRefId + "SRFieldName&Parm3=" + neRefId + "SRStartTime&Parm4=" + neRefId + "SREndTime&Parm5=" + neRefId + "TDT&Parm6=" + neRefId + "TN&Parm7=" + neRefId + "SRSubSysName&Parm8=" + neRefId + "TAG";
        parameters.fitColumns = false;
        parameters.actionType = "Export";
        parameters.pagesize = "VAV_STATS_DATA_PAGESIZE";
        parameters.pagelist = "VAV_STATS_DATA_PAGELIST";
        loadJSPFileIntoDiv(tableURL, parameters, neRefId + "SRDV");
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('enable');
        }
        $.unblockUI();
    }
}

function refreshVFDSystemParametersData(neRefId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    if ($("#" + neRefId + "SPRForm").form('validate')) {
        $.blockUI();
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "SPRStartTime&Parm14=" + neRefId + "SPREndTime";
        getChartDataFromServer(typeWithVersion + "_SYSTEM_PARAMETERS_DATA", neRefId + "SPRC", subSystemType + "_SYSTEM_PARAMS_DATA", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "SPRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        $.unblockUI();
    }
}

function refreshVFDBtuAndPowerData(neRefId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    if ($("#" + neRefId + "BPRForm").form('validate')) {
        $.blockUI();
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "BPRStartTime&Parm14=" + neRefId + "BPREndTime";
        getChartDataFromServer(typeWithVersion + "_BTU_AND_POWER_DATA", neRefId + "BPRC", subSystemType + "_BTU_AND_POWER_DATA", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "BPRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        $.unblockUI();
    }
}

function rangeSelectorInput(startDateTimeId, endDateTimeId, refreshButtonId, selectedRange) {
    setStartAndEndDateTimeBasedInput(startDateTimeId, endDateTimeId, selectedRange);
    setTimeout(function () {
        $("#" + refreshButtonId).trigger("click");
    }, 100);
}

function setStartAndEndDateTimeBasedInput(startDateTimeId, endDateTimeId, selectedRange) {
    var dateTimeFormat = $.i18n.prop('DATETIME_FORMAT');
    var sd = new Date();
    var ed = new Date();
    switch (selectedRange.toLowerCase()) {
        case "1d" :
            sd.setDate(sd.getDate() - 1);
            break;
        case "3d" :
            sd.setDate(sd.getDate() - 3);
            break;
        case "7d" :
            sd.setDate(sd.getDate() - 7);
            break;
        case "15d" :
            sd.setDate(sd.getDate() - 15);
            break;
        case "1m" :
            sd.setMonth(sd.getMonth() - 1);
            break;
        case "3m" :
            sd.setMonth(sd.getMonth() - 3);
            break;
        case "6m" :
            sd.setMonth(sd.getMonth() - 6);
            break;
        case "1y" :
            sd.setMonth(sd.getMonth() - 12);
            break;
        case "mtd" :
            sd = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
            break;
        case "ytd" :
            sd = new Date(new Date().getFullYear(), 0, 1);
            break;
        default:
            sd = new Date();
    }
    var startTime = jQuery.format.date(sd, dateTimeFormat).split(" ")[0] + " 00:00";
    var endTime = jQuery.format.date(ed, dateTimeFormat).split(" ")[0] + " 23:59";
    $("#" + startDateTimeId).datetimebox('setValue', startTime);
    $("#" + endDateTimeId).datetimebox('setValue', endTime);
}

function refreshGOAInputStatData(neRefId, formId) {
    if ($("#" + formId).form('validate')) {
        $.blockUI();
        var refreshButtonId = neRefId + "ISRRefresh";
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('disable');
        }
        if ($("#" + neRefId + "ISRC").length) {
            var additionalReqParams = "Parm1=" + neRefId + "NESNeId&Parm2=" + neRefId + "ISRStartTime&Parm3=" + neRefId + "ISREndTime";
            getChartDataFromServer("INVERTERLESS_2400_INPUT_STATISTICS_DATA", neRefId + "ISRC", "GOA_INPUT_STATS_DATA", 3228, "", "", additionalReqParams);
        }
        if ($("#" + neRefId + "ISRD").length) {
            var pager = $("#" + neRefId + "ISRD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
        $("#" + formId + " .rangeSelectorButtons a.easyui-linkbutton").each(function () {
            $(this).linkbutton('enable');
        });
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('enable');
        }
        $.unblockUI();
    }
}

function refreshGOAInputStatDataForV2(neRefId, formId) {
    if ($("#" + formId).form('validate')) {
        $.blockUI();
        var refreshButtonId = neRefId + "ISRRefresh";
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('disable');
        }
        if ($("#" + neRefId + "ISRC").length) {
            var additionalReqParams = "Parm11=" + neRefId + "NESNeId&Parm12=" + neRefId + "ISRStartTime&Parm13=" + neRefId + "ISREndTime";
            getChartDataFromServer("INVERTERLESS_2400_INPUT_STATISTICS_DATA_FOR_V2", neRefId + "ISRC", "GOA_INPUT_STATS_DATA", 3201, "", "", additionalReqParams);
        }
        if ($("#" + neRefId + "ISRD").length) {
            var pager = $("#" + neRefId + "ISRD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
        $("#" + formId + " .rangeSelectorButtons a.easyui-linkbutton").each(function () {
            $(this).linkbutton('enable');
        });
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('enable');
        }
        $.unblockUI();
    }
}

function refreshGOAOutputStatData(neRefId, formId) {
    if ($("#" + formId).form('validate')) {
        $.blockUI();
        var refreshButtonId = neRefId + "OSRRefresh";
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('disable');
        }
        if ($("#" + neRefId + "OSRC").length) {
            var additionalReqParams = "Parm1=" + neRefId + "NESNeId&Parm2=" + neRefId + "OSRFieldName&Parm3=" + neRefId + "OSRStartTime&Parm4=" + neRefId + "OSREndTime&Parm5=" + neRefId + "GDT&Parm6=" + neRefId + "TN&Parm7=" + neRefId + "OSRSubSysName&Parm8=" + neRefId + "TAG";
            var URL = $.i18n.prop('SERVER_URL') + "/getGraphDataFromDB";
            getChartDataFromServerUsingURL(URL, "GOA_OUTPUT_STATISTICS_DATA", neRefId + "OSRC", "GOA_OUTPUT_STATS_DATA", "3225", additionalReqParams);
        }
        if ($("#" + neRefId + "OSRDV").length) {
            var tableURL = $.i18n.prop('CLIENT_URL') + "/common/jsp/tablefw.jsp";
            var parameters = {};
            parameters.parentId = neRefId + "OSRDV";
            parameters.tableId = neRefId + "OSRD";
            parameters.URL = $.i18n.prop('SERVER_URL') + "/getTableDataFromDB";
            parameters.parameters = "requestType=ElectricalMeters&subRequestType=refreshGOAOutputStatsData&QueryNum=3225&key=GOA_OUTPUT_STATS_DATA&exportType=SUB_SYSTEMS_DATA";
            parameters.additionalReqParams = "Parm1=" + neRefId + "NESNeId&Parm2=" + neRefId + "OSRFieldName&Parm3=" + neRefId + "OSRStartTime&Parm4=" + neRefId + "OSREndTime&Parm5=" + neRefId + "TDT&Parm6=" + neRefId + "TN&Parm7=" + neRefId + "OSRSubSysName&Parm8=" + neRefId + "TAG";
            parameters.fitColumns = false;
            parameters.actionType = "Export";
            parameters.pagesize = "GOA_OUTPUT_STATS_DATA_PAGESIZE";
            parameters.pagelist = "GOA_OUTPUT_STATS_DATA_PAGELIST";
            loadJSPFileIntoDiv(tableURL, parameters, neRefId + "OSRDV");
        }
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('enable');
        }
        $.unblockUI();
    }
}

function refreshDGStatData(neRefId) {
    if ($("#" + neRefId + "SRForm").form('validate')) {
        $.blockUI();
        var refreshButtonId = neRefId + "SRRefresh";
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('disable');
        }
        var pager = $("#" + neRefId + "SRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        $("#" + neRefId + "SRForm .rangeSelectorButtons a.easyui-linkbutton").each(function () {
            $(this).linkbutton('enable');
        });
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('enable');
        }
        $.unblockUI();
    }
}

function setCounterReset(event, neRefId) {
    event.value = event.checked ? 1 : 0;
    var energyResetValue = $("#" + neRefId + "BatterySubSystems").val() + $("#" + neRefId + "SolarSubSystems").val() + $("#" + neRefId + "GridSubSystems").val();
    $("#" + neRefId + "EnergyReset").val(parseInt(energyResetValue, 2));
}

function goaSoftRestart(operationId, neRefId) {
    $.messager.confirm($.i18n.prop('CONFIRM_TITLE'), $.i18n.prop('CONTROLLER_SOFT_RESTART_CONFIRM_MSG'), function (r) {
        if (r) {
            configureNEData('SET', 'CONTROLLER_SOFT_RESTART', operationId, neRefId, 'SRConfig', 'GOACTRL', ' ');
        }
    });
}

function modbusSoftRestart(operationId, neRefId) {
    $.messager.confirm($.i18n.prop('CONFIRM_TITLE'), $.i18n.prop('CONTROLLER_SOFT_RESTART_CONFIRM_MSG'), function (r) {
        if (r) {
            configureNEData('SET', 'CONTROLLER_SOFT_RESTART', operationId, neRefId, 'SRConfig', 'MODBUSCTRL', ' ');
        }
    });
}

function goaCounterReset(operationId, neRefId) {
    if ($("#" + neRefId + "SolarSubSystems").is(':checked') || $("#" + neRefId + "GridSubSystems").is(':checked') || $("#" + neRefId + "BatterySubSystems").is(':checked')) {
        $.messager.confirm($.i18n.prop('CONFIRM_TITLE'), $.i18n.prop('CONTROLLER_COUNTER_RESET_CONFIRM_MSG'), function (r) {
            if (r) {
                configureNEData('SET', 'CONTROLLER_COUNTER_RESET', operationId, neRefId, 'CRConfig', 'GOACTRL', ' ');
            }
        });
    } else {
        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('CONTROLLER_COUNTER_RESET_MSG'), 'info');
        return;
    }
}

function refreshDailyReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    if ($("#" + neRefId + "DSRC").length) {
        var additionalParams = "";
        if ($("#" + neRefId + "NESNeId").length) {
            additionalParams += "Parm11=" + neRefId + "NESNeId";
        }
        if ($("#" + neRefId + "NESSubSystemId").length) {
            additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
        }
        getChartDataFromServer(graphName, neRefId + "DSRC", key, "3205", "", "", additionalParams);
    }
    if ($("#" + neRefId + "DSRD").length) {
        var pager = $('#' + neRefId + 'DSRD').datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
    }
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshWeeklyReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    if ($("#" + neRefId + "WSRC").length) {
        var additionalParams = "";
        if ($("#" + neRefId + "NESNeId").length) {
            additionalParams += "Parm11=" + neRefId + "NESNeId";
        }
        if ($("#" + neRefId + "NESSubSystemId").length) {
            additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
        }
        getChartDataFromServer(graphName, neRefId + "WSRC", key, "3205", "", "", additionalParams);
    }
    if ($("#" + neRefId + "WSRD").length) {
        var pager = $('#' + neRefId + 'WSRD').datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
    }
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshMonthlyReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    if ($("#" + neRefId + "MSRC").length) {
        var additionalParams = "";
        if ($("#" + neRefId + "NESNeId").length) {
            additionalParams += "Parm11=" + neRefId + "NESNeId";
        }
        if ($("#" + neRefId + "NESSubSystemId").length) {
            additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
        }
        getChartDataFromServer(graphName, neRefId + "MSRC", key, "3205", "", "", additionalParams);
    }
    if ($("#" + neRefId + "MSRD").length) {
        var pager = $('#' + neRefId + 'MSRD').datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
    }
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshYearlyReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    if ($("#" + neRefId + "YSRC").length) {
        var additionalParams = "";
        if ($("#" + neRefId + "NESNeId").length) {
            additionalParams += "Parm11=" + neRefId + "NESNeId";
        }
        if ($("#" + neRefId + "NESSubSystemId").length) {
            additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
        }
        getChartDataFromServer(graphName, neRefId + "YSRC", key, "3205", "", "", additionalParams);
    }
    if ($("#" + neRefId + "YSRD").length) {
        var pager = $('#' + neRefId + 'YSRD').datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
    }
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshDailyInverterReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    var additionalParams = "";
    if ($("#" + neRefId + "NESNeId").length) {
        additionalParams += "Parm11=" + neRefId + "NESNeId";
    }
    if ($("#" + neRefId + "NESSubSystemId").length) {
        additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
    }
    getChartDataFromServer(graphName, neRefId + "DSRC", key, "3302", "", "", additionalParams);
    var chart = chartArray[neRefId + "DSRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {

    }
    var pager = $('#' + neRefId + 'DSRD').datagrid('getPager');
    pager.pagination('options').onBeforeRefresh();
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshWeeklyInverterReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    var additionalParams = "";
    if ($("#" + neRefId + "NESNeId").length) {
        additionalParams += "Parm11=" + neRefId + "NESNeId";
    }
    if ($("#" + neRefId + "NESSubSystemId").length) {
        additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
    }
    getChartDataFromServer(graphName, neRefId + "WSRC", key, "3302", "", "", additionalParams);
    var pager = $('#' + neRefId + 'WSRD').datagrid('getPager');
    pager.pagination('options').onBeforeRefresh();
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshMonthlyInverterReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    var additionalParams = "";
    if ($("#" + neRefId + "NESNeId").length) {
        additionalParams += "Parm11=" + neRefId + "NESNeId";
    }
    if ($("#" + neRefId + "NESSubSystemId").length) {
        additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
    }
    getChartDataFromServer(graphName, neRefId + "MSRC", key, "3302", "", "", additionalParams);
    var pager = $('#' + neRefId + 'MSRD').datagrid('getPager');
    pager.pagination('options').onBeforeRefresh();
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshYearlyInverterReport(neRefId, graphName, key) {
    $("#" + neRefId + "RAccordion").block();
    var additionalParams = "";
    if ($("#" + neRefId + "NESNeId").length) {
        additionalParams += "Parm11=" + neRefId + "NESNeId";
    }
    if ($("#" + neRefId + "NESSubSystemId").length) {
        additionalParams += "&Parm12=" + neRefId + "NESSubSystemId";
    }
    getChartDataFromServer(graphName, neRefId + "YSRC", key, "3302", "", "", additionalParams);
    var pager = $('#' + neRefId + 'YSRD').datagrid('getPager');
    pager.pagination('options').onBeforeRefresh();
    $("#" + neRefId + "RAccordion").unblock();
}

function refreshLiftStatData(neRefId) {
    if ($("#" + neRefId + "SRForm").form('validate')) {
        $.blockUI();
        var refreshButtonId = neRefId + "SRRefresh";
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('disable');
        }
        var pager = $("#" + neRefId + "SRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        $("#" + neRefId + "SRForm .rangeSelectorButtons a.easyui-linkbutton").each(function () {
            $(this).linkbutton('enable');
        });
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('enable');
        }
        $.unblockUI();
    }
}

function refreshFireStatData(neRefId) {
    if ($("#" + neRefId + "SRForm").form('validate')) {
        $.blockUI();
        var refreshButtonId = neRefId + "SRRefresh";
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('disable');
        }
        var fpPager = $("#" + neRefId + "FPSRD").datagrid('getPager');
        fpPager.pagination('options').onBeforeRefresh();
        var fsPager = $("#" + neRefId + "FSSRD").datagrid('getPager');
        fsPager.pagination('options').onBeforeRefresh();
        var fssPager = $("#" + neRefId + "FSSSRD").datagrid('getPager');
        fssPager.pagination('options').onBeforeRefresh();
        $("#" + neRefId + "SRForm .rangeSelectorButtons a.easyui-linkbutton").each(function () {
            $(this).linkbutton('enable');
        });
        if ($("#" + refreshButtonId).length) {
            $("#" + refreshButtonId).linkbutton('enable');
        }
        $.unblockUI();
    }
}

function configureDeviceDataUsingAjax(method, URL, parameters, dataType) {
    var text = "";
    parameters.operationDoneBy = document.getElementById("commonfunctions").getAttribute("data-name") || $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    $.ajax({
        type: method,
        data: parameters,
        url: URL,
        dataType: dataType,
        cache: false,
        async: false,
        success: function (data) {
            text = String(data).replace(/\\\\/g, "\\");
        },
        error: function (jqXHR, textStatus, errorThrown) {
            throwAjaxErrorToUser(jqXHR, textStatus, errorThrown);
        }
    });
    return text;
}

function refreshChillerData(neRefId) {
    var cpmPager = $("#" + neRefId + "CPMDataList").datagrid('getPager');
    cpmPager.pagination('options').onBeforeRefresh();
    var chillerPager = $("#" + neRefId + "ChillerDataList").datagrid('getPager');
    chillerPager.pagination('options').onBeforeRefresh();
    var pumpPager = $("#" + neRefId + "PumpsDataList").datagrid('getPager');
    pumpPager.pagination('options').onBeforeRefresh();
    var valvePager = $("#" + neRefId + "ValvesDataList").datagrid('getPager');
    valvePager.pagination('options').onBeforeRefresh();
}

function showVFDAndVAVStatus(operationType, operationName, operationId, neRefId, type, subSystemType, subSystemVersion) {
    $.blockUI();
    var node = getSelectedNode();
    var neName = node.text;
    var neVersion = node.attributes.neVersionNumber;
    var neTypeName = node.attributes.neTypeName;
    var typeWithVersion = node.attributes.neVersionNumber;
    var subSystemName = node.text;
    if ($.trim(subSystemType) !== null && $.trim(subSystemType) !== "" && $.trim(subSystemType) !== undefined) {
        typeWithVersion = subSystemType;
        if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
            typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
        }
        subSystemName = subSystemType;
    } else {
        subSystemType = "LCM";
    }
    var agentId = node.attributes.agentId;
    var agentIp = node.attributes.agentIp;
    var agentPort = node.attributes.agentPort;
    var agentUserId = node.attributes.agentUserId;
    var agentMobileNumber = node.attributes.agentMobileNumber;
    var subSystemRecordId = node.attributes.subSystemRecordId;
    var subSystemTypeId = node.attributes.subSystemTypeId;
    var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
    if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
        subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
    }
    if (subSystemTypeId === null || subSystemTypeId === "" || subSystemTypeId === undefined) {
        subSystemTypeId = 9;
    }
    var formId = neRefId + type + "Form";
    var statusBarId = neRefId + type;
    try {
        var polledData = dwrPushedDatas[subSystemKey];
        if (polledData === null || polledData === "" || polledData === undefined) {
            var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandlerForSet";
            var parameters = "requestType=ElectricalMeters&subRequestType=getNEDataForSet&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&operationType=" + operationType + "&operationId=" + operationId + "&operationName=" + operationName + "&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystem=" + subSystemType + "&subSystemId=128" + "&neRefId=" + $.trim(neRefId + type) + "&subSystemTypeId=" + subSystemTypeId;
            var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
            var data = eval('(' + replyFormat.replace(/\\\\u0000/g, "") + ')');
            polledData = data;
        }
        $("#" + formId).form('clear');
        try {
            var deviceData = $.parseJSON(polledData.devicedata);
            if (parseInt(deviceData.statusCode) === 0) {
                var formData = deviceData.data[0];
                document.getElementById(neRefId + "VFDRetAirTemp").textContent = formData.device_vfdReadingRetAirtemp + " ℃";
                if (formData.device_vfdReadingMode === "0" || formData.device_vfdReadingMode === 0) {
                    document.getElementById(neRefId + "VFDMode").textContent = "Auto";
                } else if (formData.device_vfdReadingMode === "1" || formData.device_vfdReadingMode === 1) {
                    document.getElementById(neRefId + "VFDMode").textContent = "Manual";
                } else if (formData.device_vfdReadingMode === "2" || formData.device_vfdReadingMode === 2) {
                    document.getElementById(neRefId + "VFDMode").textContent = "Power Shutoff";
                } else {
                    document.getElementById(neRefId + "VFDMode").textContent = "NA";
                }
                if (formData.device_vfdReadingStatus === "0" || formData.device_vfdReadingStatus === 0) {
                    document.getElementById(neRefId + "VFDStatusRect").style.stroke = "red";
                    document.getElementById(neRefId + "VFDStatusCircle").style.fill = "red";
                    document.getElementById(neRefId + "VFDStatusCircle").style.stroke = "red";
                    document.getElementById(neRefId + "VFDFanStatus").style.fill = "red";
                } else if (formData.device_vfdReadingStatus === "1" || formData.device_vfdReadingStatus === 1) {
                    document.getElementById(neRefId + "VFDStatusRect").style.stroke = "green";
                    document.getElementById(neRefId + "VFDStatusCircle").style.fill = "green";
                    document.getElementById(neRefId + "VFDStatusCircle").style.stroke = "green";
                    document.getElementById(neRefId + "VFDFanStatus").style.fill = "green";
                } else {
                    document.getElementById(neRefId + "VFDStatusRect").style.stroke = "gray";
                    document.getElementById(neRefId + "VFDStatusCircle").style.fill = "gray";
                    document.getElementById(neRefId + "VFDStatusCircle").style.stroke = "gray";
                    document.getElementById(neRefId + "VFDFanStatus").style.fill = "gray";
                }
                document.getElementById(neRefId + "VFDPower").textContent = formData.device_vfdReadingPower + " KW";
                document.getElementById(neRefId + "VFDSupplyAir").textContent = formData.device_vfdReadingSupplyAir + " ℃";

                if (formData.device_vfdReadingFilterLevel === "0" || formData.device_vfdReadingFilterLevel === 0) {
                    document.getElementById(neRefId + "VFDFilterStatus").style.fill = "url(#cleanFilter)";
                    document.getElementById(neRefId + "VFDFilterStatusText").textContent = "CLEAN";
                } else if (formData.device_vfdReadingFilterLevel === "1" || formData.device_vfdReadingFilterLevel === 1) {
                    document.getElementById(neRefId + "VFDFilterStatus").style.fill = "url(#dirtyFilter)";
                    document.getElementById(neRefId + "VFDFilterStatusText").textContent = "DIRTY";
                } else {
                    document.getElementById(neRefId + "VFDFilterStatus").style.fill = "";
                    document.getElementById(neRefId + "VFDFilterStatusText").textContent = "NONE";
                }
                if (formData.device_vfdReadingH2OValve === "0" || formData.device_vfdReadingH2OValve === 0) {
                    document.getElementById(neRefId + "VFDH2OValve").style.fill = "transparent";
                    $('#' + neRefId + "VFDH2OValveToolTip").data('qtip').options.content.text = 'Water Valve : Closed';
                    $('#' + neRefId + "VFDH2OValveToolTip").qtip('option', 'content.text', 'Water Valve : Closed');
                } else if (formData.device_vfdReadingH2OValve === "100" || formData.device_vfdReadingH2OValve === 100) {
                    document.getElementById(neRefId + "VFDH2OValve").style.fill = "blue";
                    $('#' + neRefId + "VFDH2OValveToolTip").data('qtip').options.content.text = 'Water Valve : Open';
                    $('#' + neRefId + "VFDH2OValveToolTip").qtip('option', 'content.text', 'Water Valve : Open');
                } else {
                    document.getElementById(neRefId + "VFDH2OValve").style.fill = "transparent";
                    $('#' + neRefId + "VFDH2OValveToolTip").data('qtip').options.content.text = 'Water Valve : NA';
                    $('#' + neRefId + "VFDH2OValveToolTip").qtip('option', 'content.text', 'Water Valve : NA');
                }
                document.getElementById(neRefId + "VFDWaterIn").textContent = formData.device_vfdReadingWaterIn + " ℃";
                document.getElementById(neRefId + "VFDBTU").textContent = formData.device_vfdReadingBtu + " kWh";
                document.getElementById(neRefId + "VFDFlowMin").textContent = formData.device_vfdReadingFlowMin + " L/Hr";
                document.getElementById(neRefId + "VFDWaterOut").textContent = formData.device_vfdReadingWaterOut + " ℃";
                $("#" + formId).form('load', formData);
                delete dwrPushedDatas[subSystemKey];
            }
        } catch (e) {
            //Do Nothing
        }
        updateStatusMessage(polledData, statusBarId);
    } catch (e) {
        //Do Nothing
    }
    $.unblockUI();
}

function fetchDataFromDevice(operationName, operationId, neRefId, type, subSystemType, subSystemVersion) {
    $("#" + neRefId + type + "Layout").block();
    var queryButtonId = neRefId + type + "Query";
    if ($("#" + queryButtonId).length) {
        $("#" + queryButtonId).linkbutton('disable');
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var neId = getSelectedNeId();
        var neName = getSelectedNeName();
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        //var agentIp = node.attributes.agentIp;
        //var agentPort = node.attributes.agentPort;
        //var agentUserId = node.attributes.agentUserId;
        //var agentMobileNumber = node.attributes.agentMobileNumber;
        var formId = neRefId + type + "Form";
        var statusBarId = neRefId + type;
        var URL = $.i18n.prop('SERVER_URL') + "/GetGOAStoredDetails";
        $("#" + formId).form('submit', {
            url: URL,
            onSubmit: function (param) {
                var isValid = $("#" + formId).form('validate');
                if (isValid) {
                    param.requestType = 'ElectricalMeters';
                    param.subRequestType = 'fetchStorageData';
                    param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                    param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                    param.neId = neId;
                    param.neName = neName;
                    param.neVersion = neVersion;
                    param.neTypeName = neTypeName;
                    param.agentId = agentId;
                    //param.ipAddress = agentIp;
                    //param.port = agentPort;
                    //param.uniqueId = agentUserId;
                    //param.mobileNumber = agentMobileNumber;
                    param.subSystemId = 128;
                    param.subSystem = "GOACTRL";
                    param.operationName = operationName;
                    param.operationType = 'GET';
                    param.operationId = operationId;
                    param.typeWithVersion = typeWithVersion;
                    param.subSystemTypeId = 0;
                    var dateTimeFormat = $.i18n.prop('DATETIME_FORMAT');
                    var fetchTypes = $('#' + neRefId + "FetchDataType").combobox('getValues');
                    if (fetchTypes !== null && fetchTypes !== undefined && fetchTypes !== '') {
                        param.fetchDataType = fetchTypes;
                        $.each(fetchTypes, function (index, fetchType) {
                            if (fetchType === "1" || fetchType === 1) {
                                var sdType1 = new Date($("#" + neRefId + "FetchStartDateTimeTemp").datetimebox('getValue'));
                                sdType1.setMinutes(sdType1.getMinutes() - 15);
                                var modifiedDateTimeType1 = jQuery.format.date(sdType1, dateTimeFormat);
                                param.recordRetrievalStartDateForType1 = modifiedDateTimeType1;
                            } else if (fetchType === "2" || fetchType === 2) {
                                var sdType2 = new Date($("#" + neRefId + "FetchStartDateTimeTemp").datetimebox('getValue'));
                                //sdType2.setDate(sdType2.getDate() - 1);
                                var modifiedDateTimeType2 = jQuery.format.date(sdType2, dateTimeFormat);
                                //param.recordRetrievalStartDateForType2 = modifiedDateTimeType2;
                                param.recordRetrievalStartDateForType2 = modifiedDateTimeType2;
                            }
                        });
                    }
                }
                return isValid;
            },
            success: function (data) {
                var configStatus = eval('(' + data + ')');
                updateStatusMessage(configStatus, statusBarId);
            }
        });
    }
    if ($("#" + queryButtonId).length) {
        $("#" + queryButtonId).linkbutton('enable');
    }
    $("#" + neRefId + type + "Layout").unblock();
}

function refreshTableStatData(tableId, formId) {
    if ($("#" + formId).form('validate')) {
        var pager = $("#" + tableId).datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
    }
}

function ABBUsageDetails(neRefId) {
    var chartData, min, max;
    var chart = chartArray[neRefId + "SRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalEnergy = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Cumulative Energy") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalEnergy = ((max - min) / 1000).toFixed(2) + " " + $.i18n.prop('KILO_WATT_HOURS');
                            return;
                        }
                    }
                });
            }
        }
        $("#" + neRefId + "TotalEnergy").html(totalEnergy);
    } else {
        $("#" + neRefId + "TotalEnergy").html("None");
    }
}

/****************************** CELL Metere Set Operation ***********************/
function setChargingCurrent(setChargingCurrentId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setChargingCurrentId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setChargingCurrentId).numberspinner({
        min: Number(min),
        max: Number(max), decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: true
    });
    if (prvValue) {
        $("#" + setChargingCurrentId).numberspinner('setValue', prvValue);
    }
}
function setChargingVoltage(setChargingVoltageId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setChargingVoltageId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setChargingVoltageId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: true
    });
    if (prvValue) {
        $("#" + setChargingVoltageId).numberspinner('setValue', prvValue);
    }
}
function setChargingCutoffCurrent(setChargingCutoffCurrentId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setChargingCutoffCurrentId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setChargingCutoffCurrentId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: true});
    if (prvValue) {
        $("#" + setChargingCutoffCurrentId).numberspinner('setValue', prvValue);
    }
}
function setDischargingCurrent(setDischargingCurrentId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setDischargingCurrentId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setDischargingCurrentId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: true
    });
    if (prvValue) {
        $("#" + setDischargingCurrentId).numberspinner('setValue', prvValue);
    }
}
function setDischargingCutoffVoltage(setDischargingCutoffVoltageId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setDischargingCutoffVoltageId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setDischargingCutoffVoltageId).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        precision: 2,
        editable: true
    });
    if (prvValue) {
        $("#" + setDischargingCutoffVoltageId).numberspinner('setValue', prvValue);
    }
}
function setCyclesToRun(setCyclesToRunId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setCyclesToRunId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setCyclesToRunId).numberspinner({
        min: Number(min),
        max: Number(max),
        // decimalSeparator: ".",
        increment: 1,
        // precision: 2,
        editable: true
    });
    if (prvValue) {
        $("#" + setCyclesToRunId).numberspinner('setValue', prvValue);
    }
}
function setMaximumSOC(setMaximumSOC, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setMaximumSOC).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setMaximumSOC).numberspinner({
        min: Number(min),
        max: Number(max),
        // decimalSeparator: ".",         increment: 1,
        // precision: 2,
        editable: true,
        disabled: true
    });
    if (prvValue) {
        $("#" + setMaximumSOC).numberspinner('setValue', prvValue);
    }
}
function setMinimumSOC(setMinimumSOC, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setMinimumSOC).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setMinimumSOC).numberspinner({
        min: Number(min),
        max: Number(max), // decimalSeparator: ".",
        increment: 1,
        // precision: 2,
        editable: true,
        disabled: true
    });
    if (prvValue) {
        $("#" + setMinimumSOC).numberspinner('setValue', prvValue);
    }
}
function setConstDischargePower(setConstDischargePower, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setConstDischargePower).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setConstDischargePower).numberspinner({
        min: Number(min),
        max: Number(max),
// decimalSeparator: ".",
        increment: 1,
        // precision: 2,
        editable: true,
//  disabled: true
    });
    if (prvValue) {
        $("#" + setConstDischargePower).numberspinner('setValue', prvValue);
    }
}

function setConstDischargeResistance(setConstDischargeResist, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setConstDischargeResist).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setConstDischargeResist).numberspinner({
        min: Number(min),
        max: Number(max),
        decimalSeparator: ".",
        increment: 0.1,
        // precision: 2,
        editable: true,
        //  disabled: true
    });
    if (prvValue) {
        $("#" + setConstDischargeResist).numberspinner('setValue', prvValue);
    }
}

function setCellId(setCellId, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setCellId).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setCellId).numberspinner({
        min: Number(min),
        max: Number(max),
        // decimalSeparator: ".",
        //increment: 1,
        // precision: 2,
        editable: false,
        disabled: true
    });
    if (prvValue) {
        $("#" + setCellId).numberspinner('setValue', prvValue);
    }
}

function setMaximumSOCForV2(setMaximumSOC, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setMaximumSOC).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setMaximumSOC).numberspinner({
        min: Number(min),
        max: Number(max),
        // decimalSeparator: ".",
        increment: 1,
        // precision: 2,
        editable: true,
        disabled: false
    });
    if (prvValue) {
        $("#" + setMaximumSOC).numberspinner('setValue', prvValue);
    }
}
function setMinimumSOCForV2(setMinimumSOC, min, max) {
    var prvValue;
    try {
        prvValue = $("#" + setMinimumSOC).numberspinner('getValue');
    } catch (err) {
        //Do Nothing
    }
    $("#" + setMinimumSOC).numberspinner({
        min: Number(min),
        max: Number(max),
        increment: 1,
        editable: true,
        disabled: false
    });
    if (prvValue) {
        $("#" + setMinimumSOC).numberspinner('setValue', prvValue);
    }
}

function getBatteryStatus(batteryStatus, min, max) {
    var prvValue;
    var text;
    try {
        prvValue = $("#" + batteryStatus).textbox('getValue');
    } catch (err) {
        //Do Nothing
    }
    if (prvValue === 0) {
        text = 'Idle';
    } else if (prvValue === 1) {
        text = 'Charging';
    } else if (prvValue === 2) {
        text = 'DisCharging';
    } else if (prvValue === undefined) {
        text = 'NA';
    }
    $("#" + batteryStatus).textbox({
        disabled: true
    });
    if (text) {
        $("#" + batteryStatus).textbox('setValue', text);
    }
}

/************************ CELL Metere Set Operation **************************/
/**************************Start of CELL Graph Refresh Method *********************/
function refreshCELLStatData(neRefId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var energyFunction = subSystemType.replace("_150", "").replace("_500", "") + "UsageDetails";
    if ($("#" + neRefId + "BSRForm").form('validate')) {
        $.blockUI();
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "BSRStartTime&Parm14=" + neRefId + "BSREndTime";
        getChartDataFromServer(typeWithVersion + "_STATISTICS_DATA", neRefId + "BSRC", subSystemType + "_STATS_CHARTDATA", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "BSRD").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        if (typeof window[energyFunction] === "function") {
            window[energyFunction](neRefId);
        }
        $.unblockUI();
    }
}

function refreshCELLStatData2(neRefId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var energyFunction = subSystemType.replace("_150", "").replace("_500", "") + "UsageDetails";
    if ($("#" + neRefId + "BSR2Form").form('validate')) {
        $.blockUI();
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "BSR2StartTime&Parm14=" + neRefId + "BSR2EndTime";
        getChartDataFromServer(typeWithVersion + "_STATISTICS_DATA2", neRefId + "BSR2C", subSystemType + "_STATS_CHARTDATA2", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "BSR2D").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        if (typeof window[energyFunction] === "function") {
            window[energyFunction](neRefId);
        }
        $.unblockUI();
    }
}

function refreshCELLStatData3(neRefId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var energyFunction = subSystemType.replace("_150", "").replace("_500", "") + "UsageDetails";
    if ($("#" + neRefId + "BSR3Form").form('validate')) {
        $.blockUI();
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "BSR3StartTime&Parm14=" + neRefId + "BSR3EndTime";
        getChartDataFromServer(typeWithVersion + "_STATISTICS_DATA3", neRefId + "BSR3C", subSystemType + "_STATS_CHARTDATA3", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "BSR3D").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        if (typeof window[energyFunction] === "function") {
            window[energyFunction](neRefId);
        }
        $.unblockUI();
    }
}
/********************      End of CELL Graph Refresh Method *************************/

/**************************Start of CELL Graph Refresh Method For Version 2*********************/
function refreshCELLV2StatData3(neRefId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var energyFunction = subSystemType.replace("_150", "").replace("_500", "") + "UsageDetails";
    if ($("#" + neRefId + "BSR3Form").form('validate')) {
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "BSR3StartTime&Parm14=" + neRefId + "BSR3EndTime&Parm15=" + neRefId + "BSR3Cell";
        getChartDataFromServer(typeWithVersion + "_STATISTICS_DATA3", neRefId + "BSR3C", subSystemType + "_STATS_CHARTDATA3", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "BSR3D").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        if (typeof window[energyFunction] === "function") {
            window[energyFunction](neRefId);
        }
    }
}

function refreshCELLV2StatData2(neRefId, subSystemType, subSystemVersion) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var energyFunction = subSystemType.replace("_150", "").replace("_500", "") + "UsageDetails";
    if ($("#" + neRefId + "BSR2Form").form('validate')) {
        var additionalReqParams = "Parm11=" + neRefId + "NeId&Parm12=" + neRefId + "SubSystemRecordId&Parm13=" + neRefId + "BSR2StartTime&Parm14=" + neRefId + "BSR2EndTime&Parm15=" + neRefId + "BSR2Cell";
        getChartDataFromServer(typeWithVersion + "_STATISTICS_DATA2", neRefId + "BSR2C", subSystemType + "_STATS_CHARTDATA2", 3201, "", "", additionalReqParams);
        var pager = $("#" + neRefId + "BSR2D").datagrid('getPager');
        pager.pagination('options').onBeforeRefresh();
        if (typeof window[energyFunction] === "function") {
            window[energyFunction](neRefId);
        }
    }
}

/********************      End of CELL Graph Refresh Method For Version 2*************************/

/********************      Start of Performance report Refresh Method *************************/
function refreshChillerOverAllData() {
    refreshGraphAndTableForChillerRunHrsReport();
    refreshGraphAndTableForChillerInletVSOutletReport();
    refreshGraphAndTableForChillerSetPointReport();
}

function refreshGraphAndTableForChillerRunHrsReport() {
    $.blockUI();
    if ($("#CRForm").form('validate')) {
        if ($("#CRHC").length) {
            var additionalReqParams = "Parm11=CRStartTime&Parm12=CREndTime";
            getChartDataFromServer("CHILLER_RUNHRS_DATA", "CRHC", "CHILLER_RUNHRS_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#CRHD").length) {
            var pager = $("#CRHD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
        var energyFunction = "ChillerUsageDetails";
        if (typeof window[energyFunction] === "function") {
            window[energyFunction]();
        }
    }
    $.unblockUI();
}

function refreshGraphAndTableForChillerInletVSOutletReport() {
    $.blockUI();
    if ($("#CRForm").form('validate')) {
        if ($("#CIOC").length) {
            var additionalReqParams = "Parm11=CRStartTime&Parm12=CREndTime";
            getChartDataFromServer("CHILLER_INLET_VS_OULET", "CIOC", "CHILLER_INLET_VS_OULET_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#CIOD").length) {
            var pager = $("#CIOD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
    }
    $.unblockUI();
}

function refreshGraphAndTableForChillerSetPointReport() {
    $.blockUI();
    if ($("#CRForm").form('validate')) {
        if ($("#CSPC").length) {
            var additionalReqParams = "Parm11=CRStartTime&Parm12=CREndTime";
            getChartDataFromServer("CHILLER_SETPOINT", "CSPC", "CHILLER_SETPOINT_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#CSPD").length) {
            var pager = $("#CSPD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
    }
    $.unblockUI();
}

function ChillerUsageDetails() {
    var chartData, min, max;
    var chart = chartArray["CRHC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalChiller1Runhrs = "None";
        var totalChiller2Runhrs = "None";
        var totalChiller3Runhrs = "None";
        var totalChiller4Runhrs = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "Chiller-1 Run Hours") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalChiller1Runhrs = (max - min).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "Chiller-2 Run Hours") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalChiller2Runhrs = (max - min).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "Chiller-3 Run Hours") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalChiller3Runhrs = (max - min).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "Chiller-4 Run Hours") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalChiller4Runhrs = (max - min).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                });
            }
        }
        $("#TotalChillerRunHrs1").html(totalChiller1Runhrs);
        $("#TotalChillerRunHrs2").html(totalChiller2Runhrs);
        $("#TotalChillerRunHrs3").html(totalChiller3Runhrs);
        $("#TotalChillerRunHrs4").html(totalChiller4Runhrs);
    } else {
        $("#TotalChillerRunHrs1").html("None");
        $("#TotalChillerRunHrs2").html("None");
        $("#TotalChillerRunHrs3").html("None");
        $("#TotalChillerRunHrs4").html("None");
    }
}

function refreshAcMeterOverAllData() {
    refreshGraphAndTableForEnergySharing();
    refreshGraphAndTableForEnergySharingDayVsNight();
    refreshGraphAndTableForEnergySharingWeekdayVsWeeknight();
}

function AcMeterEnergyUsageDetails() {
    var chartData, min, max;
    var chart = chartArray["ACEHRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalAcMeterEnergy = 0;
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function (i) {
                    chartData = this.data;
                    for (i = 0; i <= chartData.length - 1; i++) {
                        totalAcMeterEnergy += chartData[i].y;
                    }
                });
            }
        }
        $("#TotalACMeterEnergy").html(totalAcMeterEnergy + " " + $.i18n.prop('KILO_WATT_HOURS'));
    } else {
        $("#TotalACMeterEnergy").html("None");
    }
}

function refreshGraphAndTableForEnergySharing() {
    $.blockUI();
    if ($("#ACRForm").form('validate')) {
        if ($("#ACEHRC").length) {
            var additionalReqParams = "Parm11=ACRStartTime&Parm12=ACREndTime";
            getChartDataFromServer("AC_ENERGYSHARING_DATA", "ACEHRC", "AC_ENERGYSHARING_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#ACEHRD").length) {
            var pager = $("#ACEHRD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
        var energyFunction = "AcMeterEnergyUsageDetails";
        if (typeof window[energyFunction] === "function") {
            window[energyFunction]();
        }
    }
    $.unblockUI();
}

function refreshGraphAndTableForEnergySharingDayVsNight() {
    $.blockUI();
    if ($("#ACRForm").form('validate')) {
        if ($("#ACDVSNRC").length) {
            var additionalReqParams = "Parm11=ACRStartTime&Parm12=ACREndTime";
            getChartDataFromServer("AC_ENERGYSHARING_DAY_VS_NIGHT_DATA", "ACDVSNRC", "AC_ENERGYSHARING_DAY_VS_NIGHT_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#ACDVSNRD").length) {
            var pager = $("#ACDVSNRD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
    }
    $.unblockUI();
}

function refreshGraphAndTableForEnergySharingWeekdayVsWeeknight() {
    $.blockUI();
    if ($("#ACRForm").form('validate')) {
        if ($("#ACWDVSWERC").length) {
            var additionalReqParams = "Parm11=ACRStartTime&Parm12=ACREndTime";
            getChartDataFromServer("EB_SHARING_WEEKDAY_VS_WEEKEND_DATA", "ACWDVSWERC", "AC_ENERGYSHARING_WEEKDAYS_VS_WEEKENDS_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#ACWDVSWERD").length) {
            var pager = $("#ACWDVSWERD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
    }
    $.unblockUI();
}

function refreshDGMeterOverAllData() {
    refreshGraphAndTableForDGOverallStaticsReport();
    refreshGraphAndTableForDGRunHrsReport();
}

function refreshGraphAndTableForDGOverallStaticsReport() {
    $.blockUI();
    if ($("#DGRForm").form('validate')) {
        if ($("#DGSRC").length) {
            var additionalReqParams = "Parm11=DGRStartTime&Parm12=DGREndTime";
            getChartDataFromServer("DG_OVERALL_STATISTICS_DATA", "DGSRC", "DG_STATS_DATA", 3205, "", "", additionalReqParams);
        }
        if ($("#DGSRD").length) {
            var pager = $("#DGSRD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
        var energyFunction = "DGUsageDetails";
        if (typeof window[energyFunction] === "function") {
            window[energyFunction]();
        }
    }
    $.unblockUI();
}

function DGUsageDetails() {
    var chartData, min, max;
    var chart = chartArray["DGSRC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalDGEnergyProduce = 0;
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    chartData = this.data;
                    for (i = 0; i <= chartData.length; i++) {
                        if (chartData[i] !== null && chartData[i] !== "null" && chartData[i] !== " " && chartData[i] !== "" && chartData[i] !== undefined) {
                            totalDGEnergyProduce += chartData[i].y;
                        }
                    }
                });
            }
        }
        $("#TotalEnergyProducedDG").html(totalDGEnergyProduce + " " + $.i18n.prop('KILO_WATT_HOURS'));
    } else {
        $("#TotalEnergyProducedDG").html("None");
    }
}

function refreshGraphAndTableForDGRunHrsReport() {
    $.blockUI();
    if ($("#DGRForm").form('validate')) {
        if ($("#DGRHC").length) {
            var additionalReqParams = "Parm11=DGRStartTime&Parm12=DGREndTime";
            getChartDataFromServer("DG_RUN_HRS_DATA", "DGRHC", "DG_RUN_HRS_DATA", 3201, "", "", additionalReqParams);
        }
        if ($("#DGRHD").length) {
            var pager = $("#DGRHD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
        var energyFunction = "DGRunHrsUsageDetails";
        if (typeof window[energyFunction] === "function") {
            window[energyFunction]();
        }
    }
    $.unblockUI();
}

function DGRunHrsUsageDetails() {
    var chartData, min, max;
    var chart = chartArray["DGRHC"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalDG12Runhrs = "None";
        var totalDG13Runhrs = "None";
        var totalDG14Runhrs = "None";
        var totalDG15Runhrs = "None";
        var totalDG16Runhrs = "None";
        var totalDG17Runhrs = "None";
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function () {
                    if (this.name === "DG12") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalDG12Runhrs = (((max - min) * 60) / 100).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "DG13") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalDG13Runhrs = (((max - min) * 60) / 100).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "DG14") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalDG14Runhrs = (((max - min) * 60) / 100).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "DG15") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalDG15Runhrs = (((max - min) * 60) / 100).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "DG16") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalDG16Runhrs = (((max - min) * 60) / 100).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                    if (this.name === "DG17") {
                        chartData = this.data;
                        if (chartData.length > 0) {
                            min = getChartMinData(chartData);
                            max = getChartMaxData(chartData);
                            totalDG17Runhrs = (((max - min) * 60) / 100).toFixed(2) + " " + $.i18n.prop('HOURS_LABEL');
                        }
                    }
                });
            }
        }
        $("#TotalRunHrsDG12").html(totalDG12Runhrs);
        $("#TotalRunHrsDG13").html(totalDG13Runhrs);
        $("#TotalRunHrsDG14").html(totalDG14Runhrs);
        $("#TotalRunHrsDG15").html(totalDG15Runhrs);
        $("#TotalRunHrsDG16").html(totalDG16Runhrs);
        $("#TotalRunHrsDG17").html(totalDG17Runhrs);
    } else {
        $("#TotalRunHrsDG12").html("None");
        $("#TotalRunHrsDG13").html("None");
        $("#TotalRunHrsDG14").html("None");
        $("#TotalRunHrsDG15").html("None");
        $("#TotalRunHrsDG16").html("None");
        $("#TotalRunHrsDG17").html("None");
    }
}

function TotalVfdReadings() {
    var chartData, min, max;
    var chart = chartArray["VFDB"];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var totalVfdReadings = 0;
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            if (chart.series.length > 0) {
                $(chart.series).each(function (i) {
                    chartData = this.data;
                    for (i = 0; i <= chartData.length - 1; i++) {
                        totalVfdReadings += chartData[i].y;
                    }
                });
            }
        }
        $("#TotalVfdReadingEnergy").html(totalVfdReadings + " " + $.i18n.prop('KILO_WATT_HOURS'));
    } else {
        $("#TotalVfdReadingEnergy").html("None");
    }
}

function refreshVFDReadingsOverAllData() {
    refreshGraphAndTableForBuilding();
    refreshGraphAndTableForFloor();
    refreshGraphAndTableForNE();
    var vfdReadingFunction = "TotalVfdReadings";
    if (typeof window[vfdReadingFunction] === "function") {
        window[vfdReadingFunction]();
    }
}
function refreshGraphAndTableForBuilding() {
    $.blockUI();
    if ($("#VFDForm").form('validate')) {
        if ($("#VFDB").length) {
            var additionalReqParams = "Parm11=VFDStartTime&Parm12=VFDEndTime";
            getChartDataFromServer("VFD_BUILDING_BASED_DATA", "VFDB", "VFD_BUILDING_BASED_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#VFDBD").length) {
            var pager = $("#VFDBD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
    }
    $.unblockUI();
}

function refreshGraphAndTableForFloor() {
    $.blockUI();
    if ($("#VFDForm").form('validate')) {
        if ($("#VFDF").length) {
            var additionalReqParams = "Parm11=VFDBuildingName&Parm12=VFDFloorName&Parm13=VFDStartTime&Parm14=VFDEndTime";
            getChartDataFromServer("VFD_FLOOR_BASED_DATA", "VFDF", "VFD_FLOOR_BASED_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#VFDFD").length) {
            var pager = $("#VFDFD").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
    }
    $.unblockUI();
}

function refreshGraphAndTableForNE() {
    $.blockUI();
    if ($("#VFDForm").form('validate')) {
        if ($("#VFDNE").length) {
            var additionalReqParams = "Parm11=VFDNEBuildingName&Parm12=VFDNEFloorName&Parm13=VFDNEName&Parm14=VFDStartTime&Parm15=VFDEndTime";
            getChartDataFromServer("VFD_NE_BASED_DATA", "VFDNE", "VFD_NE_BASED_CHARTDATA", 3201, "", "", additionalReqParams);
        }
        if ($("#VFDNED").length) {
            var pager = $("#VFDNED").datagrid('getPager');
            pager.pagination('options').onBeforeRefresh();
        }
    }
    $.unblockUI();
}
/********************      End of Performance report Refresh Method *********** **************/

/**********************************************BLT Get Handler For Set Operation *****************************************************/
function getBltDataFromDeviceForSet(operationName, operationId, neRefId, type, subSystemType, subSystemVersion, cellId) {
    $.blockUI();
    var refreshButtonId = neRefId + type + "Refresh";
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('disable');
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var subSystemId = node.attributes.subSystemId;
        var neId = node.attributes.neId;
        var neName = node.attributes.neName;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemRecordId = node.attributes.subSystemRecordId;
        var subSystemTypeId = node.attributes.subSystemTypeId;
        var subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId;
        if (subSystemRecordId !== null && subSystemRecordId !== "" && subSystemRecordId !== undefined) {
            subSystemKey = neName + $.i18n.prop('NE_DELIMITER') + operationId + $.i18n.prop('NE_DELIMITER') + subSystemRecordId;
        }
        var formId = neRefId + type + "Form";
        var statusBarId = neRefId + type;
        var polledData = dwrPushedDatas[subSystemKey];
        if (polledData === null || polledData === "" || polledData === undefined) {
            var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandlerForSet";
            var subSystemName = node.text;
            var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceDataForSet&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neId=" + neId + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&subSystemId=" + subSystemId + "&subSystem=" + subSystemType + "&operationType=GET&operationId=" + operationId + "&operationName=" + operationName + "&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystemVersion=" + subSystemVersion + "&neRefId=" + $.trim(neRefId + type) + "&subSystemTypeId=" + subSystemTypeId + "&cellId=" + cellId;
            var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
            var data = eval('(' + replyFormat + ')');
            polledData = data;
        }
        updateConfigFormData(formId, subSystemKey, polledData, statusBarId, neRefId);
    }
    if ($("#" + refreshButtonId).length) {
        $("#" + refreshButtonId).linkbutton('enable');
    }
    $.unblockUI();
}

function configureBltDeviceData(operationName, operationId, neRefId, type, subSystemType, subSystemVersion, cellId) {
    $.blockUI();
    var message;
    var updateButtonId = neRefId + type + "Update";
    if ($("#" + updateButtonId).length) {
        $("#" + updateButtonId).linkbutton('disable');
    }
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var node = getSelectedNode();
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var subSystemId = node.attributes.subSystemId;
        var neId = node.attributes.neId;
        var neName = node.attributes.neName;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemTypeId = node.attributes.subSystemTypeId;
        var formId = neRefId + type + "Form";
        var statusBarId = neRefId + type;
        var URL = $.i18n.prop('SERVER_URL') + "/setHandler";
        var dirtyFields = $("#" + formId).form('options').dirtyFields;
        if (dirtyFields.length > 0) {
            $("#" + formId).form('submit', {
                url: URL,
                onSubmit: function (param) {
                    var isValid = $("#" + formId).form('validate');
                    if (isValid) {
                        param.requestType = 'ElectricalMeters';
                        param.subRequestType = 'setDeviceData';
                        param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                        param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                        param.neId = neId;
                        param.neName = neName;
                        param.neVersion = neVersion;
                        param.neTypeName = neTypeName;
                        param.agentId = agentId;
                        param.ipAddress = agentIp;
                        param.port = agentPort;
                        param.subSystemId = subSystemId;
                        param.subSystem = subSystemType;
                        param.managedObjectInstance = subSystemId;
                        param.managedObjectClass = subSystemType;
                        param.operationName = operationName;
                        param.operationType = 'SET';
                        param.operationId = operationId;
                        param.uniqueId = agentUserId;
                        param.mobileNumber = agentMobileNumber;
                        param.subSystemName = node.text;
                        param.typeWithVersion = typeWithVersion;
                        param.subSystemVersion = subSystemVersion;
                        param.subSystemTypeId = subSystemTypeId;
                        param.cellId = cellId;
                        param.managedObjectInstance = subSystemType + "-" + subSystemId;
                        param.neRefId = $.trim(neRefId + type);
                        $("#" + formId + " input.switchbutton-value").each(function () {
                            var selInpName = $(this).attr('name');
                            var selVal = $('input[name="' + selInpName + '"]:checked').val();
                            if (selVal === 1 || selVal === "1" || selVal === "on") {
                                $(this).val(1);
                            } else {
                                $(this).val(0);
                                param[$(this).attr('name')] = 0;
                            }
                        });
                        $("#" + formId + " input:checkbox").each(function () {
                            if ($(this).prop('checked') === true) {
                                $(this).val('1');
                            } else {
                                $(this).val('0');
                                param[$(this).attr('name')] = 0;
                            }
                        });
                        var onOffLoad1Elem = dirtyFields.filter(function (v) {
                            return v.id === neRefId + 'OnOffLoad1';
                        });
                        var onOffLoad2Elem = dirtyFields.filter(function (v) {
                            return v.id === neRefId + 'OnOffLoad2';
                        });
                        if ($(onOffLoad1Elem).attr('id') === neRefId + 'OnOffLoad1' && $(onOffLoad2Elem).attr('id') === neRefId + 'OnOffLoad2') {
                            //Do Nothing
                        } else if ($(onOffLoad1Elem).attr('id') === neRefId + 'OnOffLoad1') {
                            if ($("#" + formId + " input[name='device_onOffNormalLine']").length) {
                                param.device_onOffNormalLine = $("#" + formId + " input[name='device_onOffNormalLine']").val();
                            }
                        } else if ($(onOffLoad2Elem).attr('id') === neRefId + 'OnOffLoad2') {
                            if ($("#" + formId + " input[name='device_onOffEmergencyLine']").length) {
                                param.device_onOffEmergencyLine = $("#" + formId + " input[name='device_onOffEmergencyLine']").val();
                            }
                        }
                    }
                    return isValid;
                },
                success: function (data) {
                    var configStatus = eval('(' + data + ')');
                    updateStatusMessage(configStatus, statusBarId);
                }
            });
        } else {
            message = $.i18n.prop('NO_CHANGE_MESSAGE');
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
        }
    } else {
        message = $.i18n.prop('NO_CHANGE_MESSAGE');
        $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
    }
    /* if ($("#" + updateButtonId).length) {
     $("#" + updateButtonId).linkbutton('enable');
     } */
    $("#" + neRefId + type + "Layout").unblock();
}

// rangeSelector method for BLT_002
function rangeSelectorInputForBlt_002(startDateTimeId, endDateTimeId, cellId, refreshButtonId, selectedRange) {
    setStartAndEndDateTimeBasedInputForBlt_002(startDateTimeId, endDateTimeId, cellId, selectedRange);
    setTimeout(function () {
        $("#" + refreshButtonId).trigger("click");
    }, 100);
}

function setStartAndEndDateTimeBasedInputForBlt_002(startDateTimeId, endDateTimeId, cellId, selectedRange) {
    var dateTimeFormat = $.i18n.prop('DATETIME_FORMAT');
    var sd = new Date();
    var ed = new Date();
    switch (selectedRange.toLowerCase()) {
        case "1d" :
            sd.setDate(sd.getDate() - 1);
            break;
        case "3d" :
            sd.setDate(sd.getDate() - 3);
            break;
        case "7d" :
            sd.setDate(sd.getDate() - 7);
            break;
        case "15d" :
            sd.setDate(sd.getDate() - 15);
            break;
        case "1m" :
            sd.setMonth(sd.getMonth() - 1);
            break;
        case "3m" :
            sd.setMonth(sd.getMonth() - 3);
            break;
        case "6m" :
            sd.setMonth(sd.getMonth() - 6);
            break;
        case "1y" :
            sd.setMonth(sd.getMonth() - 12);
            break;
        case "mtd" :
            sd = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
            break;
        case "ytd" :
            sd = new Date(new Date().getFullYear(), 0, 1);
            break;
        default:
            sd = new Date();
    }
    var startTime = jQuery.format.date(sd, dateTimeFormat).split(" ")[0] + " 00:00";
    var endTime = jQuery.format.date(ed, dateTimeFormat).split(" ")[0] + " 23:59";
    var prvCellValue = $("#" + cellId).combobox('getValue');
    $("#" + startDateTimeId).datetimebox('setValue', startTime);
    $("#" + endDateTimeId).datetimebox('setValue', endTime);
    $("#" + cellId).combobox('setValue', prvCellValue);
}
/********************************************** BLT Get Handler For Set Operation *****************************************************/
