var map = "";
var locationOnMapLoad = "";
function getSelectedNodeAndLoadMap() {
    if (locationOnMapLoad !== "null" && locationOnMapLoad !== "" && locationOnMapLoad !== undefined && locationOnMapLoad !== null) {
        Maplocation(locationOnMapLoad);
    }
}

function loadMaps() {
    if (typeof google === 'object' && typeof google.maps === 'object') {
        map = new google.maps.Map(document.getElementById('showOnMap'), {
            zoom: 3,
            center: new google.maps.LatLng(22, 79),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            zoomControl: true,
            mapTypeControl: true,
            scaleControl: true,
            streetViewControl: true,
            rotateControl: true,
            fullscreenControl: true
        });
        google.maps.event.addListener(map, 'idle', function () {
            google.maps.event.trigger(map, 'resize');
        });
        map.markers = {};
        //getDataAndLoadMap();
        getSelectedNodeAndLoadMap();
    }
}

function ShowLocationNotFound() {
    $("#showOnMap").empty();
    $("#showOnMap").html("<div class='vertHorzCenterDiv'><h2>Location not found</h2></div>");
}

function Maplocation(location) {
    if (location === "null" || location === "" || location === undefined || location === null) {
        ShowLocationNotFound();
    } else {
        if ((typeof google === 'object' && typeof google.maps === 'object') && (map !== null && map !== "" && map !== undefined)) {
            $.each(map.markers, function (idx, marker) {
                marker.setMap(null);
            });
            var infowindow = new google.maps.InfoWindow();
            var p = location.length;
            for (i = 0; i < p; i++) {
                var data = location[i];
                if ((data.lat !== "None" && data.lat !== null && data.lat !== "" && data.lat !== undefined) && (data.lng !== "None" && data.lng !== null && data.lng !== "" && data.lng !== undefined)) {
                    var latlng = new google.maps.LatLng(parseFloat(data.lat), parseFloat(data.lng));
                    var image = $.i18n.prop('CLIENT_URL') + "/common/images/markers/green.png";
                    if (data.status === "success" || data.status === "Success") {
                        image = $.i18n.prop('CLIENT_URL') + "/common/images/markers/green.png";
                    } else if (data.status === "failure" || data.status === "Failure") {
                        image = $.i18n.prop('CLIENT_URL') + "/common/images/markers/red.png";
                    }
                    var marker = new google.maps.Marker({
                        position: latlng,
                        map: map,
                        icon: image
                    });
                    (function (id, text, personName, mobileNumber, phoneNumber, emailAddress) {
                        google.maps.event.addListener(marker, 'click', function () {
                            infowindow.setContent("<table><tr><th>Name</th><td>" + text + "</a></td></tr><tr><th>Person Name</th><td>" + personName + "</td></tr><tr><th>Mobile Number</th><td>" + mobileNumber + "</td></tr><tr><th>Phone Number</th><td>" + phoneNumber + "</td></tr><tr><th>Email Address</th><td>" + emailAddress + "</td></tr></table>");
                            infowindow.open(map, this);
                        });
                    })(data.id, data.text, data.personName, data.mobileNumber, data.phoneNumber, data.emailAddress);
                    map.markers[data.lat] = marker;
                }
            }
        } else {
            locationOnMapLoad = location;
        }
    }
}
