function showAndHideAdvancedOptions(e, advancedId){
    if (e.checked) {
        $("." + advancedId).show();
    } else {
        $("." + advancedId).hide();
    }
}
function createInputBox() {
    column = document.createElement("td");
    element = document.createElement("input");
    element.setAttribute("id", params[0]);
    element.setAttribute("name", params[0]);
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    element.setAttribute("title", params[3]);
    if ($.trim(params[4]).replace(/"/g, '') != ""
        && $.trim(params[4]).replace(/"/g, '') != null) {
        element.setAttribute("value", params[4]);
    }
    if (params[5] == "url") {
        element.setAttribute("onkeypress", "return validateURL(event)");
    }
    element.setAttribute("type", params[5]);
    if (params[6] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }
    element.setAttribute("required", (params[7] == "true"));
    element.setAttribute("class", "required");
    $(element).addClass("required");
    column.appendChild(element);
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function createIPBox() {
    column = document.createElement("td");
    element = document.createElement("input");
    element.setAttribute("id", params[0]);
    element.setAttribute("name", params[0]);
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    element.setAttribute("title", params[3]);
    if ($.trim(params[4]).replace(/"/g, '') != ""
        && $.trim(params[4]).replace(/"/g, '') != null) {
        element.setAttribute("value", params[4]);
    }
    element.setAttribute("type", "text");
    if (params[6] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }
    $(element).addClass("ip");
    element.setAttribute("required", (params[7] == "true"));
    column.appendChild(element);
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function createIPWithPortBox() {
    column = document.createElement("td");
    element = document.createElement("input");
    element.setAttribute("id", params[0].split('_')[0]);
    element.setAttribute("name", params[0].split('_')[0]);
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    element.setAttribute("title", params[3]);
    if ($.trim(params[4].split('_')[0]).replace(/"/g, '') != ""
        && $.trim(params[4].split('_')[0]).replace(/"/g, '') != null) {
        element.setAttribute("value", params[4].split('_')[0]);
    }
    element.setAttribute("type", "text");
    if (params[6] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }
    $(element).addClass(params[5]);
    element.setAttribute("required", (params[7] == "true"));
    column.appendChild(element);
    $(column).append('&nbsp; : ');
    element1 = document.createElement("input");
    element1.setAttribute("id", params[0].split('_')[1]);
    element1.setAttribute("name", params[0].split('_')[1]);
    element1.setAttribute("title", params[3]);
    if ($.trim(params[4].split('_')[1]).replace(/"/g, '') != ""
        && $.trim(params[4].split('_')[1]).replace(/"/g, '') != null) {
        element1.setAttribute("value", params[4].split('_')[1]);
    }
    element1.setAttribute("type", params[5].split('_')[1]);
    if (params[6] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }
    element1.setAttribute("required", (params[7] == "true"));
    element1.setAttribute("size", params[8]);
    element1.setAttribute("min", params[9]);
    element1.setAttribute("max", params[10]);
    $(element1).bind('keypress', function() {
        return isNumberKey(event);
    });
    column.appendChild(element1);
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function createNumberBox() {
    column = document.createElement("td");
    element = document.createElement("input");
    element.setAttribute("id", params[0]);
    element.setAttribute("name", params[0]);
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    element.setAttribute("title", params[3]);
    if ($.trim(params[4]).replace(/"/g, '') != ""
        && $.trim(params[4]).replace(/"/g, '') != null) {
        element.setAttribute("value", params[4]);
    }
    element.setAttribute("type", "text");
    if (params[6] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }
    element.setAttribute("required", (params[7] == "true"));
    element.setAttribute('class', "{required:true,number:true}");
    $(element).addClass("{required:true,number:true}");
    if(params[8] > 0) {
    	element.setAttribute("maxlength", parseInt(params[8]));
    }
    $(element).forceNumeric();    
    column.appendChild(element);
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function createSpinBox() {
    column = document.createElement("td");
    element = document.createElement("input");
    element.setAttribute("id", params[0]);
    element.setAttribute("name", params[0]);
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    element.setAttribute("title", params[3]);
    if ($.trim(params[4]).replace(/"/g, '') != ""
        && $.trim(params[4]).replace(/"/g, '') != null) {
        element.setAttribute("value", params[4]);
    }
    element.setAttribute("type", "text");
    if (params[6] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }    
    if(params[7] == "true") {
    	element.setAttribute("required", "true");
        element.setAttribute('class', "required");
        $(element).addClass("required");    	
    }
    $(element).forceNumeric();
    var min = Number(params[8]);
	var max = Number(params[9]);
	var step = Number(params[10]);		
    //element.setAttribute("min", min);
    if(params[9] == "Infinity") {
    	$(element).change({min: min},function(event) {
    		var v = Number(this.value);		
    		var min = Number(event.data.min);
    		if (isNaN(v)) {    			
    			return this.value = min;
    		}
    	    if (v < min) {    	    	
    	    	this.value = min;
    		} else {
    			this.value = v;
    		}
    	});
    } else {    	
    	//element.setAttribute("max", max);
    	element.setAttribute('placeholder', 'Valid value: ' + min + "-" + max);
    	$(element).change({min: min, max:max},function(event) {
    		var v = Number(this.value);
    		var min = Number(event.data.min);
    		var max = Number(event.data.max);
    		if (isNaN(v)) {
    			return this.value = min;
    		}
    	    if (v < min) {
    	    	this.value = min;
    		} else if (v > max) {
    			this.value = max; 
    		} else {
    			this.value = v;
    		}
    	});
    }
    column.appendChild(element);
    row.appendChild(elementLabel);
    row.appendChild(column);
    if (params[6] != "disabled") {   	
    	if(params[9] == "Infinity") {    		
	    	$(element).spinner({
	    		min: min,	    		
	    		step: step,
	    		increment: 'fast'
	    	});
    	} else {
    		$(element).spinner({
	    		min: min,
	    		max: max,
	    		step: step,
	    		increment: 'fast'
	    	});
    	}
    }    
}
function createCheckBox() {
    column = document.createElement("td");
    element = document.createElement("input");
    element.setAttribute("id", params[0]);
    element.setAttribute("name", params[0]);
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    //elementLabel.appendChild(labelText);
    element.setAttribute("title", params[3]);
    element.setAttribute("type", params[4]);    
    if (params[5] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }
    element.setAttribute("checked", (params[6] == "true"));
    element.defaultChecked = (params[6] == "true");
    column.setAttribute("align", "center");
    column.setAttribute('style', 'text-align: center !important;');
    column.appendChild(element);
    column.appendChild(labelText);
    row.appendChild(elementLabel);
    row.appendChild(column);    
}
function createComboBox() {
    column = document.createElement("td");
    element = document.createElement("select");
    element.setAttribute("id", params[0]);
    element.setAttribute("name", params[0]);
    elementLabel = document.createElement("th");        
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    element.setAttribute("title", params[3]);
    var values = params[4].split(',');
    var options = "";
    for (var i = 0; i < values.length; i++) {
        if (i == $.trim(params[10])) {
            options = '<option value="' + values[i] + '" selected>' + values[i]
            + '</option>';
        } else {
            options = '<option value="' + values[i] + '">' + values[i]
            + '</option>';
        }
        $(element).append(options);
    }
    if (params[6] == "disabled") {
        element.setAttribute("disabled", "disabled");
    }
    element.required = (params[7] == "true");
    element.multiple = (params[8] == "true");
    element.setAttribute("size", params[9]);
    column.appendChild(element);    
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function createRadioBox() {
    column = document.createElement("td");
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    var values = params[4].split(',');
    var options = "";
    for ( var i = 0; i < values.length; i++) {
        if (params[8] == i) {
            options = '<label><input type="radio" name="' + params[0]
            + '" value="' + values[i] + '" checked="checked"'
            + params[6] + '/>' + values[i] + '</label>';
        } else {
            options = '<label><input type="radio" name="' + params[0]
            + '" value="' + values[i] + '"' + params[6] + '/>'
            + values[i] + '</label>';
        }
        $(column).append(options);
    }
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function generateSelectOption(value) {
    var startValue = value.split("-")[0];
    var endValue = value.split("-")[1];
    var options = "";
    for ( var k = startValue; k <= endValue; k++) {
        options += '<option value="' + k + '">' + k + '</option>';
    }
    return options;
}
function createRadioWithComboBox() {
    column = document.createElement("td");
    elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    elementLabel.appendChild(labelText);
    var values = params[4].split(',');
    for ( var i = 0; i < values.length; i++) {
        var options = "";
        options += '<div>';
        if (params[10] == i) {
            options += '<label><input type="radio" name="' + params[0]
            + '" value="' + values[i] + '" checked="checked"'
            + params[6] + '/>' + values[i] + '</label>';
        } else {
            options += '<label><input type="radio" name="' + params[0]
            + '" value="' + values[i] + '"' + params[6] + '/>'
            + values[i] + '</label>';
        }
        var comboLables = params[5].split(',');
        var comboValues = params[6].split(',');
        if ($.trim(comboLables[i]).replace(/"/g, '') != ""
            && $.trim(comboLables[i]).replace(/"/g, '') != null) {
            comboElement = '<label><select name="' + params[0] + '"'
            + params[6] + '>';
            comboElement += generateSelectOption(comboValues[i]);
            comboElement += '</select> ' + comboLables[i].split('_')[0]
            + '</label>';
            options += " " + comboElement;
            var comboLables1 = comboLables[i].split('_');
            if ($.trim(comboLables1[1]).replace(/"/g, '') != ""
                && $.trim(comboLables1[1]).replace(/"/g, '') != null) {
                for ( var j = 1; j < comboLables1.length; j++) {
                    if ($.trim(comboLables1[j]).replace(/"/g, '') != ""
                        && $.trim(comboLables1[j]).replace(/"/g, '') != null) {
                        comboElement1 = '<label><select name="' + params[0]
                        + '"' + params[6] + '>';
                        comboElement1 += generateSelectOption(comboValues[i]);
                        comboElement1 += '</select> ' + comboLables1[j]
                        + '</label>';
                        options += " " + comboElement1;
                    }
                }
            }
        }
        options += '</div>';
        $(column).append(options);
    }
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function createLabel() {
	column = document.createElement("td");
	elementLabel = document.createElement("th");
    var labelText = document.createTextNode(params[2]);
    column.appendChild(labelText);
    row.appendChild(elementLabel);
    row.appendChild(column);
}
function generateComp() {
    switch (params[1]) {
        case "TextBox":
            createInputBox();
            break;
        case "IPBox":
            createIPBox();
            break;
        case "IPWithPortBox":
            createIPWithPortBox();
            break;
        case "NumberBox":
            createNumberBox();
            break;
        case "SpinBox":
        	createSpinBox();
            break;            
        case "ComboBox":
            createComboBox();
            break;
        case "CheckBox":
            createCheckBox();
            break;
        case "RadioBox":
            createRadioBox();
            break;
        case "RadioWithComboBox":
            createRadioWithComboBox();
            break;
        case "Label":
        	createLabel();
            break;
        default:
    }
}
function generateDefComp(colSpan, tableBodyId, advancedId) {
    if (colSpanCnt == colSpan) {
        $("#" + tableBodyId).append(row);
        row = document.createElement("tr");
        if (advancedId != "" && advancedId != null) {
            $(row).addClass(advancedId);
            $(row).hide();
        }
        colSpanCnt = 1;
    } else if (colSpanCnt == 0) {
        colSpanCnt = 1;
    } else {
        colSpanCnt++;
    }
    generateComp();
}
function processXMLGenAdvndComp(xml, colSpan, tableBodyId) {
    var advancedId;
    $(xml).find('ConfigAdvanced').each(function() {
        advancedName = $(this).find('ConfigAdvancedName').text();
        advancedId = $(this).find('ConfigAdvancedId').text();
        colSpanCnt = 0;
        row = document.createElement("tr");
        column = document.createElement("td");
        var advancedOption = '<label><input type="checkbox" onclick="showAndHideAdvancedOptions(this,'
        + '\''
        + advancedId
        + '\''
        + ')"  value="'
        + advancedId
        + '" id="'
        + advancedId
        + 'ChkBox"/>  ' + advancedName + '</label>';
        $(column).append(advancedOption);
        row.appendChild(column);
        document.getElementById(tableBodyId).appendChild(row);
        row = document.createElement("tr");
        $(row).addClass(advancedId);
        $(row).hide();
        $(this).find('ParameterList').each(function() {
            params = new Array();
            $('*', this).each(function(index, event) {
                params.push(event.childNodes[0].nodeValue);
            });
            generateDefComp(colSpan, tableBodyId, advancedId);
        });
    });
    document.getElementById(tableBodyId).appendChild(row);
}
function processXMLGenComp(xml, colSpan, tableBodyId) {
    row = document.createElement("tr");
    $(xml).find('ConfigBasic').each(function() {
        $(this).find('ParameterList').each(function() {
            params = new Array();
            $('*', this).each(function(index, event) {
                if (event.childNodes[0].nodeValue != " "
                    && event.childNodes[0].nodeValue != null) {
                    params.push(event.childNodes[0].nodeValue);
                }
            });
            generateDefComp(colSpan, tableBodyId, null);
        });
    });
    document.getElementById(tableBodyId).appendChild(row);
}
function generateCompsFromXML(xml, headerId, tableId, tableBodyId) {
    var colSpan = 0;
    colSpanCnt = 0;
    $('#' + headerId).append($(xml).find('ConfigTypeDisplayName').text());
    $('#' + headerId).attr({
        title: $(xml).find('ConfigTypeToolTipText').text() 
    });
    colSpan = $(xml).find('ConfigTypeLayoutColumnCount').text();
    if ($(xml).find('ConfigBasic').length > 0) {
        processXMLGenComp(xml, colSpan, tableBodyId);
    }
    if ($(xml).find('ConfigAdvanced').length > 0) {
        processXMLGenAdvndComp(xml, colSpan, tableBodyId);
    }	
}