function resizeLiftView(neRefId, width, height) {
    $("#" + neRefId + "LiftPortal").portal('resize');
    var calHeight = Math.floor(height - 4);
    for (var i = 1; i < 11; i++) {
        if ($("#" + neRefId + "LiftPortalView" + i).length) {
            $("#" + neRefId + "LiftPortalView" + i).height(calHeight);
        }
    }
}

function getNoOfSubSystemPresents() {
    var node = getSelectedNode();
    var noOfSubSystems = 0;
    var nodeType = "";
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                nodeType = node.attributes.type;
                if (nodeType === $.i18n.prop('SUB_SYSTEM_STR') && nodeToProcess.attributes.subSystemType === "Lift") {
                    noOfSubSystems = 1;
                } else {
                    var selectedTabName = $("#treeTab .tabs-selected").text();
                    var nodeChildren = "";
                    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
                        nodeChildren = $('#networkTree').tree('getChildren', node.target);
                    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
                        nodeChildren = $('#logicalTree').tree('getChildren', node.target);
                    }
                    for (var i = 0; i < nodeChildren.length; i++) {
                        var nodeToProcess = nodeChildren[i];
                        if (nodeToProcess !== null && nodeToProcess !== "" && nodeToProcess !== undefined) {
                            if (nodeToProcess.attributes !== null && nodeToProcess.attributes !== "" && nodeToProcess.attributes !== undefined) {
                                if (nodeToProcess.attributes.type !== undefined && nodeToProcess.attributes.type !== null && nodeToProcess.attributes.type !== "") {
                                    nodeType = nodeToProcess.attributes.type;
                                    if (nodeType === $.i18n.prop('SUB_SYSTEM_STR') && nodeToProcess.attributes.subSystemType === "Lift") {
                                        noOfSubSystems++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return noOfSubSystems;
}

function getLiftDataFromDB(neRefId) {
    var data = "";
    var rows = [];
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                var nodeType = node.attributes.type;
                var subSystem = "";
                var subSystemId = "";
                var neId = "";
                var statusBarId = neRefId + "Lift";
                var URL = $.i18n.prop('SERVER_URL') + "/FormMgrWithList";
                var parameters = "";
                var replyFormat = "";
                if (nodeType === $.i18n.prop('SUB_SYSTEM_STR') && nodeToProcess.attributes.subSystemType === "Lift") {
                    subSystem = node.attributes.subSystemType.replace("EL Measure", "ELM").replace(" Inverter", "");
                    subSystemId = node.attributes.subSystemId;
                    neId = node.attributes.neId;
                    //parameters = "requestType=NEManager&subRequestType=getLiftData&QueryNum=3221&key=LIFT_DATA&Parm1=" + neId + "&Parm2=" + subSystemId + "&Parm3=" + 1;
                    parameters = "requestType=NEManager&subRequestType=getLiftData&QueryNum=3221&key=LIFT_DATA&Parm1=" + neId + "&Parm2=" + subSystemId;
                    replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
                    data = eval('(' + replyFormat + ')');
                    updateStatusMessage(data, statusBarId);
                    rows = data.rows;
                } else if (nodeType === $.i18n.prop('BUILDING_STR')) {
                    if (node !== null && node !== "" && node !== undefined) {
                        var selectedTabName = $("#treeTab .tabs-selected").text();
                        var nodeChildren = "";
                        if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
                            nodeChildren = $('#networkTree').tree('getChildren', node.target);
                        } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
                            nodeChildren = $('#logicalTree').tree('getChildren', node.target);
                        }
                        for (var i = 0; i < nodeChildren.length; i++) {
                            var nodeToProcess = nodeChildren[i];
                            if (nodeToProcess !== null && nodeToProcess !== "" && nodeToProcess !== undefined) {
                                if (nodeToProcess.attributes !== null && nodeToProcess.attributes !== "" && nodeToProcess.attributes !== undefined) {
                                    if (nodeToProcess.attributes.type !== undefined && nodeToProcess.attributes.type !== null && nodeToProcess.attributes.type !== "") {
                                        nodeType = nodeToProcess.attributes.type;
                                        subSystem = nodeToProcess.attributes.subSystemType.replace("EL Measure", "ELM").replace(" Inverter", "");
                                        if (nodeType === $.i18n.prop('SUB_SYSTEM_STR') && subSystem.toUpperCase() === $.i18n.prop('LIFT_STR')) {
                                            subSystemId = nodeToProcess.attributes.subSystemId;
                                            neId = nodeToProcess.attributes.neId;
                                            //parameters = "requestType=NEManager&subRequestType=getLiftData&QueryNum=3221&key=LIFT_DATA&Parm1=" + neId + "&Parm2=" + subSystemId + "&Parm3=" + 1;
                                            parameters = "requestType=NEManager&subRequestType=getLiftData&QueryNum=3221&key=LIFT_DATA&Parm1=" + neId + "&Parm2=" + subSystemId;
                                            replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
                                            data = eval('(' + replyFormat + ')');
                                            updateStatusMessage(data, statusBarId);
                                            rows.push(data.rows[0]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return rows;
}

function refreshLiftData(operationId, neRefId, subSystemType, subSystemVersion) {
    $("#" + neRefId + "LiftLayout").block();
    var leafs = [];
    var node = getSelectedNode();
    leafs.push(node);
    SingleLiftView(operationId, neRefId, subSystemType, subSystemVersion, leafs);
    $(".liftgroup").css('stroke', $(".panel-header").css('border-top-color'));
    $(".liftgroup").css('stroke-width', '0.3');
    $(".liftgroup").css('fill', $(".panel-body").css('color'));
    $("#" + neRefId + "LiftLayout").unblock();
}

function refreshAllLiftData(neRefId, operationId) {
    $.block();
    ThreeLiftView(neRefId);
    $(".liftgroup").css('stroke', $(".panel-header").css('border-top-color'));
    $(".liftgroup").css('stroke-width', '0.3');
    $(".liftgroup").css('fill', $(".panel-body").css('color'));
    $.unblock();
}

function loadLiftView(liftViewId, data) {
    $("#" + liftViewId).block();
    var clientURL = $.i18n.prop('CLIENT_URL');
    var liftContent = '<svg version="1.1" baseProfile="full" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" width="100%" height="100%" style="overflow:hidden" fill="transparent" viewBox="0 0 100 100" preserveAspectRatio="none" zoomAndPan="magnify">' +
        '<defs>' +
        '<marker id="up" orient="auto" markerWidth="2" markerHeight="4" refX="0.1" refY="2" markerUnits="strokeWidth">' +
        '<path d="M0,0 V4 L2,2 Z" fill="red"/>' +
        '</marker>' +
        '<marker id="down" orient="auto" markerWidth="2" markerHeight="4" refX="0.1" refY="2" markerUnits="strokeWidth">' +
        '<path d="M0,0 V4 L2,2 Z" fill="red"/>' +
        '</marker>' +
        '</defs>' +
        '<g class="liftgroup">' +
        '<rect x="1" y="1" width="100" height="99" fill="transparent"/>' +
        '<rect x="1" y="1" width="30" height="99" fill="transparent"/>' +
        '<rect x="90" y="1" width="10" height="99" fill="transparent"/>';
    if (data.doorStatus === "1" || data.doorStatus === 1) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/doorfullyopen.gif" preserveAspectRatio="none" x="31.2" y="1" width="58.5" height="99" qtip-content="Door Status - Fully opened"/>';
    } else if (data.doorStatus === "2" || data.doorStatus === 2 || data.doorStatus === "0" || data.doorStatus === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/doorfullyclosed.gif" preserveAspectRatio="none" x="31.2" y="1" width="58.5" height="99" qtip-content="Door Status - Fully closed"/>';
    } else if (data.doorStatus === "3" || data.doorStatus === 3) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/doorpartiallyopen.gif" preserveAspectRatio="none" x="31.2" y="1" width="58.5" height="99" qtip-content="Door Status - Partially open"/>';
    }
    if (data.travelStatus === "1" || data.travelStatus === 1) {
        liftContent += '<rect x="90" y="35" width="10" height="10" fill="transparent"/>' +
            '<path id="travellingUp" stroke-width="0.5" fill="red" stroke="red" d="M95,42 L95,39" marker-end="url(#up)" stroke-dasharray="1,1,1" qtip-content="Direction Of Travel - Up direction">' +
            '<animateMotion dur="1s" repeatCount="indefinite" path="M0 0 0 -1 0 -2 0 -3"/>' +
            '</path>' +
            '<text x="95" y="43" alignment-baseline="middle" text-anchor="middle" style= "font-size:4px;font-weight:bold;font-style:normal;" fill="red" stroke="none" qtip-content="Floor Position - ' + data.floorPosition + '">' + data.floorPosition + '</text>' +
            '<rect x="90" y="45" width="10" height="10" fill="transparent"/>' +
            '<path d="M95.2 47 L93.7 50 L96.7 50 Z" fill="green" stroke="green" stroke-width="0.2" />' +
            '<path d="M95.2 54 L93.7 51 L96.7 51 Z" fill="transparent" stroke-width="0.2" />';
    } else if (data.travelStatus === "2" || data.travelStatus === 2) {
        liftContent += '<rect x="90" y="35" width="10" height="10" fill="transparent"/>' +
            '<path stroke-width="0.5" fill="red" stroke="red" d="M95,41 L95,38" marker-end="url(#up)" stroke-dasharray="1,1,1" qtip-content="Direction Of Travel - Not Traveling"/>' +
            '<text x="95" y="43" alignment-baseline="middle" text-anchor="middle" style= "font-size:4px;font-weight:bold;font-style:normal;" fill="red" stroke="none" qtip-content="Floor Position - ' + data.floorPosition + '">' + data.floorPosition + '</text>' +
            '<rect x="90" y="45" width="10" height="10" fill="transparent"/>' +
            '<path d="M95.2 47 L93.7 50 L96.7 50 Z" fill="blue" stroke="blue" stroke-width="0.2" />' +
            '<path d="M95.2 54 L93.7 51 L96.7 51 Z" fill="transparent" stroke-width="0.2" />';
    } else if (data.travelStatus === "5" || data.travelStatus === 5) {
        liftContent += '<rect x="90" y="35" width="10" height="10" fill="transparent"/>' +
            '<path id="travellingDown"  stroke-width="0.5" fill="red" stroke="red" d="M95,35 L95,38" marker-end="url(#down)" stroke-dasharray="1,1,1" qtip-content="Direction Of Travel - Down direction">' +
            '<animateMotion dur="1s" repeatCount="indefinite" path="M0 0 0 1 0 2 0 3"/>' +
            '</path>' +
            '<text x="95" y="43" alignment-baseline="middle" text-anchor="middle" style= "font-size:4px;font-weight:bold;font-style:normal;" fill="red" stroke="none" qtip-content="Floor Position - ' + data.floorPosition + '">' + data.floorPosition + '</text>' +
            '<rect x="90" y="45" width="10" height="10" fill="transparent"/>' +
            '<path d="M95.2 47 L93.7 50 L96.7 50 Z" fill="transparent" stroke-width="0.2" />' +
            '<path d="M95.2 54 L93.7 51 L96.7 51 Z" fill="green" stroke="green" stroke-width="0.2" />';
    } else if (data.travelStatus === "6" || data.travelStatus === 6) {
        liftContent += '<rect x="90" y="35" width="10" height="10" fill="transparent"/>' +
            '<path stroke-width="0.5" fill="red" stroke="red" d="M95,35 L95,38" marker-end="url(#down)" stroke-dasharray="1,1,1" qtip-content="Direction Of Travel - Not Traveling"/>' +
            '<text x="95" y="43" alignment-baseline="middle" text-anchor="middle" style= "font-size:4px;font-weight:bold;font-style:normal;" fill="red" stroke="none" qtip-content="Floor Position - ' + data.floorPosition + '">' + data.floorPosition + '</text>' +
            '<rect x="90" y="45" width="10" height="10" fill="transparent"/>' +
            '<path d="M95.2 47 L93.7 50 L96.7 50 Z" fill="transparent" stroke-width="0.2" />' +
            '<path d="M95.2 54 L93.7 51 L96.7 51 Z" fill="blue" stroke="blue" stroke-width="0.2" />';
    } else {
        liftContent += '<rect x="90" y="35" width="10" height="10" fill="transparent"/>' +
            '<text x="95" y="43" alignment-baseline="middle" text-anchor="middle" style= "font-size:4px;font-weight:bold;font-style:normal;" fill="red" stroke="none" qtip-content="Floor Position - ' + data.floorPosition + '">' + data.floorPosition + '</text>' +
            '<rect x="90" y="45" width="10" height="10" fill="transparent"/>' +
            '<path d="M95.2 47 L93.7 50 L96.7 50 Z" fill="transparent" stroke-width="0.2" />' +
            '<path d="M95.2 54 L93.7 51 L96.7 51 Z" fill="transparent" stroke-width="0.2" />';
    }
    if (data.liftOperationMode === "0" || data.liftOperationMode === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/auto.gif" preserveAspectRatio="none" x="11" y="2" width="8" height="8" qtip-content="Operation Mode - Auto"/>' +
            '<text x="16" y="13" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">OPERATION MODE</text>';
    } else if (data.liftOperationMode === "1" || data.liftOperationMode === 1) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/auto.gif" preserveAspectRatio="none" x="11" y="2" width="8" height="8" qtip-content="Operation Mode - Attendant"/>' +
            '<text x="16" y="13" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">OPERATION MODE</text>';
    }
    if (data.carAlarm === "0" || data.carAlarm === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/caralarmgray.gif" preserveAspectRatio="none" x="11" y="15" width="8" height="8" qtip-content="Car Alarm - Not Present"/>' +
            '<text x="15" y="26" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">CAR ALARM</text>';
    } else if (data.carAlarm === "1" || data.carAlarm === 1) {
        liftContent += '<circle class="blinkCircle" cx="15" cy="20" r="5" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/lift/caralarm.gif" preserveAspectRatio="none" x="11" y="16" width="8" height="8" qtip-content="Car Alarm - Present"/>' +
            '<text x="15" y="27.5" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">CAR ALARM</text>';
    }
    if (data.powerFailed === "0" || data.powerFailed === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/powerfailedgray.gif" preserveAspectRatio="none" x="11" y="28" width="8" height="8" qtip-content="Power Failed Mode - Not Present"/>' +
            '<text x="15" y="39" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">POWER FAILURE</text>';
    } else if (data.powerFailed === "1" || data.powerFailed === 1) {
        liftContent += '<circle class="blinkCircle" cx="15" cy="34" r="5" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/lift/powerfailed.gif" preserveAspectRatio="none" x="11" y="30" width="8" height="8" qtip-content="Power Failed Mode - Present"/>' +
            '<text x="15" y="41.5" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">POWER FAILURE</text>';
    }
    if (data.maintenanceMode === "0" || data.maintenanceMode === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/maintenancegray.gif" preserveAspectRatio="none" x="11" y="41" width="8" height="8" qtip-content="Maintenance Mode - Not Present"/>' +
            '<text x="16" y="52" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">MAINTENANCE MODE</text>';
    } else if (data.maintenanceMode === "1" || data.maintenanceMode === 1) {
        liftContent += '<circle class="blinkCircle" cx="15" cy="48" r="5" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/lift/maintenance.gif" preserveAspectRatio="none" x="11" y="44" width="8" height="8" qtip-content="Maintenance Mode - Present"/>' +
            '<text x="16" y="55.5" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">MAINTENANCE MODE</text>';
    }
    if (data.fireManMode === "0" || data.fireManMode === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/firegray.gif" preserveAspectRatio="none" x="11" y="54" width="8" height="8" qtip-content="Fire Man Mode - Not Present"/>' +
            '<text x="15" y="65" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">FIRE MAN MODE</text>';
    } else if (data.fireManMode === "1" || data.fireManMode === 1) {
        liftContent += '<circle class="blinkCircle" cx="15" cy="62" r="5" stroke="red" stroke-width="0.4" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/lift/fire.gif" preserveAspectRatio="none" x="11" y="58" width="8" height="8" qtip-content="Fire Man Mode - Present"/>' +
            '<text x="16" y="69.5" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">FIRE MAN MODE</text>';
    }
    if (data.rescueMode === "0" || data.rescueMode === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/rescuegray.gif" preserveAspectRatio="none" x="11" y="67" width="8" height="8" qtip-content="Rescue Mode - Not Present"/>' +
            '<text x="15" y="78" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">RESCUE MODE</text>';
    } else if (data.rescueMode === "1" || data.rescueMode === 1) {
        liftContent += '<circle class="blinkCircle" cx="15" cy="76" r="5" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/lift/rescue.gif" preserveAspectRatio="none" x="11" y="72" width="8" height="8" qtip-content="Rescue Mode - Present"/>' +
            '<text x="16" y="83.5" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">RESCUE MODE</text>';
    }
    if (data.vvvfTrip === "0" || data.vvvfTrip === 0) {
        liftContent += '<image xlink:href="' + clientURL + '/common/images/lift/vvvfgray.gif" preserveAspectRatio="none" x="11" y="80" width="8" height="8" qtip-content="VF Trip Mode - Not Present"/>' +
            '<text x="16" y="91" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">VF TRIP MODE</text>';
    } else if (data.vvvfTrip === "1" || data.vvvfTrip === 1) {
        liftContent += '<circle class="blinkCircle" cx="15" cy="90" r="5" stroke="red" stroke-width="0.5" fill="transparent"/>' +
            '<image xlink:href="' + clientURL + '/common/images/lift/vvvf.gif" preserveAspectRatio="none" x="11" y="86" width="8" height="8" qtip-content="VF Trip Mode - Present"/>' +
            '<text x="16" y="97.5" alignment-baseline="middle" text-anchor="middle" stroke="transparent" stroke-width="0" style="font-size:2.5px;font-weight:bold;font-style:normal;">VF TRIP MODE</text>';
    }
    liftContent += '</g></svg>';
    $("#" + liftViewId).empty().html(liftContent);
    $("#" + liftViewId + ' svg image, path, text').each(function () {
        $(this).qtip({
            overwrite: true,
            content: {
                text: $(this).attr('qtip-content')
            },
            show: {
                delay: 100
            },
            hide: {
                fixed: true
            }
        });
    });
    $("#" + liftViewId).unblock();
}

function getLiftDataFromDevice(operationName, operationId, subSystemType, subSystemVersion, neRefId, node) {
    var typeWithVersion = subSystemType;
    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
        typeWithVersion = subSystemType + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
    }
    var data = "";
    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
        var subSystemId = node.attributes.subSystemId;
        var neId = node.attributes.neId;
        var neName = node.attributes.neName;
        var neVersion = node.attributes.neVersionNumber;
        var neTypeName = node.attributes.neTypeName;
        var agentId = node.attributes.agentId;
        var agentIp = node.attributes.agentIp;
        var agentPort = node.attributes.agentPort;
        var agentUserId = node.attributes.agentUserId;
        var agentMobileNumber = node.attributes.agentMobileNumber;
        var subSystemName = node.text;
        var subSystemTypeId = node.attributes.subSystemTypeId;
        var goaMeterURL = $.i18n.prop('SERVER_URL') + "/getHandler";
        var parameters = "requestType=ElectricalMeters&subRequestType=getDeviceData&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&neId=" + neId + "&neName=" + neName + "&neVersion=" + neVersion + "&neTypeName=" + neTypeName + "&agentId=" + agentId + "&ipAddress=" + agentIp + "&port=" + agentPort + "&subSystemId=" + subSystemId + "&subSystem=" + subSystemType + "&operationType=GET&operationId=" + operationId + "&operationName=" + operationName + "&uniqueId=" + agentUserId + "&mobileNumber=" + agentMobileNumber + "&subSystemName=" + subSystemName + "&typeWithVersion=" + typeWithVersion + "&subSystemVersion=" + subSystemVersion + "&neRefId=" + $.trim(neRefId) + "&subSystemTypeId=" + subSystemTypeId;
        var replyFormat = getDataFromServer("POST", goaMeterURL, $.deserialize(parameters), "text");
        var replyFormatStr = replyFormat.toString();
        var replyFormatJson = $.trim(replyFormatStr).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/\\"/g, '"').replace(/\\\\"/g, '"').replace(/"{/g, "{").replace(/}"/g, "}");
        data = eval('(' + replyFormatJson + ')');
    }
    return data;
}

function showLiftsInBuildings(operationId, neRefId, subSystemType, subSystemVersion) {
    $("#" + neRefId + "LiftLayout").block();
    var subSystemArray = {};
    var t = null;
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        t = $('#networkTree');
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        t = $('#logicalTree');
    }

    var selectedNode = getSelectedNode();
    var leafs = [];
    var liftLeafs = [];
    $.map(t.tree('getChildren', selectedNode.target), function (node) {
        if (t.tree('isLeaf', node.target)) {
            leafs.push(node);
        }
    });
    $.each(leafs, function (index, leaf) {
        if (leaf.attributes !== null && leaf.attributes !== "" && leaf.attributes !== undefined) {
            if (leaf.attributes.subSystemType !== null && leaf.attributes.subSystemType !== "" && leaf.attributes.subSystemType !== undefined) {
                var subSystemName = leaf.attributes.subSystemType;
                if (subSystemName.toUpperCase() === "LIFT") {
                    liftLeafs.push(leaf);
                    if (!subSystemArray[subSystemName]) {
                        subSystemArray[subSystemName] = 1;
                    } else if (subSystemArray[subSystemName]) {
                        subSystemArray[subSystemName] += 1;
                    }
                }
            }
        }
    });
    var numberOfLists = subSystemArray.Lift;
    switch (numberOfLists) {
        case 1:
            SingleLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
        case 2:
            TwoLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
        case 3:
            ThreeLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
        case 4:
            FourLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
    }
    $(".liftgroup").css('stroke', $(".panel-header").css('border-top-color'));
    $(".liftgroup").css('stroke-width', '0.3');
    $(".liftgroup").css('fill', $(".panel-body").css('color'));
    $("#" + neRefId + "LiftLayout").unblock();
}

function showLiftsInBuilding(operationId, neRefId, subSystemType, subSystemVersion) {
    $("#" + neRefId + "LiftLayout").block();
    var subSystemArray = {};
    var t = null;
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        t = $('#networkTree');
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        t = $('#logicalTree');
    }
    var leafs = [];
    var liftLeafs = [];
    var selBuildingNode = getSelectedNode();
    $.map(t.tree('getChildren', selBuildingNode.target), function (node) {
        if (t.tree('isLeaf', node.target)) {
            leafs.push(node);
        }
    });
    $.each(leafs, function (index, leaf) {
        if (leaf.attributes !== null && leaf.attributes !== "" && leaf.attributes !== undefined) {
            if (leaf.attributes.subSystemType !== null && leaf.attributes.subSystemType !== "" && leaf.attributes.subSystemType !== undefined) {
                var subSystemName = leaf.attributes.subSystemType;
                if (subSystemName.toUpperCase() === "LIFT") {
                    liftLeafs.push(leaf);
                    if (!subSystemArray[subSystemName]) {
                        subSystemArray[subSystemName] = 1;
                    } else if (subSystemArray[subSystemName]) {
                        subSystemArray[subSystemName] += 1;
                    }
                }
            }
        }
    });
    var numberOfLists = subSystemArray.Lift;
    switch (numberOfLists) {
        case 1:
            SingleLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
        case 2:
            TwoLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
        case 3:
            ThreeLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
        case 4:
            FourLiftView(operationId, neRefId, subSystemType, subSystemVersion, liftLeafs);
            break;
    }
    $(".liftgroup").css('stroke', $(".panel-header").css('border-top-color'));
    $(".liftgroup").css('stroke-width', '0.3');
    $(".liftgroup").css('fill', $(".panel-body").css('color'));
    $("#" + neRefId + "LiftLayout").unblock();
}

function SingleLiftView(operationId, neRefId, subSystemType, subSystemVersion, leafs) {
    var liftContent = '<div id="' + neRefId + 'LiftPanel" class="liftPanel easyui-panel" title=" " style="width:50%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift" class="' + neRefId + 'Lift liftView" style="width:100%;height:100%"></div>' +
        '</div>';
    $("#" + neRefId + "LiftView").empty().html(liftContent);
    $("#" + neRefId + "LiftPanel").panel();
    $.each(leafs, function (index, leaf) {
        var data = {
            floorPosition: 0,
            travelStatus: 0,
            liftOperationMode: 0,
            doorStatus: 0,
            carAlarm: 0,
            powerFailed: 0,
            fireManMode: 0,
            maintenanceMode: 0,
            rescueMode: 0,
            vvvfTrip: 0
        };
        if (leaf.attributes !== null && leaf.attributes !== "" && leaf.attributes !== undefined) {
            var leafSubSystemType = leaf.attributes.subSystemType;
            if (leafSubSystemType !== null && leafSubSystemType !== "" && leafSubSystemType !== undefined) {
                if (leafSubSystemType.toUpperCase() === "LIFT") {
                    if (leaf.attributes.subSystemDisplayName !== undefined && leaf.attributes.subSystemDisplayName !== null && leaf.attributes.subSystemDisplayName !== "") {
                        var subSysDisplayName = leaf.attributes.subSystemDisplayName;
                        $("#" + neRefId + "LiftPanel").panel('setTitle', subSysDisplayName);
                    }
                    var replyFormat = getLiftDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId, leaf);
                    //getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId);
                    var deviceData = replyFormat.devicedata;
                    try {
                        if (parseInt(deviceData.statusCode) === 0) {
                            data = deviceData.data[0];
                        }
                    } catch (e) {
                        //Do Nothing
                    }
                    updateStatusMessage(replyFormat, neRefId + "Lift");
                }
            }
        }
        loadLiftView(neRefId + "Lift", data);
    });
}

function TwoLiftView(operationId, neRefId, subSystemType, subSystemVersion, leafs) {
    var liftContent = '<div id="' + neRefId + 'LiftPortal" class="liftPortal" data-options="fit:true" border="false">' +
        '<div id="' + neRefId + 'LiftPortalView1" class="liftPortalView" style="width:50%">' +
        '<div id="' + neRefId + 'Lift1Panel" class="liftPanel easyui-panel" title="Lift 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift1" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView2" class="liftPortalView" style="width:50%">' +
        '<div id="' + neRefId + 'Lift2Panel" class="liftPanel easyui-panel" title="Lift 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift2" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + neRefId + "LiftView").empty().html(liftContent);
    var calHeight = Math.floor($("#" + neRefId + "LiftView").height() - 4);
    $("#" + neRefId + "LiftPortalView1").height(calHeight);
    $("#" + neRefId + "LiftPortalView2").height(calHeight);
    $("#" + neRefId + "LiftPortal").portal({
        border: false,
        fit: true,
        width: $("#" + neRefId + "LiftView").width(),
        height: $("#" + neRefId + "LiftView").height()
    });
    $.each(leafs, function (index, leaf) {
        var data = {
            floorPosition: 0,
            travelStatus: 0,
            liftOperationMode: 0,
            doorStatus: 0,
            carAlarm: 0,
            powerFailed: 0,
            fireManMode: 0,
            maintenanceMode: 0,
            rescueMode: 0,
            vvvfTrip: 0
        };
        if (leaf.attributes !== null && leaf.attributes !== "" && leaf.attributes !== undefined) {
            var leafSubSystemType = leaf.attributes.subSystemType;
            if (leafSubSystemType !== null && leafSubSystemType !== "" && leafSubSystemType !== undefined) {
                if (leafSubSystemType.toUpperCase() === "LIFT") {
                    if (leaf.attributes.subSystemDisplayName !== undefined && leaf.attributes.subSystemDisplayName !== null && leaf.attributes.subSystemDisplayName !== "") {
                        var subSysDisplayName = leaf.attributes.subSystemDisplayName;
                        $("#" + neRefId + "Lift" + (index + 1) + "Panel").panel('setTitle', subSysDisplayName);
                    }
                    var replyFormat = getLiftDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId, leaf);
                    //getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId);
                    var deviceData = replyFormat.devicedata;
                    try {
                        if (parseInt(deviceData.statusCode) === 0) {
                            data = deviceData.data[0];
                        }
                    } catch (e) {
                        //Do Nothing
                    }
                    updateStatusMessage(replyFormat, neRefId + "Lift");
                }
            }
        }
        loadLiftView(neRefId + "Lift" + (index + 1), data);
    });
}

function ThreeLiftView(operationId, neRefId, subSystemType, subSystemVersion, leafs) {
    var liftContent = '<div id="' + neRefId + 'LiftPortal" class="liftPortal" data-options="fit:true" border="false">' +
        '<div id="' + neRefId + 'LiftPortalView1" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift1Panel" class="liftPanel easyui-panel" title="Lift 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift1" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView2" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift2Panel" class="liftPanel easyui-panel" title="Lift 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift2" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView3" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift3Panel" class="liftPanel easyui-panel" title="Lift 3" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift3" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + neRefId + "LiftView").empty().html(liftContent);
    var calHeight = Math.floor($("#" + neRefId + "LiftView").height() - 4);
    $("#" + neRefId + "LiftPortalView1").height(calHeight);
    $("#" + neRefId + "LiftPortalView2").height(calHeight);
    $("#" + neRefId + "LiftPortalView3").height(calHeight);
    $("#" + neRefId + "LiftPortal").portal({
        border: false,
        fit: true,
        width: $("#" + neRefId + "LiftView").width(),
        height: $("#" + neRefId + "LiftView").height()
    });
    $.each(leafs, function (index, leaf) {
        var data = {
            floorPosition: 0,
            travelStatus: 0,
            liftOperationMode: 0,
            doorStatus: 0,
            carAlarm: 0,
            powerFailed: 0,
            fireManMode: 0,
            maintenanceMode: 0,
            rescueMode: 0,
            vvvfTrip: 0
        };
        if (leaf.attributes !== null && leaf.attributes !== "" && leaf.attributes !== undefined) {
            var leafSubSystemType = leaf.attributes.subSystemType;
            if (leafSubSystemType !== null && leafSubSystemType !== "" && leafSubSystemType !== undefined) {
                if (leafSubSystemType.toUpperCase() === "LIFT") {
                    if (leaf.attributes.subSystemDisplayName !== undefined && leaf.attributes.subSystemDisplayName !== null && leaf.attributes.subSystemDisplayName !== "") {
                        var subSysDisplayName = leaf.attributes.subSystemDisplayName;
                        $("#" + neRefId + "Lift" + (index + 1) + "Panel").panel('setTitle', subSysDisplayName);
                    }
                    var replyFormat = getLiftDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId, leaf);
                    //getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId);
                    var deviceData = replyFormat.devicedata;
                    try {
                        if (parseInt(deviceData.statusCode) === 0) {
                            data = deviceData.data[0];
                        }
                    } catch (e) {
                        //Do Nothing
                    }
                    updateStatusMessage(replyFormat, neRefId + "Lift");
                }
            }
        }
        loadLiftView(neRefId + "Lift" + (index + 1), data);
    });
}

function FourLiftView(operationId, neRefId, subSystemType, subSystemVersion, leafs) {
    var liftContent = '<div id="' + neRefId + 'LiftPortal" class="liftPortal" data-options="fit:true" border="false">' +
        '<div id="' + neRefId + 'LiftPortalView1" class="liftPortalView" style="width:50%">' +
        '<div id="' + neRefId + 'Lift1Panel" class="liftPanel easyui-panel" title="Lift 1" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift1" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift3Panel" class="liftPanel easyui-panel" title="Lift 3" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift3" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView2" class="liftPortalView" style="width:50%">' +
        '<div id="' + neRefId + 'Lift2Panel" class="liftPanel easyui-panel" title="Lift 2" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift2" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift4Panel" class="liftPanel easyui-panel" title="Lift 4" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift4" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + neRefId + "LiftView").empty().html(liftContent);
    var calHeight = Math.floor($("#" + neRefId + "LiftView").height() - 4);
    $("#" + neRefId + "LiftPortalView1").height(calHeight);
    $("#" + neRefId + "LiftPortalView2").height(calHeight);
    $("#" + neRefId + "LiftPortal").portal({
        border: false,
        fit: true,
        width: $("#" + neRefId + "LiftView").width(),
        height: $("#" + neRefId + "LiftView").height()
    });
    $.each(leafs, function (index, leaf) {
        var data = {
            floorPosition: 0,
            travelStatus: 0,
            liftOperationMode: 0,
            doorStatus: 0,
            carAlarm: 0,
            powerFailed: 0,
            fireManMode: 0,
            maintenanceMode: 0,
            rescueMode: 0,
            vvvfTrip: 0
        };
        if (leaf.attributes !== null && leaf.attributes !== "" && leaf.attributes !== undefined) {
            var leafSubSystemType = leaf.attributes.subSystemType;
            if (leafSubSystemType !== null && leafSubSystemType !== "" && leafSubSystemType !== undefined) {
                if (leafSubSystemType.toUpperCase() === "LIFT") {
                    if (leaf.attributes.subSystemDisplayName !== undefined && leaf.attributes.subSystemDisplayName !== null && leaf.attributes.subSystemDisplayName !== "") {
                        var subSysDisplayName = leaf.attributes.subSystemDisplayName;
                        $("#" + neRefId + "Lift" + (index + 1) + "Panel").panel('setTitle', subSysDisplayName);
                    }
                    var replyFormat = getLiftDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId, leaf);
                    //getDataFromDevice(subSystemType + "_POLLED_DATA", operationId, subSystemType, subSystemVersion, neRefId);
                    var deviceData = replyFormat.devicedata;
                    try {
                        if (parseInt(deviceData.statusCode) === 0) {
                            data = deviceData.data[0];
                        }
                    } catch (e) {
                        //Do Nothing
                    }
                    updateStatusMessage(replyFormat, neRefId + "Lift");
                }
            }
        }
        loadLiftView(neRefId + "Lift" + (index + 1), data);
    });
}

function SixLiftView(neRefId) {
    var liftContent = '<div id="' + neRefId + 'LiftPortal" class="liftPortal" data-options="fit:true" border="false">' +
        '<div id="' + neRefId + 'LiftPortalView1" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift1Panel" class="liftPanel easyui-panel" title="Lift 1" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift1" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift4Panel" class="liftPanel easyui-panel" title="Lift 4" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift4" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView2" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift2Panel" class="liftPanel easyui-panel" title="Lift 2" style="width:50%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift2" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift5Panel" class="liftPanel easyui-panel" title="Lift 5" style="width:50%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift5" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView3" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift3Panel" class="liftPanel easyui-panel" title="Lift 3" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift3" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift6Panel" class="liftPanel easyui-panel" title="Lift 6" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift6" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + neRefId + "LiftView").empty().html(liftContent);
    var calHeight = Math.floor($("#" + neRefId + "LiftView").height() - 4);
    $("#" + neRefId + "LiftPortalView1").height(calHeight);
    $("#" + neRefId + "LiftPortalView2").height(calHeight);
    $("#" + neRefId + "LiftPortalView3").height(calHeight);
    $("#" + neRefId + "LiftPortal").portal({
        border: false,
        fit: true,
        width: $("#" + neRefId + "LiftView").width(),
        height: $("#" + neRefId + "LiftView").height()
    });
    var data = getLiftDataFromDB(neRefId);
    $.each(data, function (index, row) {
        loadLiftView(neRefId + "Lift" + (index + 1), row);
    });
}

function EightLiftView(neRefId) {
    var liftContent = '<div id="' + neRefId + 'LiftPortal" class="liftPortal" data-options="fit:true" border="false">' +
        '<div id="' + neRefId + 'LiftPortalView1" class="liftPortalView" style="width:25%">' +
        '<div id="' + neRefId + 'Lift1Panel" class="liftPanel easyui-panel" title="Lift 1" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift1" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift5Panel" class="liftPanel easyui-panel" title="Lift 5" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift5" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView2" class="liftPortalView" style="width:25%">' +
        '<div id="' + neRefId + 'Lift2Panel" class="liftPanel easyui-panel" title="Lift 2" style="width:50%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift2" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift6Panel" class="liftPanel easyui-panel" title="Lift 6" style="width:50%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift6" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView3" class="liftPortalView" style="width:25%">' +
        '<div id="' + neRefId + 'Lift3Panel" class="liftPanel easyui-panel" title="Lift 3" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift3" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift7Panel" class="liftPanel easyui-panel" title="Lift 7" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift7" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView4" class="liftPortalView" style="width:25%">' +
        '<div id="' + neRefId + 'Lift4Panel" class="liftPanel easyui-panel" title="Lift 4" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift4" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift8Panel" class="liftPanel easyui-panel" title="Lift 8" style="width:100%;height:50%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift8" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + neRefId + "LiftView").empty().html(liftContent);
    var calHeight = Math.floor($("#" + neRefId + "LiftView").height() - 4);
    $("#" + neRefId + "LiftPortalView1").height(calHeight);
    $("#" + neRefId + "LiftPortalView2").height(calHeight);
    $("#" + neRefId + "LiftPortalView3").height(calHeight);
    $("#" + neRefId + "LiftPortalView4").height(calHeight);
    $("#" + neRefId + "LiftPortal").portal({
        border: false,
        fit: true,
        width: $("#" + neRefId + "LiftView").width(),
        height: $("#" + neRefId + "LiftView").height()
    });
    var data = getLiftDataFromDB(neRefId);
    $.each(data, function (index, row) {
        loadLiftView(neRefId + "Lift" + (index + 1), row);
    });
}

function NineLiftView(neRefId) {
    var liftContent = '<div id="' + neRefId + 'LiftPortal" class="liftPortal" data-options="fit:true" border="false">' +
        '<div id="' + neRefId + 'LiftPortalView1" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift1Panel" class="liftPanel easyui-panel" title="Lift 1" style="width:100%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift1" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift4Panel" class="liftPanel easyui-panel" title="Lift 4" style="width:100%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift4" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift7Panel" class="liftPanel easyui-panel" title="Lift 7" style="width:100%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift7" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView2" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift2Panel" class="liftPanel easyui-panel" title="Lift 2" style="width:50%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift2" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift5Panel" class="liftPanel easyui-panel" title="Lift 5" style="width:100%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift5" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift8Panel" class="liftPanel easyui-panel" title="Lift 8" style="width:50%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift8" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '<div id="' + neRefId + 'LiftPortalView3" class="liftPortalView" style="width:33%">' +
        '<div id="' + neRefId + 'Lift3Panel" class="liftPanel easyui-panel" title="Lift 3" style="width:100%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift3" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift6Panel" class="liftPanel easyui-panel" title="Lift 6" style="width:100%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift6" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '<div id="' + neRefId + 'Lift9Panel" class="liftPanel easyui-panel" title="Lift 9" style="width:100%;height:33%;padding:1px" border="true">' +
        '<div id="' + neRefId + 'Lift9" class="liftView" style="width:100%;height:100%"></div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + neRefId + "LiftView").empty().html(liftContent);
    var calHeight = Math.floor($("#" + neRefId + "LiftView").height() - 4);
    $("#" + neRefId + "LiftPortalView1").height(calHeight);
    $("#" + neRefId + "LiftPortalView2").height(calHeight);
    $("#" + neRefId + "LiftPortalView3").height(calHeight);
    $("#" + neRefId + "LiftPortal").portal({
        border: false,
        fit: true,
        width: $("#" + neRefId + "LiftView").width(),
        height: $("#" + neRefId + "LiftView").height()
    });
    var data = getLiftDataFromDB(neRefId);
    $.each(data, function (index, row) {
        loadLiftView(neRefId + "Lift" + (index + 1), row);
    });
}
