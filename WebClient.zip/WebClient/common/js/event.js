var ctrlAgentEventEndPntFormData = {};
var snmpAgentEventEndPntFormData = {};

function getAgentEventEndPntFormData(eventName, neId, agentId, type) {
    var URL = $.i18n.prop('SERVER_URL') + "/FormMgr";
    var parameters = "requestType=EventMgmt&subRequestType=refreshAgentEventEmailAndSmsDetails&QueryNum=5047&key=AGENT_EVENT_END_POINT_DETAILS&operationId=${param.id}&Parm1=" + eventName + "&Parm2=" + neId + "&Parm3=" + agentId;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, type + "AgentEventList");
    if (type === "ctrl") {
        ctrlAgentEventEndPntFormData = data.formdata;
    } else if (type === "snmp") {
        snmpAgentEventEndPntFormData = data.formdata;
    }
}

var ctrlAgentEventDetailsViewEvent = new function () {
    this.rowClicked = function (index, row) {
        if (row) {
            $("#ctrlagenteventdetleventname").val(row.agenteventdetleventname);
            getAgentEventEndPntFormData(row.agenteventdetleventname, $("#ctrlagenteventdetlneid").val(), $("#ctrlagenteventdetlagentid").val(), 'ctrl');
        } else {
            $("#ctrlagenteventdetleventname").val("");
        }
        loadAgentEventEmailDetls('ctrl');
        loadAgentEventSMSDetls('ctrl');
    };
};

var snmpAgentEventDetailsViewEvent = new function () {
    this.rowClicked = function (index, row) {
        if (row) {
            $("#snmpagenteventdetleventname").val(row.agenteventdetleventname);
            getAgentEventEndPntFormData(row.agenteventdetleventname, $("#snmpagenteventdetlneid").val(), $("#snmpagenteventdetlagentid").val(), 'snmp');
        } else {
            $("#snmpagenteventdetleventname").val("");
        }
        loadAgentEventEmailDetls('snmp');
        loadAgentEventSMSDetls('snmp');
    };
};

function loadAgentEventEmailDetls(type) {
    var parentTableActionLabel = "<fmt:message bundle='${clientrb}' key='AGENT_EVENT_DETAILS_ACTION_LABEL'/>";
    var row = $('#' + type + 'AgentEventList').datagrid('getSelected');
    if (!row) {
        var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
        $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
        return;
    }
    $('#' + type + 'AgentEventEmailForm').form('clear');
    if (type === "ctrl") {
        $('#' + type + 'AgentEventEmailForm').form('load', ctrlAgentEventEndPntFormData);
    } else if (type === "snmp") {
        $('#' + type + 'AgentEventEmailForm').form('load', snmpAgentEventEndPntFormData);
    }
}

function loadAgentEventSMSDetls(type) {
    var parentTableActionLabel = "<fmt:message bundle='${clientrb}' key='AGENT_EVENT_DETAILS_ACTION_LABEL'/>";
    var row = $('#' + type + 'AgentEventList').datagrid('getSelected');
    if (!row) {
        var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
        $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
        return;
    }
    $('#' + type + 'AgentEventSMSForm').form('clear');
    if (type === "ctrl") {
        $('#' + type + 'AgentEventSMSForm').form('load', ctrlAgentEventEndPntFormData);
    } else if (type === "snmp") {
        $('#' + type + 'AgentEventSMSForm').form('load', snmpAgentEventEndPntFormData);
    }
}

function updatAgentEventEmailConfig(type) {
    var parentTableActionLabel = "<fmt:message bundle='${clientrb}' key='AGENT_EVENT_DETAILS_ACTION_LABEL'/>";
    var row = $('#' + type + 'AgentEventList').datagrid('getSelected');
    if (!row) {
        var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
        $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
        return;
    }
    var URL = $.i18n.prop('SERVER_URL') + "/editAgentEventEmailDetails";
    $('#' + type + 'AgentEventEmailForm').form('submit', {
        url: URL,
        onSubmit: function (param) {
            var isValid = $(this).form('validate');
            if (isValid) {
                param.requestType = 'EventMgmt';
                param.subRequestType = 'editAgentEventEmailDetails';
                param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                param.operationId = "${param.id}";
                param.agenteventendpnteventname = row.agenteventdetleventname;
                param.agenteventendpntneid = $('#' + type + "agenteventdetlneid").val();
                param.agenteventendpntagentid = $('#' + type + "agenteventdetlagentid").val();
            }
            return isValid;
        },
        success: function (data) {
            var replyFormat = eval('(' + data + ')');
            updateStatusMessage(replyFormat, type + "AgentEventList");
        }
    });
}

function updatAgentEventSMSConfig(type) {
    var parentTableActionLabel = "<fmt:message bundle='${clientrb}' key='AGENT_EVENT_DETAILS_ACTION_LABEL'/>";
    var row = $('#' + type + 'AgentEventList').datagrid('getSelected');
    if (!row) {
        var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
        $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
        return;
    }
    var URL = $.i18n.prop('SERVER_URL') + "/editAgentEventSmsDetails";
    $('#' + type + 'AgentEventSMSForm').form('submit', {
        url: URL,
        onSubmit: function (param) {
            var isValid = $(this).form('validate');
            if (isValid) {
                param.requestType = 'EventMgmt';
                param.subRequestType = 'editAgentEventSmsDetails';
                param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
                param.operationId = "${param.id}";
                param.agenteventendpnteventname = row.agenteventdetleventname;
                param.agenteventendpntneid = $('#' + type + "agenteventdetlneid").val();
                param.agenteventendpntagentid = $('#' + type + "agenteventdetlagentid").val();
            }
            return isValid;
        },
        success: function (data) {
            var replyFormat = eval('(' + data + ')');
            updateStatusMessage(replyFormat, type + "AgentEventList");
        }
    });
}
