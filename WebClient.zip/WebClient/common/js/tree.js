var treeReloadFlag = false;
var ipCamTreeReloadFlag = false;
var neWorkSpace = [];

function collapse(id) {
    $('#' + id).tree('collapseAll');
}

function expand(id) {
    $('#' + id).tree('expandAll');
}

function getSelectedNodeData() {   //this function which is used in device.js
    var node = getSelectedNode();
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                var nodeType = node.attributes.type;
                if (nodeType === $.i18n.prop('SUB_SYSTEM_STR')) {
                    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
                        node = $('#networkTree').tree('getParent', node.target);
                    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
                        node = $('#logicalTree').tree('getParent', node.target);
                    }
                }
            }
        }
    }
    var selectedNodeData = null;
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        selectedNodeData = $('#networkTree').tree('getData', node.target);
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        selectedNodeData = $('#logicalTree').tree('getData', node.target);
    }
    return node;
}

function getSelectedParentNode() {  // this function is used in chart.js
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        var selectedTabName = $("#treeTab .tabs-selected").text();
        if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
            node = $('#networkTree').tree('getParent', node.target);
        } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
            node = $('#logicalTree').tree('getParent', node.target);
        }
    }
    return node;
}

function getSelectedNode() {
    var node = null;
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        node = $('#networkTree').tree('getSelected');
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        node = $('#logicalTree').tree('getSelected');
    }
    return node;
}

function getSelectedNeId() {
    var neId = 0;
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                if (node.attributes.type === $.i18n.prop('NE_STR')) {
                    neId = node.id.split($.i18n.prop('TREE_DELIMITER'))[1];
                } else if (node.attributes.type === $.i18n.prop('SUB_SYSTEM_STR')) {
                    neId = node.attributes.neId;
                }
            }
        }
    }
    return neId;
}

function getSelectedAgentId() {
    var agentId = 0;
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.agentId !== undefined && node.attributes.agentId !== null && node.attributes.agentId !== "") {
                agentId = node.attributes.agentId;
            }
        }
    }
    return agentId;
}

function getSelectedNeName() {
    var neName = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                var nodeType = node.attributes.type;
                if (nodeType !== $.i18n.prop('SUB_SYSTEM_STR') && nodeType === $.i18n.prop('NE_STR')) {
                    neName = node.text;
                } else {
                    if (node.attributes.neName !== undefined && node.attributes.neName !== null && node.attributes.neName !== "") {
                        neName = node.attributes.neName;
                    }
                }
            }
        }
    }
    return neName;
}

function getSelectedNodeNameForChart() {
    var node = getSelectedNode();
    var nodeName = "";
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type === $.i18n.prop('SUB_SYSTEM_STR')) {
                var selectedTabName = $("#treeTab .tabs-selected").text();
                if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
                    nodeName = node.text.replace(/\s+/g, "").toLowerCase();
                } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
                    var neName = node.attributes.neName;
                    var neNameWithH = neName + "-";
                    nodeName = node.text.replace(/\s+/g, "").replace(neNameWithH, "").toLowerCase();
                }
            } else {
                nodeName = node.text.replace(/\s+/g, "").toLowerCase();
            }
        }
    }
    return nodeName;
}

function getSelectedNodeName() {
    var node = getSelectedNode();
    var nodeName = null;
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type === $.i18n.prop('SUB_SYSTEM_STR')) {
                if (node.attributes.neName !== undefined && node.attributes.neName !== null && node.attributes.neName !== "") {
                    nodeName = node.attributes.neName.replace(/\s+/g, "");
                }
            } else {
                nodeName = node.text.replace(/\s+/g, "");
            }
        } else {
            nodeName = node.text.replace(/\s+/g, "");
        }
    }
    return nodeName;
}

function getSelectedNeVersionNumber() {
    var neVersionNumber = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.neVersionNumber !== undefined && node.attributes.neVersionNumber !== null && node.attributes.neVersionNumber !== "") {
                neVersionNumber = node.attributes.neVersionNumber;
            }
        }
    }
    return neVersionNumber;
}
function getSelectedSubSystemRecordId() {
    var subSystemRecordId = -1;
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemRecordId !== undefined && node.attributes.subSystemRecordId !== null && node.attributes.subSystemRecordId !== "") {
                subSystemRecordId = node.attributes.subSystemRecordId;
            }
        }
    }
    return subSystemRecordId;
}

function getSelectedSubSystemTypeId() {
    var subSystemTypeId = -1;
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemTypeId !== undefined && node.attributes.subSystemTypeId !== null && node.attributes.subSystemTypeId !== "") {
                subSystemTypeId = node.attributes.subSystemTypeId;
            }
        }
    }
    return subSystemTypeId;
}

function getSelectedSubSystemType() {
    var subSystemType = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemType !== undefined && node.attributes.subSystemType !== null && node.attributes.subSystemType !== "") {
                subSystemType = node.attributes.subSystemType.replace("EL Measure", "ELM").replace(" Inverter", "");
            }
        }
    }
    return subSystemType;
}

function getSelectedSubSystemName() {
    var subSystemName = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemName !== undefined && node.attributes.subSystemName !== null && node.attributes.subSystemName !== "") {
                subSystemName = node.attributes.subSystemName;
            }
        }
    }
    return subSystemName;
}

function getSelectedSubSystemId() {
    var subSystemId = 0;
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemId !== undefined && node.attributes.subSystemId !== null && node.attributes.subSystemId !== "") {
                subSystemId = node.attributes.subSystemId;
            }
        }
    }
    return subSystemId;
}

function getSelectedNeIpaddress() {
    var neIp = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.agentIp !== undefined && node.attributes.agentIp !== null && node.attributes.agentIp !== "") {
                neIp = node.attributes.agentIp;
            }
        }
    }
    return neIp;
}

function getSelectedNePort() {
    var nePort = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.agentPort !== undefined && node.attributes.agentPort !== null && node.attributes.agentPort !== "") {
                nePort = node.attributes.agentPort;
            }
        }
    }
    return nePort;
}

function getSelectedUniqueId() {
    var neUniqueId = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.children !== undefined && node.children !== null && node.children !== "") {
            for (var i = 0; i < node.children.length; i++) {
                var childNode = node.children[i];
                var childNodeAttributes = childNode.attributes;
                if (childNodeAttributes.agentUserId !== undefined && childNodeAttributes.agentUserId !== null && childNodeAttributes.agentUserId !== "") {
                    neUniqueId = childNodeAttributes.agentUserId;
                }
            }
        }
    }
    return neUniqueId;
}

function getSelectedSubSystemDisplayName() {
    var subSysDisplayName = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemDisplayName !== undefined && node.attributes.subSystemDisplayName !== null && node.attributes.subSystemDisplayName !== "") {
                subSysDisplayName = node.attributes.subSystemDisplayName;
            }
        }
    }
    return subSysDisplayName;
}

function getSelectedTenantDisplayName() {
    var tenantDisplayName = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.tenantDisplayName !== undefined && node.attributes.tenantDisplayName !== null && node.attributes.tenantDisplayName !== "") {
                tenantDisplayName = node.attributes.tenantDisplayName;
            }
        }
    }
    return tenantDisplayName;
}

function getSelectedSubSystemTypeRange() {
    var subSystemType = "";
    var subSystemTypeRange = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemType !== undefined && node.attributes.subSystemType !== null && node.attributes.subSystemType !== "") {
                subSystemType = node.attributes.subSystemType;
                if (subSystemType.indexOf("_") > -1) {
                    subSystemTypeRange = subSystemType.split("_")[1];
                }
            }
        }
    }
    return subSystemTypeRange;
}

function getSelectedSubSystemVersion() {
    var subSystemVersion = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.subSystemVersion !== undefined && node.attributes.subSystemVersion !== null && node.attributes.subSystemVersion !== "") {
                subSystemVersion = node.attributes.subSystemVersion;
            }
        }
    }
    return subSystemVersion;
}

function getSelectedNodeType() {
    var nodeType = "GROUP";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                var nodeTypeTemp = node.attributes.type;
                if (nodeTypeTemp !== $.i18n.prop('SUB_SYSTEM_STR')) {
                    nodeType = nodeTypeTemp.toUpperCase();
                } else {
                    //nodeType = node.attributes.subSystemName;
                    nodeType = node.attributes.subSystemTypeId;
                }
            }
        }
    }
    return nodeType;
}

function getSelectedNodeTypeStr() {
    var nodeType = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                nodeType = node.attributes.type;
            }
        }
    }
    return nodeType;
}

function getSelectedTabId() {
    var node = getSelectedNode();
    var nodeName = "";
    var subSystemType = "";
    var subSystemId = "";
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                if (node.attributes.type === $.i18n.prop('SUB_SYSTEM_STR')) {
                    subSystemType = getSelectedSubSystemType();
                    subSystemId = getSelectedSubSystemId();
                    nodeName = node.attributes.neName.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemType.replace(/\s+/g, "").toLowerCase() + $.i18n.prop('NE_DELIMITER') + subSystemId.replace(/\s+/g, "").toLowerCase();
                } else {
                    nodeName = node.text.replace(/\s+/g, "").toLowerCase();
                }
            }
        } else {
            nodeName = node.text.replace(/\s+/g, "").toLowerCase();
        }
    }
    var tabId = nodeName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "tab";
    return tabId.replace(/\s+/g, "").toLowerCase();
}

function defaultSelectRootNode(id) {
    var parentNode = $('#' + id).tree('getRoot');
    var nodeId = parentNode.id;
    var node = $('#' + id).tree('find', nodeId);
    $('#' + id).tree('select', node.target);
}

function selectNodeOnLoad(id) {
    var node = null;
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        node = $.jStorage.get("NetworkTreeNode");
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        node = $.jStorage.get("LogicalTreeNode");
    } else {
        node = $('#' + id).tree('getSelected');
    }
    if (node !== null && node !== "" && node !== undefined) {
        var nodeId = node.id;
        var selNode = $('#' + id).tree('find', nodeId);
        if (selNode !== null && selNode !== "" && selNode !== undefined) {
            $('#' + id).tree('select', selNode.target);
            $('#' + id).tree('expandTo', selNode.target);
            $('#' + id).tree('scrollTo', selNode.target);
        } else {
            defaultSelectRootNode(id);
        }
    } else {
        defaultSelectRootNode(id);
    }
}

function switchTreeView() {
    var node = null;
    var rootNode = null;
    var nodeText = "";
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        node = $('#networkTree').tree('getSelected');
        nodeText = node.text;
        rootNode = $('#networkTree').tree('getRoot');
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        node = $('#logicalTree').tree('getSelected');
        nodeText = node.text;
        rootNode = $('#logicalTree').tree('getRoot');
    }
    if (rootNode !== null && rootNode !== "" && rootNode !== undefined) {
        if (rootNode.text === nodeText) {
            switchWorkSpaceToGUI();
        } else {
            switchWorkSpace();
        }
    }
}

function getSelectedBuildingName() {
    var buildingName = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                var nodeType = node.attributes.type;
                if (nodeType === $.i18n.prop('BUILDING_STR')) {
                    buildingName = node.text;
                }
            }
        }
    }
    return buildingName;
}

function getSelectedFloorName() {
    var floorName = "";
    var node = getSelectedNode();
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                var nodeType = node.attributes.type;
                if (nodeType === $.i18n.prop('FLOOR_STR')) {
                    floorName = node.text;
                }
            }
        }
    }
    return floorName;
}

function getNodeBasedOnId(nodeId) {
    var node = null;
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        node = $('#networkTree').tree('find', nodeId);
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        node = $('#logicalTree').tree('find', nodeId);
    }
    return node;
}

function updateNodeStatus(nodeId, nodeStatus) {
    var node = null;
    var treeId = null;
    var selectedTabName = $("#treeTab .tabs-selected").text();
    if (selectedTabName === $.i18n.prop('NETWORK_TREE_TITLE')) {
        node = $('#networkTree').tree('find', nodeId);
        treeId = "networkTree";
    } else if (selectedTabName === $.i18n.prop('LOGICAL_TREE_TITLE')) {
        node = $('#logicalTree').tree('find', nodeId);
        treeId = "logicalTree";
    }
    var iconClass = "icon-indeterminate";
    var nodeStatusStr = "Indeterminate";
    var childStatus = 2;
    if (nodeStatus === "Connected" || nodeStatus === "connected" || nodeStatus === "CONNECTED" || nodeStatus === 0 || nodeStatus === "0") {
        iconClass = "icon-success";
        nodeStatusStr = "Success";
        childStatus = 0;
    } else if (nodeStatus === "Disconnected" || nodeStatus === "disconnected" || nodeStatus === "DISCONNECTED" || nodeStatus === 1 || nodeStatus === "1") {
        iconClass = "icon-failure";
        nodeStatusStr = "Failure";
        childStatus = 1;
    }
    if (node !== null && node !== "" && node !== undefined) {
        if (node.attributes !== undefined && node.attributes !== null && node.attributes !== "") {
            var nodeAttributes = node.attributes;
            nodeAttributes.status = nodeStatusStr;
            $('#' + treeId).tree('update', {
                target: node.target,
                iconCls: iconClass,
                attributes: nodeAttributes
            });
            /* var nodeChildren = $('#' + treeId).tree('getChildren', node.target);
             for (var i = 0; i < nodeChildren.length; i++) {
             var childNode = nodeChildren[i];
             var childNodeAttributes = childNode.attributes;
             childNodeAttributes.subSystemStatus = childStatus;
             childNodeAttributes.status = nodeStatus;
             $('#' + treeId).tree('update', {
             target: childNode.target,
             iconCls: iconClass,
             attributes: childNodeAttributes
             });
             } */
        }
    }
}

/********************************************** Network Tree *****************************************************/
function reloadTreeOnSelect(selectedTreeNode) {
    treeReloadFlag = false;
    var URL = $.i18n.prop('SERVER_URL') + "/getNetworkTreeData";
    var parameters = "requestType=NetworkTree&subRequestType=refreshNetworkTree&key=NETWORK_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    $('#networkTree').block();
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#networkTree').tree('loadData', treeJsonData.nodes);
    try {
        var nodeId = selectedTreeNode.id;
        var node = $('#networkTree').tree('find', nodeId);
        if (node !== null && node !== "" && node !== undefined) {
            $('#networkTree').tree('select', node.target);
            $('#networkTree').tree('expandTo', node.target);
            $('#networkTree').tree('scrollTo', node.target);
        } else {
            selectNodeOnLoad("networkTree");
        }
    } catch (e) {
        selectNodeOnLoad("networkTree");
    }
    $('#networkTree').unblock();
}

function reloadTree() {
    if ($('#networkTree').length) {
        var selectedTreeNode = $('#networkTree').tree('getSelected');
        reloadTreeOnSelect(selectedTreeNode);
    }
}

function getTree() {
    var URL = $.i18n.prop('SERVER_URL') + "/getNetworkTreeData";
    var parameters = "requestType=NetworkTree&subRequestType=refreshNetworkTree&key=NETWORK_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#networkTree').tree({
        data: treeJsonData.nodes,
        animate: true,
        onBeforeSelect: function (node) {
            $(this).find('.tooltip-f').tooltip('destroy');
        },
        onSelect: function (node) {
            $.jStorage.set("NetworkTreeNode", node);
            if (treeReloadFlag) {
                reloadTreeOnSelect(node);
            } else {
                treeClick(node);
            }
            $.parser.parse($(this));
        },
        formatter: function (node) {
            return '<span title=\'' + node.text + '\' class=\'easyui-tooltip\'>' + node.text + '</span>';
        },
        onLoadSuccess: function (node, data) {
            $.parser.parse($(this));
        }
    });
    setTimeout(function () {
        selectNodeOnLoad("networkTree");
    }, 100);
}

function treeFormat(node) {
    var nodeChildren = '';
    if (node.children) {
        nodeChildren = node.children;
        for (var i = 0; i < nodeChildren.length; i++) {
            var selNode = nodeChildren[i];
            if (selNode.attributes !== undefined && selNode.attributes !== null && selNode.attributes !== "") {
                if (selNode.attributes.status !== undefined && selNode.attributes.status !== null && selNode.attributes.status !== "") {
                    var nodeStatus = selNode.attributes.status;
                    if (nodeStatus === "Success" || nodeStatus === "success" || nodeStatus === 0) {
                        selNode.iconCls = "successIcon";
                    } else if (nodeStatus === "Failure" || nodeStatus === "failure" || nodeStatus === 1) {
                        selNode.iconCls = "failureIcon";
                    } else {
                        selNode.iconCls = "defaultIcon";
                    }
                }
            }
        }
    }
}

function treeClick(node) {
    var mapLocAttr = [];
    var nodeLat, nodeLong;
    var nodeText = node.text;
    var rootNode = $('#networkTree').tree('getRoot');
    if (rootNode.text === nodeText) {
        switchWorkSpaceToGUI();
    } else {
        switchWorkSpace();
    }
    var nodeIsLeaf = $('#networkTree').tree('isLeaf', node.target);
    if (!nodeIsLeaf) {
        var nodeChildren = $('#networkTree').tree('getChildren', node.target);
        for (var i = 0; i < nodeChildren.length; i++) {
            selNode = nodeChildren[i];
            if (selNode.attributes) {
                if (selNode.attributes.lat && selNode.attributes.lng) {
                    nodeLat = selNode.attributes.lat;
                    nodeLong = selNode.attributes.lng;
                    if (nodeLat !== undefined || nodeLong !== undefined || nodeLat !== null || nodeLong !== null || nodeLat !== "" || nodeLong !== "") {
                        mapLocAttr.push({
                            lat: nodeLat,
                            lng: nodeLong,
                            text: selNode.text,
                            personName: selNode.attributes.personName,
                            mobileNumber: selNode.attributes.mobileNumber,
                            phoneNumber: selNode.attributes.phoneNumber,
                            emailAddress: selNode.attributes.emailAddress,
                            ip: selNode.attributes.ip,
                            id: selNode.id,
                            status: selNode.attributes.status
                        });
                    }
                }
            }
        }
        Maplocation(mapLocAttr);
    } else {
        var selNode = $('#networkTree').tree('getNode', node.target);
        if (selNode.text === nodeText) {
            if (selNode.attributes) {
                if (selNode.attributes.lat && selNode.attributes.lng) {
                    nodeLat = selNode.attributes.lat;
                    nodeLong = selNode.attributes.lng;
                    if (nodeLat !== undefined || nodeLong !== undefined || nodeLat !== null || nodeLong !== null || nodeLat !== "" || nodeLong !== "") {
                        mapLocAttr.push({
                            lat: nodeLat,
                            lng: nodeLong,
                            text: selNode.text,
                            personName: selNode.attributes.personName,
                            mobileNumber: selNode.attributes.mobileNumber,
                            phoneNumber: selNode.attributes.phoneNumber,
                            emailAddress: selNode.attributes.emailAddress,
                            ip: selNode.attributes.ip,
                            id: selNode.id,
                            status: selNode.attributes.status
                        });
                    }
                }
            }
            Maplocation(mapLocAttr);
        }
    }
}

function treeMapOnload(node, data) {
    var mapLocAttr = [];
    if (data) {
        var nodeChildren = $('#networkTree').tree('getChildren', data);
        for (var i = 0; i < nodeChildren.length; i++) {
            var selNode = nodeChildren[i];
            if (selNode.attributes) {
                var nodeLat = selNode.attributes.lat;
                var nodeLong = selNode.attributes.lng;
                if (nodeLat !== undefined || nodeLong !== undefined || nodeLat !== null || nodeLong !== null || nodeLat !== "" || nodeLong !== "") {
                    mapLocAttr.push({
                        lat: nodeLat,
                        lng: nodeLong,
                        text: selNode.text,
                        personName: selNode.attributes.personName,
                        mobileNumber: selNode.attributes.mobileNumber,
                        phoneNumber: selNode.attributes.phoneNumber,
                        emailAddress: selNode.attributes.emailAddress,
                        ip: selNode.attributes.ip,
                        id: selNode.id,
                        status: selNode.attributes.status
                    });
                }
            }
        }
        if (mapLocAttr.length > 0) {
            Maplocation(mapLocAttr);
        }
    }
}

function getDataAndLoadMap() {
    var mapLocAttr = [];
    var parentNode = $('#networkTree').tree('getRoot');
    var nodeChildren = $('#networkTree').tree('getChildren', parentNode.target);
    for (var i = 0; i < nodeChildren.length; i++) {
        var selNode = nodeChildren[i];
        if (selNode.attributes) {
            var nodeLat = selNode.attributes.lat;
            var nodeLong = selNode.attributes.lng;
            if (nodeLat !== undefined || nodeLong !== undefined || nodeLat !== null || nodeLong !== null || nodeLat !== "" || nodeLong !== "") {
                mapLocAttr.push({
                    lat: nodeLat,
                    lng: nodeLong,
                    text: selNode.text,
                    personName: selNode.attributes.personName,
                    mobileNumber: selNode.attributes.mobileNumber,
                    phoneNumber: selNode.attributes.phoneNumber,
                    emailAddress: selNode.attributes.emailAddress,
                    ip: selNode.attributes.ip,
                    id: selNode.id,
                    status: selNode.attributes.status
                });
            }
        }
    }
    if (mapLocAttr.length > 0) {
        Maplocation(mapLocAttr);
    }
}

function networkTreeSearch(value, name) {
    var searchText = value;
    if (searchText === "Do Filter" || searchText === "Search Text") {
        searchText = "";
    }
    if (searchText.length > 0) {
        $('#networkTree').tree('doFilter', searchText);
    } else {
        $('#networkTree').tree('doFilter', '');
    }
}

function switchWorkSpaceToGUI() {
    $("#applicationView").children('div').each(function () {
        $(this).hide();
    });
    if ($("#application").tabs('tabs').length > 1) {
        $("#application").show();
        $("#application").tabs('resize', {});
    } else {
        //var loggedInDetails = $.jStorage.get("model");
        var loggedInDetails = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_XML_KEY'));
        addGuiAppBasedOnAccess(loggedInDetails, 'application');
        $("#application").show();
    }
}

function switchWorkSpace() {
    if ($("#application").tabs('exists', 0)) {
        $("#application").hide();
    }
    $("#applicationView").children('div').each(function () {
        $(this).hide();
    });
    var nodeName = getSelectedNodeName();
    var tabId = getSelectedTabId();
    var nodeType = getSelectedNodeType();
    var found = $.inArray(tabId, neWorkSpace) > -1;
    var workSpaceLimit = parseInt($.i18n.prop('WORKSPACE_MAX_LIMIT'));
    if (!found) {
        if (neWorkSpace.length >= workSpaceLimit) {
            var tabIdToRemove = neWorkSpace[0];
            $("#" + tabIdToRemove).remove();
            neWorkSpace.shift();
            neWorkSpace.push(tabId);
        } else {
            neWorkSpace.push(tabId);
        }
    }
    if ($("#" + tabId).length > 0) {
        $("#" + tabId).show();
        $("#" + tabId).tabs('resize', {});
    } else {
        if (nodeType.toUpperCase() === $.i18n.prop('BUILDING_STR').toUpperCase()) {
            var getGuiAppURL = $.i18n.prop('SERVER_URL') + "/getGUIAppList";
            var guiParameters = "requestType=GUIManager&subRequestType=getGUIAppList&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&nodeName=" + nodeName + "&nodeType=" + nodeType;
            var guiReplyFormat = getDataFromServer("POST", getGuiAppURL, $.deserialize(guiParameters), "text");
            var guiAppData = $.parseJSON(unescape(guiReplyFormat));
            updateStatusMessage(guiAppData, "");
            addGuiAppBasedOnAccess(guiAppData, tabId);
        } else {
            var getNeAppURL = $.i18n.prop('SERVER_URL') + "/getNodeAppList";
            var parameters = "requestType=NEManager&subRequestType=getNeApplicationList&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&nodeName=" + nodeName + "&nodeType=" + nodeType;
            var replyFormat = getDataFromServer("POST", getNeAppURL, $.deserialize(parameters), "text");
            var neAppData = $.parseJSON(unescape(replyFormat));
            updateStatusMessage(neAppData, "");
            addNEAppBasedOnAccess(neAppData, tabId);
        }
    }
}
/********************************************** Network Tree *****************************************************/

/********************************************** Logical Tree *****************************************************/
function reloadLogicalTreeOnSelect(selectedTreeNode) {
    treeReloadFlag = false;
    var URL = $.i18n.prop('SERVER_URL') + "/getLogicalTreeData";
    var parameters = "requestType=LogicalTree&subRequestType=refreshLogicalTree&key=LOGICAL_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    $('#logicalTree').block();
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#logicalTree').tree('loadData', treeJsonData.nodes);
    try {
        var nodeId = selectedTreeNode.id;
        var node = $('#logicalTree').tree('find', nodeId);
        if (node !== null && node !== "" && node !== undefined) {
            $('#logicalTree').tree('select', node.target);
            $('#logicalTree').tree('expandTo', node.target);
            $('#logicalTree').tree('scrollTo', node.target);
        } else {
            selectNodeOnLoad("logicalTree");
        }
    } catch (e) {
        selectNodeOnLoad("logicalTree");
    }
    $('#logicalTree').unblock();
}

function reloadLogicalTree() {
    if ($('#logicalTree').length) {
        var selectedTreeNode = $('#logicalTree').tree('getSelected');
        reloadLogicalTreeOnSelect(selectedTreeNode);
    }
}

function getLogicalTree() {
    var URL = $.i18n.prop('SERVER_URL') + "/getLogicalTreeData";
    var parameters = "requestType=LogicalTree&subRequestType=refreshLogicalTree&key=LOGICAL_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#logicalTree').tree({
        data: treeJsonData.nodes,
        animate: true,
        onBeforeSelect: function (node) {
            $(this).find('.tooltip-f').tooltip('destroy');
        },
        onSelect: function (node) {
            $.jStorage.set("LogicalTreeNode", node);
            if (treeReloadFlag) {
                reloadLogicalTreeOnSelect(node);
            } else {
                logicalTreeClick(node);
            }
            $.parser.parse($(this));
        },
        formatter: function (node) {
            return '<span title=\'' + node.text + '\' class=\'easyui-tooltip\'>' + node.text + '</span>';
        },
        onLoadSuccess: function (node, data) {
            $.parser.parse($(this));
        }
    });
    setTimeout(function () {
        selectNodeOnLoad("logicalTree");
    }, 100);
}

function logicalTreeSearch(value, name) {
    var searchText = value;
    if (searchText === "Do Filter" || searchText === "Search Text") {
        searchText = "";
    }
    if (searchText.length > 0) {
        $('#logicalTree').tree('doFilter', searchText);
    } else {
        $('#logicalTree').tree('doFilter', '');
    }
}

function logicalTreeClick(node) {
    var nodeText = node.text;
    var rootNode = $('#logicalTree').tree('getRoot');
    if (rootNode.text === nodeText) {
        switchWorkSpaceToGUI();
    } else {
        switchWorkSpace();
    }
}
/********************************************** Logical Tree *****************************************************/

/********************************************** IPCam Tree *****************************************************/
function collapseIpCam() {
    $('#IpCamTree').tree('collapseAll');
}

function expandIpCam() {
    $('#IpCamTree').tree('expandAll');
}

function getIPCamTree() {
    var URL = $.i18n.prop('SERVER_URL') + "/getIPCamTreeData";
    var parameters = "requestType=IPCamTree&subRequestType=refreshIPCamTree&key=IPCAM_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#IpCamTree').tree({
        data: treeJsonData.nodes,
        animate: true,
        onBeforeSelect: function (node) {
            $(this).find('.tooltip-f').tooltip('destroy');
        },
        onSelect: function (node) {
            if (ipCamTreeReloadFlag) {
                reloadIPCamTreeOnSelect(node);
            }
            $.parser.parse($(this));
        },
        formatter: function (node) {
            return '<span title=\'' + node.text + '\' class=\'easyui-tooltip\'>' + node.text + '</span>';
        },
        onLoadSuccess: function (node, data) {
            $.parser.parse($(this));
        }
    });
    setTimeout(selectRootNodeOnLoadForIpCam, 100);
}


function reloadIPCamTreeOnSelect(selectedTreeNode) {
    ipCamTreeReloadFlag = false;
    var URL = $.i18n.prop('SERVER_URL') + "/getIPCamTreeData";
    var parameters = "requestType=IPCamTree&subRequestType=refreshIPCamTree&key=IPCAM_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    $('#IpCamTree').block();
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#IpCamTree').tree('loadData', treeJsonData.nodes);
    try {
        var nodeId = selectedTreeNode.id;
        var node = $('#IpCamTree').tree('find', nodeId);
        $('#IpCamTree').tree('select', node.target);
        $('#IpCamTree').tree('expandTo', node.target);
        $('#IpCamTree').tree('scrollTo', node.target);
    } catch (e) {
        selectRootNodeOnLoadForIpCam();
    }
    $('#IpCamTree').unblock();
}


function selectRootNodeOnLoadForIpCam() {
    var parentNode = $('#IpCamTree').tree('getRoot');
    var nodeId = parentNode.id;
    var node = $('#IpCamTree').tree('find', nodeId);
    $('#IpCamTree').tree('select', node.target);
}

function reloadIPCamTree() {
    if ($('#IpCamTree').length) {
        var selectedTreeNode = $('#IpCamTree').tree('getSelected');
        reloadIPCamTreeOnSelect(selectedTreeNode);
    }
}


function IPCamTreeSearch(value, name) {
    var searchText = value;
    if (searchText === "Do Filter" || searchText === "Search Text") {
        searchText = "";
    }
    if (searchText.length > 0) {
        $('#IpCamTree').tree('doFilter', searchText);
    } else {
        $('#IpCamTree').tree('doFilter', '');
    }
}
/********************************************** IPCam Tree *****************************************************/

