var autoRefreshArray = [];
var systemStatusTimer = null;
var neStatusTimer = null;
var workLoadStatusTimer = null;

function reloadTimer(moduleId, method, moduleTimerKey) {
    clearTimer(moduleTimerKey);
    var minutes = $('#' + moduleId).combobox('getValue');
    var milliseconds = Number(minutes) * 60 * 1000;
    var timerKey = setInterval(function () {
        window[method]();
    }, Number(milliseconds));
    autoRefreshArray[moduleTimerKey] = timerKey;
}

function startTimer(moduleId, method, moduleTimerKey) {
    var minutes = $('#' + moduleId).combobox('getValue');
    var milliseconds = Number(minutes) * 60 * 1000;
    var timerKey = setInterval(function () {
        window[method]();
    }, Number(milliseconds));
    autoRefreshArray[moduleTimerKey] = timerKey;
}

function clearTimer(moduleTimerKey) {
    clearInterval(autoRefreshArray[moduleTimerKey]);
}

function loadSystemStatus() {
    var existChart = chartArray.systemStatus;
    if (existChart !== null && existChart !== " ") {
        existChart.destroy();
    }
    $('#systemStatus').highcharts({
        chart: {
            type: 'spline',
            borderWidth: 0
        },
        title: {
            text: ''
        },
        credits: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        exporting: {
            enabled: false
        },
        xAxis: {
            categories: ['9:00', '9:30', '10:00', '10:30', '11:00', '11:30',
                '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
                '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00'
            ],
            title: {
                text: 'Last 24 Hours'
            }
        },
        yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: 'Order Counts'
            }
        },
        tooltip: {
            useHTML: true,
            pointFormat: '<span>{series.name}</span>: <b>{point.y}</b><br/>'
        },
        series: [{
                name: 'Total Orders',
                data: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190],
                color: '#49B6F1'
            }, {
                name: 'Success Orders',
                data: [8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 136, 144, 152],
                color: '#00A000'
            }, {
                name: 'Failure Orders',
                data: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38],
                color: '#CC0033'
            }]
    });
    var chart = $('#systemStatus').highcharts();
    chartArray.systemStatus = chart;
    resizeChart('systemStatus', 0, 0);
}

function loadNEStatus() {
    var existChart = chartArray.neStatus;
    if (existChart !== null && existChart !== " ") {
        existChart.destroy();
    }
    $('#neStatus').highcharts({
        chart: {
            type: 'column',
            borderWidth: 0
        },
        title: {
            text: ''
        },
        credits: {
            enabled: false
        },
        legend: {
            enabled: false
        },
        exporting: {
            enabled: false
        },
        xAxis: {
            categories: ['HLR', 'PGW', 'HSS', 'HSI', 'CITIC', 'MMSC', 'DMM'],
            title: {
                text: 'NEs'
            }
        },
        yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: 'Order Counts'
            }
        },
        tooltip: {
            useHTML: true,
            pointFormat: '<span>{series.name}</span>: <b>{point.y}</b><br/>'
        },
        series: [{
                name: 'Total Orders',
                data: [10, 20, 30, 40, 50, 60, 70],
                color: '#49B6F1',
                dataLabels: {
                    enabled: true,
                    inside: false
                }
            }, {
                name: 'Success Orders',
                data: [8, 16, 24, 32, 40, 48, 56],
                color: '#00A000',
                dataLabels: {
                    enabled: true,
                    inside: false
                }
            }, {
                name: 'Failure Orders',
                data: [2, 4, 6, 8, 10, 12, 14],
                color: '#CC0033',
                dataLabels: {
                    enabled: true,
                    inside: false
                }
            }]
    });
    var chart = $('#neStatus').highcharts();
    chartArray.neStatus = chart;
    resizeChart('neStatus', 0, 0);
}

function reloadWorkLoadStatus() {
    var jsonData = getDataFromServer("POST", workLoadStatusURL, "", "text");
    var data = eval('(' + jsonData + ')');
    $('#workLoadStatus').datagrid('loadData', data.rows);
}

function pollDataFromServer(dataType) {
    switch (dataType) {
        case "SystemStatus":
            loadSystemStatus();
            break;
        case "NEStatus":
            loadNEStatus();
            break;
        case "WorkLoadStatus":
            reloadWorkLoadStatus();
            break;
        default:
    }
}

function enableAndDisableAutoRefresh(e, dataType) {
    switch (dataType) {
        case "SystemStatus":
            if ($(e).is(':checked')) {
                reloadTimer("systemStatusRefreshDuration", "loadSystemStatus", "systemStatusTimer");
            } else {
                clearTimer("systemStatusTimer");
            }
            break;
        case "NEStatus":
            if ($(e).is(':checked')) {
                reloadTimer("neStatusRefreshDuration", "loadNEStatus", "neStatusTimer");
            } else {
                clearTimer("neStatusTimer");
            }
            break;
        case "WorkLoadStatus":
            if ($(e).is(':checked')) {
                reloadTimer("workLoadStatusRefreshDuration", "loadWorkLoadStatus", "workLoadStatusTimer");
            } else {
                clearTimer("workLoadStatusTimer");
            }
            break;
        default:
    }
}

function reloadPeriodicRefresh(comboBoxId, referenceKey, method, parameters) {
    stopPeriodicRefresh(referenceKey);
    startPeriodicRefresh(comboBoxId, referenceKey, method, parameters);
}

function startPeriodicRefresh(comboBoxId, referenceKey, method, parameters) {
    var minutes = $('#' + comboBoxId).combobox('getValue');
    var milliseconds = Number(minutes) * 60 * 1000;
    var timerKey = setInterval(function () {
        window[method].apply(this, parameters.split(","));
    }, Number(milliseconds));
    autoRefreshArray[referenceKey] = timerKey;
}

function stopPeriodicRefresh(referenceKey) {
    if (autoRefreshArray.length > 0) {
        var keyIsExists = autoRefreshArray[referenceKey];
        if (keyIsExists !== null && keyIsExists !== "" && keyIsExists !== undefined) {
            clearInterval(autoRefreshArray[referenceKey]);
        }
    }
}

function enableAndDisableAutoRefresh(e, type, neRefId, method, parameters) {
    switch (type) {
        case "NEStatus":
            if ($(e).is(':checked')) {
                reloadPeriodicRefresh(neRefId + "AutoRefreshInterval", neRefId + "AutoRefreshKey", method, parameters);
            } else {
                stopPeriodicRefresh(neRefId + "AutoRefreshKey");
            }
            break;
        default:
    }
}
