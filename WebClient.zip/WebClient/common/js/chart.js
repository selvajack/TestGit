var chartArray = [];
var rangeSelectorButtonText = "";
var rangeSelectorButtonIndex = 0;

Highcharts.setOptions({
    global: {
        useUTC: false
    }
});

Highcharts.dateFormats = {
    W: function (timestamp) {
        var date = new Date(timestamp), day = date.getDay() === 0 ? 7 : date.getDay(), dayNumber;
        date.setDate(date.getDate() + 4 - day);
        dayNumber = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 1, -6)) / 86400000);
        return 1 + Math.floor(dayNumber / 7);
    },
    V: function (timestamp) {
        var target = new Date(timestamp);
        var dayNr = (target.getDay() + 6) % 7;
        target.setDate(target.getDate() - dayNr + 3);
        var firstThursday = target.valueOf();
        target.setMonth(0, 1);
        if (target.getDay() !== 4) {
            target.setMonth(0, 1 + ((4 - target.getDay()) + 7) % 7);
        }
        return 1 + Math.ceil((firstThursday - target) / 604800000); // 604800000 = 7 * 24 * 3600 * 1000  
    },
    G: function (timestamp) {
        var target = new Date(timestamp);
        target.setDate(target.getDate() - ((target.getDay() + 6) % 7) + 3);
        return target.getFullYear();
    }
};

function highlightMinAndMax(chartId) {
    var minMaxFound = false;
    var chart = chartArray[chartId];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        if (chart.series !== null && chart.series !== "null" && chart.series !== " " && chart.series !== "" && chart.series !== undefined) {
            for (var i = 0; i < chart.series.length; i++) {
                var seriesName = chart.series[i].name;
                if (seriesName === "Power" || seriesName === "Power Load1" || seriesName === "Power Load2" || seriesName === "Input Power" || seriesName === "Voltage" || seriesName === "Input Voltage") {
                    minMaxFound = true;
                    var min = chart.series[i].dataMin;
                    var max = chart.series[i].dataMax;
                    for (var j = 0; j < chart.series[i].points.length; j++) {
                        if (chart.series[i].points[j].y === min) {
                            chart.series[i].points[j].update({
                                marker: {
                                    radius: 5,
                                    fillColor: '#FFFF00',
                                    lineWidth: 3,
                                    lineColor: "#FFFF00"
                                }
                            });
                            break;
                        }
                    }
                    for (var k = chart.series[i].points.length - 1; k >= 0; k--) {
                        if (chart.series[i].points[k].y === max) {
                            chart.series[i].points[k].update({
                                marker: {
                                    radius: 5,
                                    fillColor: '#FF0000',
                                    lineWidth: 3,
                                    lineColor: "#FF0000"
                                }
                            });
                            break;
                        }
                    }
                }
            }
        }
    }
    if (minMaxFound) {
        chart.redraw();
    }
}

function resizeChartBasedOnParent(chartId) {
    var chart = chartArray[chartId];
    if (chart !== null && chart !== " " && chart !== undefined) {
        try {
            $("#" + chartId).width($("#" + chartId).parent().width() - 2);
            $("#" + chartId).height($("#" + chartId).parent().height() - 2);
            chart.setSize($("#" + chartId).parent().width() - 2, $("#" + chartId).parent().height() - 2, false);
        } catch (e) {
            //Do Nothing
        }
    }
}

function resizeChart(chartId, width, height) {
    var chart = chartArray[chartId];
    if (chart !== null && chart !== " " && chart !== undefined) {
        try {
            $("#" + chartId).width(width - 2);
            $("#" + chartId).height(height - 30);
            chart.setSize(width - 2, height - 30, false);
        } catch (e) {
            //Do Nothing
        }
    }
}

function setDataNotFound(divId) {
    $("#" + divId).empty();
    $("#" + divId).addClass("vertHorzCenterDiv");
    $("#" + divId).html($.i18n.prop('DATA_NOT_AVAILABLE_STR'));
}

function getDateFromServerAndPlotChart(event, chartRenderTo, graphName, key, QueryNum, additionalReqParams) {
    $("#" + chartRenderTo).block();
    var dateTimeFormat = $.i18n.prop('DATETIME_FORMAT');
    var startDateTime = Highcharts.dateFormat(dateTimeFormat, event.min);
    var endDateTime = Highcharts.dateFormat(dateTimeFormat, event.max);
    rangeSelectorButtonText = event.rangeSelectorButton.text;
    var URL = $.i18n.prop('SERVER_URL') + "/GraphMgrForHS";
    var parameters = "requestType=GraphMgr&subRequestType=getChartDataForHS&graphName=" + graphName + "&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&key=" + key + "&QueryNum=" + QueryNum;
    var params = $.deserialize(parameters);
    if ($.trim(additionalReqParams) !== null && $.trim(additionalReqParams) !== "null" && $.trim(additionalReqParams) !== undefined && $.trim(additionalReqParams) !== '') {
        var addReqParameters = $.deserialize(additionalReqParams);
        for (var reqParamKey in addReqParameters) {
            if (addReqParameters.hasOwnProperty(reqParamKey)) {
                var paramStr = addReqParameters[reqParamKey];
                if (paramStr.indexOf(",") > -1) {
                    var conditionStr = "";
                    $.each(paramStr.split(","), function (index, item) {
                        if (item !== "" && item !== '' && item !== null && item !== undefined && item !== "null") {
                            var itemValue = $("#" + item).val() || $("[name='" + item + "']").val();
                            if (itemValue !== "" && itemValue !== '' && itemValue !== null && itemValue !== undefined && itemValue !== "null" && itemValue !== "All") {
                                if (itemValue.indexOf(",") > -1) {
                                    var itemValues = "";
                                    $.each(paramStr.split(","), function (index1, item1) {
                                        if (index1 === 0) {
                                            itemValues = "'" + item1 + "'";
                                        } else {
                                            itemValues = ", '" + item1 + "'";
                                        }
                                    });
                                    conditionStr += " AND " + item + " IN (" + itemValues + ")";
                                } else {
                                    conditionStr += " AND " + item + " = '" + itemValue + "'";
                                }
                            }
                        }
                    });
                    params[reqParamKey] = conditionStr;
                } else {
                    params[reqParamKey] = $("#" + paramStr).val() || $("[name='" + paramStr + "']").val() || Number(-1);
                }
            }
        }
    }
    if (startDateTime !== null && startDateTime !== undefined && startDateTime !== "" && startDateTime !== '' && startDateTime !== "null") {
        params.Parm21 = startDateTime;
    }
    if (endDateTime !== null && endDateTime !== undefined && endDateTime !== "" && endDateTime !== '' && endDateTime !== "null") {
        params.Parm22 = endDateTime;
    }
    parameters = params;
    //var parameters = "requestType=Report&subRequestType=ChartData&graphName=" + chartName + "&nodeType=" + selectedNodeType + "&nodeName=" + selectedNodeName + "&nodeId=" + selectedNodeID + "&dateRange=" + rangeSelectorButtonText + "&graphSelectedRange=" + rangeSelectorButtonIndex;
    var data = getDataFromServer("POST", URL, parameters, "text");
    plotChartFromJSONDataForHS(data, chartRenderTo, graphName);
    $("#" + chartRenderTo).unblock();
}

function plotChartFromJSONDataForHS(data, chartRenderTo, graphName) {
    var exportFileName = graphName.toString().toLowerCase();
    var selNodeName = getSelectedNodeNameForChart();
    if (selNodeName !== null && selNodeName !== "" && selNodeName !== undefined) {
        exportFileName = selNodeName + $.i18n.prop('NE_DELIMITER') + graphName.toString().toLowerCase();
    }
    var existChart = chartArray[chartRenderTo];
    if (existChart !== null && existChart !== " " && existChart !== undefined && existChart !== '') {
        try {
            existChart.destroy();
        } catch (e) {
            //Do Nothing
        }
    }
    Highcharts.setOptions({
        global: {
            useUTC: false
        },
        lang: {
            numericSymbols: null //otherwise by default ['k', 'M', 'G', 'T', 'P', 'E']
        },
        chart: {
            renderTo: chartRenderTo
        },
        xAxis: {
            events: {
                setExtremes: function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    if (e.trigger === "rangeSelectorButton") {
                        var existChart = chartArray[chartRenderTo];
                        rangeSelectorButtonText = e.rangeSelectorButton.text;
                        $.each(existChart.rangeSelector.buttons, function (index, value) {
                            if (value.element.textContent === rangeSelectorButtonText) {
                                rangeSelectorButtonIndex = index;
                            }
                        });
                        getDateFromServerAndPlotChart(e, chartRenderTo, graphName);
                    }
                }
            },
            minRange: 3600 * 1000
        },
        exporting: {
            enabled: true,
            buttons: {
                contextButton: {
                    menuItems: [{
                            text: 'Print',
                            onclick: function () {
                                this.print();
                            }
                        }, {
                            text: 'Export As SVG',
                            onclick: function () {
                                if (Highcharts.exporting.supports("image/svg+xml")) {
                                    this.exportChartLocal({
                                        type: "image/svg+xml",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As PNG',
                            onclick: function () {
                                if (Highcharts.exporting.supports("image/png")) {
                                    this.exportChartLocal({
                                        type: "image/png",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As JPEG',
                            onclick: function () {
                                if (Highcharts.exporting.supports("image/jpeg")) {
                                    this.exportChartLocal({
                                        type: "image/jpeg",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As PDF',
                            onclick: function () {
                                if (Highcharts.exporting.supports("application/pdf")) {
                                    this.exportChartLocal({
                                        type: "application/pdf",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As CSV',
                            onclick: function () {
                                if (Highcharts.exporting.supports("text/csv")) {
                                    this.exportChartLocal({
                                        type: "text/csv",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As Excel',
                            onclick: function () {
                                if (Highcharts.exporting.supports("application/vnd.ms-excel")) {
                                    this.exportChartLocal({
                                        type: "application/vnd.ms-excel",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }]
                }
            }
        },
        plotOptions: {
            series: {
                point: {
                    events: {
                        dblclick: function (event) {
                            //event.point.remove();
                            event.point.update({y: null});
                        },
                        remove: function () {
                            if (!confirm('Do you really want to remove the selected point?')) {
                                return false;
                            }
                        }
                    }
                }
            }
        }
    });
    var chart = null;
    $("#" + chartRenderTo).removeClass("vertHorzCenterDiv");
    try {
        var chartJSONData = eval('(' + data.replace(/NAN/g, "null") + ')');
        chart = new Highcharts.StockChart(JSON.parse(chartJSONData.graphdata));
        chartArray[chartRenderTo] = chart;
        resizeChartBasedOnParent(chartRenderTo);
        highlightMinAndMax(chartRenderTo);
        loadChartSeriesAndTypeData(chartRenderTo);
    } catch (e) {
        setDataNotFound(chartRenderTo);
    }
}

function getChartDataFromServerUsingURL(URL, graphName, chartId, key, QueryNum, additionalReqParams) {
    $("#" + chartId).parent().closest('div').block();
    var parameters = "requestType=GraphMgr&subRequestType=getChartDataForHC&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&key=" + key + "&QueryNum=" + QueryNum;
    var params = $.deserialize(parameters);
    if ($.trim(additionalReqParams) !== null && $.trim(additionalReqParams) !== "null" && $.trim(additionalReqParams) !== undefined && $.trim(additionalReqParams) !== '') {
        var addReqParameters = $.deserialize(additionalReqParams);
        for (var paramKey in addReqParameters) {
            if (addReqParameters.hasOwnProperty(paramKey)) {
                var paramStr = addReqParameters[paramKey];
                if (paramStr.indexOf(",") > -1) {
                    var conditionStr = "";
                    $.each(paramStr.split(","), function (index, item) {
                        if (item !== "" && item !== '' && item !== null && item !== undefined && item !== "null") {
                            var itemValue = $("#" + item).val() || $("[name='" + item + "']").val();
                            if (itemValue !== "" && itemValue !== '' && itemValue !== null && itemValue !== undefined && itemValue !== "null" && itemValue !== "All") {
                                if (itemValue.indexOf(",") > -1) {
                                    var itemValues = "";
                                    $.each(paramStr.split(","), function (index1, item1) {
                                        if (index1 === 0) {
                                            itemValues = "'" + item1 + "'";
                                        } else {
                                            itemValues = ", '" + item1 + "'";
                                        }
                                    });
                                    conditionStr += " AND " + item + " IN (" + itemValues + ")";
                                } else {
                                    conditionStr += " AND " + item + " = '" + itemValue + "'";
                                }
                            }
                        }
                    });
                    params[paramKey] = conditionStr;
                } else {
                    //params[paramKey] = $("#" + paramStr).val() || $("[name='" + paramStr + "']").val() || Number(-1);
                    params[paramKey] = $("#" + paramStr).val() || $("[name='" + paramStr + "[]']").map(function () {
                        return $(this).val();
                    }).get().toString() || $("[name='" + paramStr + "']").val() || Number(-1);
                }
            }
        }
    }
    parameters = params;
    var data = getDataFromServer("POST", URL, parameters, "text");
    plotChartFromJSONData(data, chartId, graphName);
}

function changeChartType(chartType, chartId) {
    var chart = chartArray[chartId];
    if (chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        chartType = chartType.toLowerCase();
        $(chart.series).each(function () {
            if (chartType === "stackedcolumn") {
                if (this.userOptions.yAxis !== null && this.userOptions.yAxis !== "" && this.userOptions.yAxis !== undefined) {
                    var yAxis = Number(this.userOptions.yAxis);
                    var pointPlacement = parseFloat(yAxis * 0.2);
                    this.update({type: 'column', stacking: 'normal', pointPadding: 0.4, pointPlacement: pointPlacement}, false);
                } else {
                    this.update({type: 'column', stacking: 'normal', pointPadding: 0.1, pointPlacement: null}, false);
                }
            } else {
                this.update({type: chartType, stacking: '', pointPadding: 0.1, pointPlacement: null}, false);
            }
        });
        chart.redraw();
    }
}

function setGraphUnits(chartRenderTo, chart, graphName) {
    var s = "%Y-%m-%d %H:%M:%S";
    if (graphName.toLowerCase().indexOf("daily") >= 0) {
        chart.series[0].tooltipOptions.xDateFormat = '%Y-%m-%d';
        s = "%Y-%m-%d";
    } else if (graphName.toLowerCase().indexOf("weekly") >= 0) {
        chart.xAxis[0].update({
            labels: {
                format: '{value:Week %W %Y}',
                align: 'right',
                rotation: -30
            }
        }, false);
        chart.series[0].tooltipOptions.xDateFormat = 'Week %W %Y';
        s = "Week %W %Y";
    } else if (graphName.toLowerCase().indexOf("monthly") >= 0) {
        chart.xAxis[0].update({
            labels: {
                format: '{value:%b %Y}'
            }
        }, false);
        chart.series[0].tooltipOptions.xDateFormat = '%b %Y';
        s = "%b %Y";
    } else if (graphName.toLowerCase().indexOf("yearly") >= 0) {
        chart.xAxis[0].update({
            labels: {
                format: '{value: %Y}'
            }
        }, false);
        chart.series[0].tooltipOptions.xDateFormat = '%Y';
        s = "%Y";
    }
    //chart.series[0].tooltipOptions.valueDecimals = 2;
    chart.tooltip.options.formatter = function () {
        var formattedStr = "";
        if (isNaN(this.x)) {
            formattedStr = "<span style='font-size: 12px'><b>" + this.x + "</b></span><br/>";
        } else {
            var dateTime = Highcharts.dateFormat(s, new Date(this.x));
            if (dateTime !== null && dateTime !== "" && dateTime !== undefined) {
                formattedStr = "<span style='font-size: 12px'><b>" + Highcharts.dateFormat(s, new Date(this.x)) + "</b></span><br/>";
            } else {
                formattedStr = "<span style='font-size: 12px'><b>" + this.x + "</b></span><br/>";
            }
        }
        $.each(this.points, function () {
            var valueSuffix = this.series.tooltipOptions.valueSuffix;
            var numericSymbols = ['K', 'M', 'G', 'T', 'P', 'E'];
            var textStr;
            try {
                textStr = this.series.yAxis.axisTitle.textStr;
            } catch (e) {
                textStr = undefined;
            }
            if (textStr !== null && textStr !== "" && textStr !== undefined) {
                if (textStr.indexOf("Wh") >= 0) {
                    numericSymbols = ['k', 'M', 'G', 'T', 'P', 'E'];
                }
            }
            var ret, i = numericSymbols.length;
            if (Math.abs(this.y) >= 1000) {
                while (i-- && ret === undefined) {
                    var multi = Math.pow(1000, i + 1);
                    if (Math.abs(this.y) >= multi && numericSymbols[i] !== null) {
                        ret = (this.y / multi) + " " + numericSymbols[i] + valueSuffix;
                    }
                }
            }
            formattedStr += "<span style='color:" + this.series.color + "'>" + this.series.name + "</span>: <b>" + (ret ? ret : this.y + " " + valueSuffix) + "</b><br/>";
        });
        return formattedStr;
    };
    chart.yAxis.forEach(function (yAxis, index) {
        var numericSymbols = ['K', 'M', 'G', 'T', 'P', 'E'];
        var textStr;
        try {
            textStr = yAxis.axisTitle.textStr;
        } catch (e) {
            textStr = undefined;
        }
        if (textStr !== null && textStr !== "" && textStr !== undefined) {
            if (textStr.indexOf("Wh") >= 0) {
                numericSymbols = ['k', 'M', 'G', 'T', 'P', 'E'];
            }
        }
        var gridLineWidth = 1;
        if (index !== 0) {
            gridLineWidth = 0;
        }
        yAxis.update({
            gridLineWidth: gridLineWidth,
            labels: {
                formatter: function () {
                    var ret, i = numericSymbols.length;
                    if (Math.abs(this.value) >= 1000) {
                        while (i-- && ret === undefined) {
                            var multi = Math.pow(1000, i + 1);
                            if (Math.abs(this.value) >= multi && numericSymbols[i] !== null) {
                                ret = (this.value / multi) + " " + numericSymbols[i];
                            }
                        }
                    }
                    return (ret ? ret : this.value);
                }
            }
        }, false);
    });
    setTimeout(function () {
        chart.redraw();
        $("#" + chartRenderTo).parent().closest('div').unblock();
    }, 0);
}

function plotChartFromJSONData(data, chartRenderTo, graphName) {
    var exportFileName = graphName.toString().toLowerCase();
    var selNodeName = getSelectedNodeNameForChart();
    if (selNodeName !== null && selNodeName !== "" && selNodeName !== undefined) {
        exportFileName = selNodeName + $.i18n.prop('NE_DELIMITER') + graphName.toString().toLowerCase();
    }
    var existChart = chartArray[chartRenderTo];
    if (existChart !== null && existChart !== " " && existChart !== undefined && existChart !== '') {
        try {
            existChart.destroy();
        } catch (e) {
            //Do Nothing
        }
    }
    var staggerLines = 1;
    if (graphName === "VFD_FLOOR_BASED_DATA" || graphName === "VFD_NE_BASED_DATA") {
        staggerLines = 2;
    }
    var chartWidth = $("#" + chartRenderTo).parent().width() - 2;
    var chartHeight = $("#" + chartRenderTo).parent().height() - 2;
    $("#" + chartRenderTo).width(chartWidth);
    $("#" + chartRenderTo).height(chartHeight);
    Highcharts.setOptions({
        chart: {
            renderTo: chartRenderTo,
            width: chartWidth,
            height: chartHeight,
            alignTicks: false,
            resetZoomButton: {
                position: {
                    align: 'right',
                    verticalAlign: 'top',
                    x: -30,
                    y: 5
                },
                relativeTo: 'chart'
            }
        },
        xAxis: {
            startOfWeek: 0,
            gridLineWidth: 1,
            gridLineColor: '#C0C0C0',
            gridLineDashStyle: 'Solid',
            crosshair: true,
            labels: {
                overflow: 'justify',
                staggerLines: staggerLines
            },
            startOnTick: false,
            endOnTick: false,
            maxPadding: 0
        },
        yAxis: {
            gridLineWidth: 1,
            gridLineColor: '#C0C0C0',
            gridLineDashStyle: 'Solid',
            crosshair: true,
            labels: {
                overflow: 'justify'
            },
            startOnTick: false,
            endOnTick: false,
            maxPadding: 0
        },
        exporting: {
            enabled: true,
            buttons: {
                contextButton: {
                    menuItems: [{
                            text: 'Print',
                            onclick: function () {
                                this.print();
                            }
                        }, {
                            text: 'Export As SVG',
                            onclick: function () {
                                if (Highcharts.exporting.supports("image/svg+xml")) {
                                    this.exportChartLocal({
                                        type: "image/svg+xml",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As PNG',
                            onclick: function () {
                                if (Highcharts.exporting.supports("image/png")) {
                                    this.exportChartLocal({
                                        type: "image/png",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As JPEG',
                            onclick: function () {
                                if (Highcharts.exporting.supports("image/jpeg")) {
                                    this.exportChartLocal({
                                        type: "image/jpeg",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As PDF',
                            onclick: function () {
                                if (Highcharts.exporting.supports("application/pdf")) {
                                    this.exportChartLocal({
                                        type: "application/pdf",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As CSV',
                            onclick: function () {
                                if (Highcharts.exporting.supports("text/csv")) {
                                    this.exportChartLocal({
                                        type: "text/csv",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }, {
                            text: 'Export As Excel',
                            onclick: function () {
                                if (Highcharts.exporting.supports("application/vnd.ms-excel")) {
                                    this.exportChartLocal({
                                        type: "application/vnd.ms-excel",
                                        filename: exportFileName
                                    });
                                }
                            }
                        }]
                }
            }
        },
        plotOptions: {
            series: {
                point: {
                    events: {
                        dblclick: function (event) {
                            if (event.point !== null && event.point !== "" && event.point !== undefined) {
                                event.point.remove();
                                //event.point.update({y: null});
                            }
                        },
                        remove: function () {
                            if (!confirm('Do you really want to remove the selected point?')) {
                                return false;
                            }
                        }
                    }
                }
            }
        }
    });
    var chart = null;
    $("#" + chartRenderTo).removeClass("vertHorzCenterDiv");
    try {
        var chartJSONData = eval('(' + data.replace(/NAN/g, "null") + ')');
        if (chartJSONData.graphdata !== null && chartJSONData.graphdata !== "" && chartJSONData.graphdata !== undefined) {
            chart = new Highcharts.Chart(JSON.parse(chartJSONData.graphdata));
            chartArray[chartRenderTo] = chart;
            if (graphName === "AC_ENERGYSHARING_DATA" || graphName === "VFD_BUILDING_BASED_DATA") {
                $("#" + chartRenderTo).parent().closest('div').unblock();
            } else {
                highlightMinAndMax(chartRenderTo);
                loadChartSeriesAndTypeData(chartRenderTo);
                setGraphUnits(chartRenderTo, chart, graphName);
            }
        } else {
            setDataNotFound(chartRenderTo);
            $("#" + chartRenderTo).parent().closest('div').unblock();
        }
    } catch (e) {
        setDataNotFound(chartRenderTo);
        $("#" + chartRenderTo).parent().closest('div').unblock();
    }
}

function getChartDataFromServer(graphName, chartId, key, QueryNum, startDateTime, endDateTime, additionalReqParams) {
    $("#" + chartId).parent().closest('div').block();
    var URL = $.i18n.prop('SERVER_URL') + "/GraphMgr";
    var parameters = "requestType=GraphMgr&subRequestType=getChartDataForHC&graphName=" + graphName + "&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&key=" + key + "&QueryNum=" + QueryNum;
    var params = $.deserialize(parameters);
    if ($.trim(additionalReqParams) !== null && $.trim(additionalReqParams) !== "null" && $.trim(additionalReqParams) !== undefined && $.trim(additionalReqParams) !== '') {
        var addReqParameters = $.deserialize(additionalReqParams);
        for (var reqParamKey in addReqParameters) {
            if (addReqParameters.hasOwnProperty(reqParamKey)) {
                var paramStr = addReqParameters[reqParamKey];
                if (paramStr.indexOf(",") > -1) {
                    var conditionStr = "";
                    $.each(paramStr.split(","), function (index, item) {
                        if (item !== "" && item !== '' && item !== null && item !== undefined && item !== "null") {
                            var itemValue = $("#" + item).val() || $("[name='" + item + "']").val();
                            if (itemValue !== "" && itemValue !== '' && itemValue !== null && itemValue !== undefined && itemValue !== "null" && itemValue !== "All") {
                                if (itemValue.indexOf(",") > -1) {
                                    var itemValues = "";
                                    $.each(paramStr.split(","), function (index1, item1) {
                                        if (index1 === 0) {
                                            itemValues = "'" + item1 + "'";
                                        } else {
                                            itemValues = ", '" + item1 + "'";
                                        }
                                    });
                                    conditionStr += " AND " + item + " IN (" + itemValues + ")";
                                } else {
                                    conditionStr += " AND " + item + " = '" + itemValue + "'";
                                }
                            }
                        }
                    });
                    params[reqParamKey] = conditionStr;
                } else {
                    params[reqParamKey] = $("#" + paramStr).val() || $("[name='" + paramStr + "']").val() || Number(-1);
                }
            }
        }
    }
    if (startDateTime !== null && startDateTime !== undefined && startDateTime !== "" && startDateTime !== '' && startDateTime !== "null") {
        params.Parm21 = startDateTime;
    }
    if (endDateTime !== null && endDateTime !== undefined && endDateTime !== "" && endDateTime !== '' && endDateTime !== "null") {
        params.Parm22 = endDateTime;
    }
    parameters = params;
    var data = getDataFromServer("POST", URL, parameters, "text");
    plotChartFromJSONData(data, chartId, graphName);
}

function changeChartType(chartId) {
    var chart = chartArray[chartId];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var chartType = $("#" + chartId + "T").combobox('getValue').toLowerCase();
        var chartSeries = $("#" + chartId + "S").combobox('getValue');
        if (chartSeries.toLowerCase() === "all") {
            $(chart.series).each(function () {
                if (chartType === "stackedcolumn") {
                    if (this.userOptions.yAxis !== null && this.userOptions.yAxis !== "" && this.userOptions.yAxis !== undefined) {
                        var yAxis = Number(this.userOptions.yAxis);
                        var pointPlacement = parseFloat(yAxis * 0.2);
                        this.update({type: 'column', stacking: 'normal', pointPadding: 0.4, pointPlacement: pointPlacement}, false);
                    } else {
                        this.update({type: 'column', stacking: 'normal', pointPadding: 0.1, pointPlacement: null}, false);
                    }
                } else {
                    this.update({type: chartType, stacking: '', pointPadding: 0.1, pointPlacement: null}, false);
                }
            });
        } else {
            if (chartSeries !== null && chartSeries !== "" && chartSeries !== undefined) {
                var series = chart.get(chartSeries);
                if (chartType === "stackedcolumn") {
                    if (series.userOptions.yAxis !== null && series.userOptions.yAxis !== "" && series.userOptions.yAxis !== undefined) {
                        var yAxis = Number(series.userOptions.yAxis);
                        var pointPlacement = parseFloat(yAxis * 0.2);
                        series.update({type: 'column', stacking: 'normal', pointPadding: 0.4, pointPlacement: pointPlacement}, false);
                    } else {
                        series.update({type: 'column', stacking: 'normal', pointPadding: 0.1, pointPlacement: null}, false);
                    }
                } else {
                    series.update({type: chartType, stacking: '', pointPadding: 0.1, pointPlacement: null}, false);
                }
            }
        }
        chart.redraw();
    }
}

function loadChartSeriesAndTypeData(chartId) {
    var chart = chartArray[chartId];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        if (chart.series.length > 0) {
            $("#" + chartId + "A").on('click', function () {
                changeChartType(chartId);
            });
            var seriesData = [{
                    "value": "all",
                    "label": "All"
                }];
            $(chart.series).each(function () {
                var seriesObj = {};
                seriesObj.value = this.name;
                seriesObj.label = this.name;
                seriesData.push(seriesObj);
            });
            if ($("#" + chartId + "S").length) {
                $("#" + chartId + "S").combobox({
                    data: seriesData,
                    valueField: 'value',
                    textField: 'label',
                    cache: false,
                    selectOnNavigation: true,
                    required: false,
                    multiple: false,
                    editable: false,
                    disabled: false
                });
                comboboxSearchOnSelect(chartId + "S");
            }
            if ($("#" + chartId + "T").length) {
                $("#" + chartId + "T").combobox({
                    url: $.i18n.prop('CLIENT_URL') + '/' + $.i18n.prop('CHART_TYPES_URL'),
                    valueField: 'value',
                    textField: 'label',
                    cache: false,
                    selectOnNavigation: true,
                    required: false,
                    multiple: false,
                    editable: false,
                    disabled: false
                });
                comboboxSearchOnSelect(chartId + "T");
            }
        }
    } else {
        $("#" + chartId + "A").off('click');
        if ($("#" + chartId + "S").length) {
            $("#" + chartId + "S").combobox('disable', true);
        }
        if ($("#" + chartId + "T").length) {
            $("#" + chartId + "T").combobox('disable', true);
        }
    }
}

function toggleLegend(chartId) {
    var chart = chartArray[chartId];
    if (chart !== null && chart !== "null" && chart !== " " && chart !== "" && chart !== undefined) {
        var legend = chart.legend;
        if ($("#" + chartId + "L").is(':checked')) {
            legend.group.show();
            legend.box.show();
            legend.display = true;
        } else {
            legend.group.hide();
            legend.box.hide();
            legend.display = false;
        }
    }
}
