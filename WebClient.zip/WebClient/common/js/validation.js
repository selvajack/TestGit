$.extend($.fn.validatebox.defaults.rules, {
    equals: {
        validator: function (value, param) {
            return value === $(param[0]).val();
        },
        message: 'Password and confirm password fields does not match.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    minLength: {
        validator: function (value, param) {
            return value.length >= param[0];
        },
        message: 'Please enter at least {0} characters.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    domainName: {
        validator: function (value) {
            return /^(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)$/i.test(value) || /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z-]{2,6}$/i.test(value);
        },
        message: 'Please enter valid domain name.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    emails: {
        validator: function (value) {
            return /^(?:\s*(((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)\s*(?:,|$))+$/i.test(value);
        },
        message: 'Please enter comma separated email address.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    mobileNumbers: {
        validator: function (value) {
            return /^(?:\s*\+[1-9]{1}[0-9]{7,11}\s*(?:,|$))+$/i.test(value);
        },
        message: 'Please enter comma separated mobile number.'
    }
});

/*$.extend($.fn.validatebox.defaults.rules, {
 mobileNumber: {
 validator: function (value) {
 return /^((\+)?[0-9]{1,3})?([-])?([0-9]{7,11})$/i.test(value);
 },
 message: 'Please enter valid phone or mobile number.'
 }
 });*/

$.extend($.fn.validatebox.defaults.rules, {
    phoneNumber: {
        validator: function (value) {
            return /^(\+91|0)?\d{10}$/i.test(value);
        },
        message: 'Please enter valid phone number.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    mobileNumber: {
        validator: function (value) {
            //return /^(\+[\d]{1,3}|0)?[7-9]\d{9}$/i.test(value);
            return /^(\+91|0)?[7-9]\d{9}$/i.test(value);
        },
        message: 'Please enter valid mobile number.'
    }
});

//var mob = /^[1-9]{1}[0-9]{9}$/;
//^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$
//^(\+[\d]{1,3}|0)?[7-9]\d{9}$

$.extend($.fn.validatebox.defaults.rules, {
    pinCode: {
        validator: function (value) {
            return /^([1-9])([0-9]){5}$/i.test(value);
        },
        message: 'Please enter valid pin code.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    alpha: {
        validator: function (value) {
            return /^[a-z\s]+$/i.test(value);
        },
        message: 'Please enter alphabetical characters only.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    alphaNumeric: {
        validator: function (value) {
            return /^[a-zA-Z0-9]+$/i.test(value);
        },
        message: 'Please enter alphanumeric characters.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    dategt: {
        validator: function (value, param) {
            var startDateTime = $(param[0]).datetimebox('getValue');
            var d1 = $.fn.datebox.defaults.parser(startDateTime);
            var d2 = $.fn.datebox.defaults.parser(value);
            return d2 >= d1;
            //return Date.parse(value) <= Date.parse($(param[0]).val());
        },
        message: 'The end date must be greater than equal to start date.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    ipAddress: {
        validator: function (value) {
            return /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/.test(value);
        },
        message: 'Please enter valid ip address.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    charLength: {
        validator: function (value, param) {
            return value.length >= param[0] && value.length <= param[1];
        },
        message: 'Input length should be between {0} and {1}.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    loginUserName: {
        validator: function (value) {
            return /^[a-z0-9._-]*$/.test(value);
        },
        message: 'Please enter valid user name.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    personName: {
        validator: function (value) {
            return /^[A-Za-z]{1}[A-Za-z 0-9.]*$/i.test(value);
        },
        message: 'First letter should be alphabetic.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    name: {
        validator: function (value) {
            return /^[A-Za-z]{1}[A-Za-z 0-9._-]*$/i.test(value);
        },
        message: 'First letter should be alphabetic.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    floorname: {
        validator: function (value) {
            return /^[A-Za-z]{1}[A-Za-z0-9._-]*$/i.test(value);
        },
        message: 'First letter should be alphabetic.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    tenantname: {
        validator: function (value) {
            return /^[A-Za-z]{1}[A-Za-z 0-9.,_-]*$/i.test(value);
        },
        message: 'First letter should be alphabetic.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    shortname: {
        validator: function (value) {
            return /^[A-Za-z]{1}[A-Za-z 0-9]*$/i.test(value);
        },
        message: 'First letter should be alphabetic.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    displayname: {
        validator: function (value) {
            return /^[A-Za-z]{1}[A-Za-z 0-9._-]*$/i.test(value);
        },
        message: 'First letter should be alphabetic.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    appName: {
        validator: function (value) {
            return /^[A-Za-z]{1}[A-Za-z0-9._-]*$/i.test(value);
        },
        message: 'First letter should be alphabetic.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    alphaSpace: {
        validator: function (value) {
            return /^[a-z\s ]+$/i.test(value);
        },
        message: 'Please enter alphabetical characters and space only.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    subSystemId: {
        validator: function (value, param) {
            var subTypeName = $(param[0]).combobox('getValue');
            if (subTypeName === "Water" || subTypeName === "GAS" || subTypeName === "EnvSensor") {
                return /^[A-Fa-f0-9]{4}$/i.test(value);
            } else {
                return (!isNaN(value) && value > 0 && value <= 247);
            }
        },
        message: 'Please enter valid sub system id.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    casmeterid: {
        validator: function (value) {
            return /^[A-Fa-f0-9]{4}$/i.test(value);
        },
        message: 'Please enter valid hexadecimal meter id between 0001 and FFFF.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    goameterid: {
        validator: function (value) {
            return (!isNaN(value) && value > 0 && value <= 247);
        },
        message: 'Please enter valid subsystem id between 1 and 247.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    ipcamurl: {
        validator: function (value) {
            return /^(https?|rtsp|rtmp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);
        },
        message: 'Please enter valid URL.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    version: {
        validator: function (value) {
            return /^[A-Za-z0-9\s/_-]+$/i.test(value);
        },
        message: 'Please enter alpha-numberical characters, space and _-/ only.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    description: {
        validator: function (value) {
            return /^[A-Za-z0-9. ,/_-]*$/i.test(value);
        },
        message: 'Please enter alpha-numberical characters, space and .,/- only.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    tag: {
        validator: function (value) {
            return /^[A-Za-z0-9.,/_-]*$/i.test(value);
        },
        message: 'Please enter alpha-numberical characters and .,/- only.'
    }
});
$.extend($.fn.validatebox.defaults.rules, {
    futureDate: {
        validator: function (value, param) {
            if (value !== null && value !== undefined && value !== "") {
                var currentTime = new Date().setMinutes(new Date().getMinutes() + 1);
                var selTime = Date.parse(new Date(value));
                return currentTime <= selTime;
            } else {
                return true;
            }
        },
        message: 'Please enter a future datetime.'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    threadRange: {
        validator: function (value) {
            return /^0*(?:[1-9][0-9]?|100)$/.test(value);
        },
        message: 'Please enter 1 to 100 only'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    threadModule: {
        validator: function (value) {
            return /^[A-Z_]+$/.test(value);
        },
        message: 'Please enter upper case characters only'
    }
});

$.extend($.fn.validatebox.defaults.rules, {
    threadttl: {
        validator: function (value) {
            return /^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[12][0-9]{3}|3[0-5][0-9]{2}|3600)$/.test(value);
        },
        message: 'Please enter 1 to 3600 only'
    }
});
