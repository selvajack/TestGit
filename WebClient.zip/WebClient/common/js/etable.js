var editIndexArr = {};
function endEditing(datagridId) {
    var editIndex = editIndexArr[datagridId];
    if (editIndex === null || editIndex === "" || editIndex === undefined) {
        return true;
    }
    if ($('#' + datagridId).datagrid('validateRow', editIndex)) {
        $('#' + datagridId).datagrid('endEdit', editIndex);
        editIndex = undefined;
        editIndexArr[datagridId] = undefined;
        return true;
    } else {
        return false;
    }
}

function onDoubleClickCell(index, field, value) {
    var datagridId = $(this).attr('id');
    var editIndex = editIndexArr[datagridId];
    if (editIndex !== index) {
        if (endEditing(datagridId)) {
            $('#' + datagridId).datagrid('selectRow', index).datagrid('beginEdit', index);
            var ed = $('#' + datagridId).datagrid('getEditor', {index: index, field: field});
            if (ed) {
                ($(ed.target).data('textbox') ? $(ed.target).textbox('textbox') : $(ed.target)).focus();
            }
            editIndex = index;
            editIndexArr[datagridId] = index;
        } else {
            setTimeout(function () {
                $('#' + datagridId).datagrid('selectRow', editIndex);
            }, 0);
        }
    }
}

function onEndEdit(rowIndex, row) {
    var datagridId = $(this).attr('id');
    var fields = $('#' + datagridId).datagrid('getColumnFields');
    $.each(fields, function (index, field) {
        var ed = $('#' + datagridId).datagrid('getEditor', {
            index: rowIndex,
            field: field
        });
        if (ed !== null && ed !== "" && ed !== undefined) {
            if (ed.type !== null && ed.type !== "" && ed.type !== undefined) {
                if (ed.type === "combobox") {
                    row[field] = $(ed.target).combobox('getText');
                }
            }
        }
    });
}

function onBeginEdit(rowIndex, row) {
    var datagridId = $(this).attr('id');
    var fields = $('#' + datagridId).datagrid('getColumnFields');
    $.each(fields, function (index, field) {
        var ed = $('#' + datagridId).datagrid('getEditor', {
            index: rowIndex,
            field: field
        });
        var options = "";
        if (ed !== null && ed !== "" && ed !== undefined) {
            if (ed.type !== null && ed.type !== "" && ed.type !== undefined) {
                if (ed.type === "numberspinner") {
                    if (field === "dcCutOffLoad1" || field === "dcCutOffLoad2") {
                        options = $(ed.target).numberspinner('options');
                        options.max = row.rbmcfgsubsystemtype.split("_")[1];
                        $(ed.target).numberspinner(options);
                        $(ed.target).numberspinner('fix');
                    }
                } else if (ed.type === "combobox") {
                    if (field === "vavReadingVavstatus") {
                        options = $(ed.target).combobox('options');
                        var setTempED = $('#' + datagridId).datagrid('getEditor', {
                            index: rowIndex,
                            field: "vavReadingSetTemp"
                        });
                        var setTempOptions = "";
                        options.onChange = function (newValue, oldValue) {
                            if (newValue !== null && newValue !== "" && newValue !== undefined) {
                                if (newValue === 1 || $.trim(newValue) === "1") {
                                    $(setTempED.target).numberspinner('enable');
                                    setTempOptions = $(setTempED.target).numberspinner('options');
                                    setTempOptions.min = 15;
                                    setTempOptions.max = 31;
                                    $(setTempED.target).numberspinner(setTempOptions);
                                    $(setTempED.target).numberspinner('fix');
                                } else {
                                    setTempOptions = $(setTempED.target).numberspinner('options');
                                    setTempOptions.min = 0;
                                    setTempOptions.max = 31;
                                    $(setTempED.target).numberspinner(setTempOptions);
                                    $(setTempED.target).numberspinner('fix');
                                    $(setTempED.target).numberspinner('disable');
                                }
                            }
                        };
                        options.onSelect = function (record) {
                            if (record !== null && record !== "" && record !== undefined) {
                                if (record.value === 1) {
                                    $(setTempED.target).numberspinner('enable');
                                    setTempOptions = $(setTempED.target).numberspinner('options');
                                    setTempOptions.min = 15;
                                    setTempOptions.max = 31;
                                    $(setTempED.target).numberspinner(setTempOptions);
                                    $(setTempED.target).numberspinner('fix');
                                } else {
                                    setTempOptions = $(setTempED.target).numberspinner('options');
                                    setTempOptions.min = 0;
                                    setTempOptions.max = 31;
                                    $(setTempED.target).numberspinner(setTempOptions);
                                    $(setTempED.target).numberspinner('fix');
                                    $(setTempED.target).numberspinner('disable');
                                }
                            }
                        };
                        $(ed.target).combobox(options);
                        $(ed.target).combobox('setValue', row.vavReadingVavstatus);
                    }
                    else if (field === "vfdReadingMode") {
                        options = $(ed.target).combobox('options');
                        var vfdStatusED = $('#' + datagridId).datagrid('getEditor', {
                            index: rowIndex,
                            field: "vfdReadingStatus"
                        });
                        var vfdFrequencyED = $('#' + datagridId).datagrid('getEditor', {
                            index: rowIndex,
                            field: "vfdReadingFreq"
                        });
                        options.onChange = function (newValue, oldValue) {
                            if (newValue !== null && newValue !== "" && newValue !== undefined) {
                                if (newValue === 0 || $.trim(newValue) === "0") {
                                    $(vfdStatusED.target).combobox('enable');
                                    var selValue = $(vfdStatusED.target).combobox('getValue');
                                    if (selValue !== null && selValue !== "" && selValue !== undefined) {
                                        if (selValue === 1 || $.trim(selValue) === "1") {
                                            $(vfdFrequencyED.target).numberspinner('enable');
                                        } else {
                                            $(vfdFrequencyED.target).numberspinner('disable');
                                        }
                                    }
                                } else {
                                    $(vfdStatusED.target).combobox('disable');
                                    $(vfdFrequencyED.target).numberspinner('disable');
                                }
                            }
                        };
                        options.onSelect = function (record) {
                            if (record !== null && record !== "" && record !== undefined) {
                                if (record.value === "0") {
                                    $(vfdStatusED.target).combobox('enable');
                                } else {
                                    $(vfdStatusED.target).combobox('disable');
                                    $(vfdFrequencyED.target).numberspinner('disable');
                                }
                            }
                        };
                        $(ed.target).combobox(options);
                        $(ed.target).combobox('setValue', row.vfdReadingMode);
                    } else if (field === "vfdReadingStatus") {
                        options = $(ed.target).combobox('options');
                        var vfdFrequencyED = $('#' + datagridId).datagrid('getEditor', {
                            index: rowIndex,
                            field: "vfdReadingFreq"
                        });
                        var vfdModeED = $('#' + datagridId).datagrid('getEditor', {
                            index: rowIndex,
                            field: "vfdReadingMode"
                        });

                        options.onChange = function (newValue, oldValue) {
                            if (newValue !== null && newValue !== "" && newValue !== undefined) {
                                var selVfdModeValue = $(vfdModeED.target).combobox('getValue');
                                if (selVfdModeValue === 0 || $.trim(selVfdModeValue) === "0" && newValue === 1 || $.trim(newValue) === "1") {
                                    $(vfdFrequencyED.target).numberspinner('enable');
                                } else {
                                    $(vfdFrequencyED.target).numberspinner('disable');
                                }
                            }
                        };
                        options.onSelect = function (record) {
                            if (record !== null && record !== "" && record !== undefined) {
                                var selVfdModeValue = $(vfdModeED.target).combobox('getValue');
                                if (selVfdModeValue === "0" || $.trim(selVfdModeValue) === "0" && record.value === "1") {
                                    $(vfdFrequencyED.target).numberspinner('enable');
                                } else {
                                    $(vfdFrequencyED.target).numberspinner('disable');
                                }
                            }
                        };
                        $(ed.target).combobox(options);
                        $(ed.target).combobox('setValue', row.vfdReadingStatus);
                    }

                }
            }
        }
    });
}

function accept(datagridId) {
    if (endEditing()) {
        $('#' + datagridId).datagrid('acceptChanges');
    }
}

function reject(datagridId) {
    $('#' + datagridId).datagrid('rejectChanges');
    editIndexArr[datagridId] = undefined;
}

function getChanges(datagridId) {
    var rows = $('#' + datagridId).datagrid('getChanges');
    return rows;
}

function getSelectedNodeForNE(value) {
    var node = null;
    node = $('#networkTree').tree('find', value);
    return node;
}

function configDataToDevice(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    var msgForWindow = {};
    var cfgNeName = null;
    var updated = getChanges(datagridId);
    requestParams += "&operationDoneBy=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var param = $.deserialize(requestParams);
    param.username = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    param.operationDoneBy = $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY'));
    var win = $.messager.alert({
        title: title,
        msg: title
    });
    $.each(updated, function (index, record) {
        if (record.vfdcfgnename !== undefined) {
            cfgNeName = record.vfdcfgnename;
        }
        else if (record.vavcfgnename !== undefined) {
            cfgNeName = record.vavcfgnename;
        }
        else if (record.rbmcfgnename !== undefined) {
            cfgNeName = record.rbmcfgnename;
        }
        msgForWindow[cfgNeName] = cfgNeName + "<br/>";
        updateMsgForDialog(msgForWindow, win);
        var configParam = param;
        $.each(record, function (key, value) {
            if (key !== null && key !== "" && key !== undefined) {
                if (key.indexOf('neid') > -1) {
                    var node = getSelectedNodeForNE($.i18n.prop('NE_STR') + $.i18n.prop('TREE_DELIMITER') + value);
                    if (node.attributes !== null && node.attributes !== "" && node.attributes !== undefined) {
                        if (node.attributes.type !== undefined && node.attributes.type !== null && node.attributes.type !== "") {
                            if (node.attributes.type === $.i18n.prop('NE_STR')) {
                                var neId = node.id.split($.i18n.prop('TREE_DELIMITER'))[1];
                                var neName = node.text;
                                var neVersion = node.attributes.neVersionNumber;
                                var neTypeName = node.attributes.neTypeName;
                                var agentId = node.attributes.agentId;
                                var agentIp = node.attributes.agentIp;
                                var agentPort = node.attributes.agentPort;
                                var agentUserId = node.attributes.agentUserId;
                                var agentMobileNumber = node.attributes.agentMobileNumber;
                                param.neId = neId;
                                param.neName = neName;
                                param.neVersion = neVersion;
                                param.neTypeName = neTypeName;
                                param.agentId = agentId;
                                param.ipAddress = agentIp;
                                param.port = agentPort;
                                param.operationType = 'SET';
                                param.uniqueId = agentUserId;
                                param.mobileNumber = agentMobileNumber;
                            }
                        }
                    }
                }
                else if (key.indexOf('subsystemid') > -1) {
                    configParam.subSystemId = value;
                } else if (key.indexOf('subsystemname') > -1) {
                    configParam.subSystemName = value;
                    configParam.managedObjectInstance = configParam.subSystemId;
                    configParam.managedObjectClass = value;
                } else if (key.indexOf('subsystemtype') > -1) {
                    configParam.subSystem = value;
                    configParam.subSystemType = value;
                    var typeWithVersion = value;
                    var subSystemVersion = value.split("_")[2];
                    if ($.trim(subSystemVersion) !== null && $.trim(subSystemVersion) !== "" && $.trim(subSystemVersion) !== undefined) {
                        typeWithVersion = value + $.i18n.prop('NE_DELIMITER') + subSystemVersion;
                    }
                    configParam.typeWithVersion = typeWithVersion;
                } else if (key.indexOf('subsystypeid') > -1) {
                    configParam.subSystemTypeId = value;
                }
                else if (key.indexOf('nename') > -1) {
                    //Do Nothing
                } else if (value !== null && value !== "" && value !== undefined) {
                    var fieldOptions = $('#' + datagridId).datagrid('getColumnOption', key);
                    if (fieldOptions.editable === true) {
                        configParam["device_" + key] = value;
                    }
                }
            }

        });
        if (configParam.hasOwnProperty('subSystemId')) {
            var data = configureDeviceDataUsingAjax("POST", URL, configParam, "text");
            var configStatus = eval('(' + data + ')');
            updateStatusMessage(configStatus, datagridId);
            msgForWindow[cfgNeName] = cfgNeName + " : " + configStatus.status + "<br/>";
        }
        updateMsgForDialog(msgForWindow, win);
    });
}

function updateMsgForDialog(msgForWindow, win) {
    var msgForWndowStr = "";
    $.each(msgForWindow, function (index, rec) {
        msgForWndowStr += rec;
    });
    win.html(msgForWndowStr);
    //win.show(msgForWndowStr);
}

function updateDataToServerForED(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables) {
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    endEditing(datagridId);
    var rows = getChanges(datagridId);
    if (rows) {
        var dlg = $.messager.confirm({
            title: $.i18n.prop('CONFIRM_TITLE'),
            msg: $.i18n.prop('CONFIG_MSG') + " " + title,
            buttons: [{
                    text: 'Accept',
                    onClick: function () {
                        dlg.dialog('destroy');
                        configDataToDevice(parentId, datagridId, data, refreshURL, refreshParams, URL, requestParams, title, label, iconClass, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                        accept(datagridId);
                    }
                }, {
                    text: 'Reject',
                    onClick: function () {
                        reject(datagridId);
                        dlg.dialog('destroy');
                    }
                }, {
                    text: 'Cancel',
                    onClick: function () {
                        dlg.dialog('destroy');
                    }
                }]
        });
    } else {
        $.messager.alert($.i18n.prop('INFO_TITLE'), $.i18n.prop('CONFIG_ROW_MSG'), 'info');
    }
}

function reloadDataFromServerForED(parentId, datagridId, URL, requestParams, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, title) {
    var selected = $('#' + datagridId).datagrid('getSelected');
    var rowCount = $('#' + datagridId).datagrid('getRows').length;
    $('#' + datagridId).datagrid('clearChecked');
    var pager = $('#' + datagridId).datagrid('getPager');
    $(pager).find('a.l-btn').each(function () {
        $(this).tooltip('destroy');
    });
    var emptyData = {
        total: 0,
        rows: []
    };
    if (clearChildTables !== '' && clearChildTables !== null && clearChildTables !== undefined && clearChildTables !== "null") {
        $.each(clearChildTables.split(","), function (index, item) {
            try {
                if ($('#' + item).length) {
                    $('#' + item).datagrid('loadData', emptyData);
                    $('#' + item).datagrid('clearSelections');
                    $('#' + item).datagrid('clearChecked');
                }
            } catch (err) {
                try {
                    if ($('#' + item).length) {
                        $('#' + item).form('clear');
                    }
                } catch (e) {
                    //Do Nothing
                }
            }
        });
    }
    if (parentTableId !== null && parentTableId !== undefined && parentTableId !== '' && parentTableId !== "null") {
        var row = $('#' + parentTableId).datagrid('getSelected');
        if (!row) {
            var message = $.i18n.prop('PARENT_ROW_MSG').replace('<table>', parentTableActionLabel);
            $.messager.alert($.i18n.prop('INFO_TITLE'), message, 'info');
            return;
        }
    }
    var parameters = addAddtReqParamToReqParam(requestParams, additionalReqParams);
    var jsonData = getDataFromServer("POST", URL, parameters, "text");
    jsonData = $.trim(jsonData).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '').replace(/"\\"/g, '"').replace(/\\""/g, '"').replace(/"checkBoxFormatter"/g, "checkBoxFormatter").replace(/"UserNEPrivileges"/g, "UserNEPrivileges").replace(/"UserDefaultNEPrivileges"/g, "UserDefaultNEPrivileges").replace(/"mapKeyValues"/g, "mapKeyValues");
    var data = eval('(' + jsonData + ')');
    var rowWithTotal = {};
    rowWithTotal.total = data.total;
    rowWithTotal.rows = data.rows;
    var selectedRowIndex = -1;
    if (selected) {
        selectedRowIndex = $('#' + datagridId).datagrid('getRowIndex', selected);
    }
    $('#' + datagridId).datagrid('loadData', rowWithTotal);
    if (Number(data.total) > 0 && Number(rowCount) <= 0) {
        reloadWithFilter(parentId, datagridId, true, data);
    }
    if (Number(data.total) <= 0) {
        $('#' + datagridId).datagrid('clearSelections');
        reloadWithFilter(parentId, datagridId, true, data);
    }
    if (selected && selectedRowIndex > -1 && Number(data.total) > 0 && Number(rowCount) > 0) {
        if (title === "Delete") {
            $('#' + datagridId).datagrid('clearSelections');
        } else if (title === "Add" || title === "Update") {
            $('#' + datagridId).datagrid('selectRow', selectedRowIndex);
            $('#' + datagridId).datagrid('highlightRow', selectedRowIndex);
        }
    }
    if (title === "Delete") {
        if (Number(rowCount) === 1) {
            $('#' + datagridId).datagrid('clearSelections');
            $('#' + datagridId).datagrid('getPager').pagination('select');
        }
    }
    updateStatusMessage(data, datagridId);
    setOtherDataGridOptions(datagridId);
}

function addEditActionIconForED(parentId, datagridId, data, URL, parameters, editURL, editParameters, actionLabel, additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, pagesize, pagelist) {
    var pager = $('#' + datagridId).datagrid('getPager');
    pager.pagination({
        pageSize: Number(pagesize),
        pageList: pagelist.split(','),
        total: data.total,
        onBeforeRefresh: function () {
            reloadDataFromServerForED(parentId, datagridId, URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables, "Refresh");
            return false;
        },
        buttons: [{
                iconCls: 'icon-save',
                handler: function () {
                    updateDataToServerForED(parentId, datagridId, data, URL, parameters, editURL, editParameters, actionLabel, "Configuration", "icon-edit", additionalReqParams, disabledParam, duplicateParam, parentTableId, parentTableActionLabel, fitColumns, disabledKey, clearChildTables);
                }
            }, '-',
            {
                iconCls: 'icon-csv',
                handler: function () {
                    exportAsCSV(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-excel',
                handler: function () {
                    exportAsExcel(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-pdf',
                handler: function () {
                    exportAsPDF(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }, {
                iconCls: 'icon-xml',
                handler: function () {
                    exportAsXML(URL, parameters, additionalReqParams, parentTableId, parentTableActionLabel);
                }
            }]
    });
}