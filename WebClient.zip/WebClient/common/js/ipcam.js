var SelPlayerIdArray = [];
var SelViewArray = [];
var SelFileURLArray = [];

function playAllIpCAMPlayers() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMPlayAndCloseBtn";
    $("#" + id + " span.l-btn-text").text($.i18n.prop('CLOSE_ALL_LABEL'));
    for (var i = 1; i <= selView; i++) {
        var playerId = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMPlayer" + i;
        loadIpCAM(playerId, i);
        updateIpCAMTreeIcon(i);
    }
}

function closeAllIpCAMPlayers() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMPlayAndCloseBtn";
    $("#" + id + " span.l-btn-text").text($.i18n.prop('PLAY_ALL_LABEL'));
    for (var i = 1; i <= 16; i++) {
        var playerId = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMPlayer" + i;
        $("#" + playerId).empty();
        clearIpCAMTreeIcon(i);
    }
}

function playAndStopIPCam() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMPlayAndCloseBtn";
    var selText = $("#" + id + " span.l-btn-text").text();
    if (selText === $.i18n.prop('PLAY_ALL_LABEL')) {
        playAllIpCAMPlayers();
    } else if (selText === $.i18n.prop('CLOSE_ALL_LABEL')) {
        closeAllIpCAMPlayers();
    }
}

function clearIpCAMTreeIcon(nodeId) {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMTree";
    var node = $('#' + id).tree('find', nodeId);
    $('#' + id).tree('update', {
        target: node.target,
        iconCls: 'defaultcam'
    });
}

function updateIpCAMTreeIcon(nodeId) {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMTree";
    var node = $('#' + id).tree('find', nodeId);
    $('#' + id).tree('update', {
        target: node.target,
        iconCls: 'selectedcam'
    });
}

function reloadIpCamTree() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMTree";
    var selectedTreeNode = $('#' + id).tree('getSelected');
    $('#' + id).block();
    var URL = $.i18n.prop('SERVER_URL') + "/getIPCAMTreeData";
    var parameters = "requestType=IPCAMTree&subRequestType=refreshIPCAMTree&key=IPCAM_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&BuildingName=" + buildingName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#' + id).tree('loadData', treeJsonData.nodes);
    try {
        var nodeId = selectedTreeNode.id;
        var node = $('#' + id).tree('find', nodeId);
        if (node !== null && node !== "" && node !== undefined) {
            $('#' + id).tree('select', node.target);
            $('#' + id).tree('expandTo', node.target);
            $('#' + id).tree('scrollTo', node.target);
        }
    } catch (e) {
        //Do Nothing
    }
    $('#' + id).unblock();
}

function loadIpCamTree() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER') + "IpCAMTree";
    var URL = $.i18n.prop('SERVER_URL') + "/getIPCAMTreeData";
    var parameters = "requestType=IPCAMTree&subRequestType=refreshIPCAMTree&key=IPCAM_TREE&username=" + $.jStorage.get($.i18n.prop('LOGGED_IN_USER_NAME_KEY')) + "&BuildingName=" + buildingName;
    var replyFormat = getDataFromServer("POST", URL, $.deserialize(parameters), "text");
    var data = eval('(' + replyFormat + ')');
    updateStatusMessage(data, "");
    var treeData = $.trim(data.treedata).replace(/\n/g, '').replace(/\t/g, '').replace(/\r/g, '');
    var treeJsonData = $.parseJSON(unescape(treeData));
    $('#' + id).tree({
        data: treeJsonData.nodes,
        animate: true,
        onBeforeSelect: function (node) {
            $(this).find('.tooltip-f').tooltip('destroy');
        },
        onSelect: function (node) {
            $.parser.parse($(this));
            $('#' + id).tree('update', {
                target: node.target,
                iconCls: 'selectedcam'
            });
            loadIpCAM(SelPlayerIdArray[buildingName], node.id);
        },
        formatter: function (node) {
            return '<span title=\'' + node.text + '\' class=\'easyui-tooltip\'>' + node.text + '</span>';
        },
        onLoadSuccess: function (node, data) {
            $.parser.parse($(this));
            SwitchToFourView();
        }
    });
}

function SwitchToFS() {
    var buildingName = getSelectedBuildingName();
    var selVideoPlayerId = SelPlayerIdArray[buildingName] + $.i18n.prop('NE_DELIMITER') + "Video";
    if (selVideoPlayerId !== null && selVideoPlayerId !== "" && selVideoPlayerId !== undefined) {
        var vid = document.getElementById(selVideoPlayerId);
        if (vid.requestFullScreen) {
            vid.requestFullScreen();
        } else if (vid.webkitRequestFullScreen) {
            vid.webkitRequestFullScreen();
        } else if (vid.mozRequestFullScreen) {
            vid.mozRequestFullScreen();
        } else if (vid.msRequestFullscreen) {
            vid.msRequestFullscreen();
        }
    }
}

function setSelIpCAMPlayerId(selIpCAMPlayerIdTemp) {
    var buildingName = getSelectedBuildingName();
    SelPlayerIdArray[buildingName] = selIpCAMPlayerIdTemp;
}

function loadIpCAM(playerId, channelNum) {
    var playerVideoId = playerId + $.i18n.prop('NE_DELIMITER') + "Video";
    $("#" + playerId).empty();
    var playerContent = '<video id="' + playerVideoId + '" class="video-js vjs-default-skin vjs-big-play-centered" controls preload="auto" data-setup=\'{"example_option": true, "controlBar": { "muteToggle": false }, "autoplay": false, "techOrder": ["flash", "html5"]}\'>' +
        '<source src="rtmp://10.7.143.76/live/85" type="rtmp/flv">' +
        '<source src="http://10.7.143.76:1935/live/85" type="video/flv">' +
        '</video>';
    $("#" + playerId).append(playerContent);
    videojs.options.flash.swf = $.i18n.prop('CLIENT_URL') + "/videojs/video-js.swf";
    $("#" + playerVideoId).width($("#" + playerId).width());
    $("#" + playerVideoId + " object").width($("#" + playerId).width());
    $("#" + playerVideoId).height($("#" + playerId).height());
    $("#" + playerVideoId + " object").height($("#" + playerId).height());
}

function loadIpCAMPanelForPlayer(playerIds) {
    $.each(playerIds.split(","), function (index, playerId) {
        var playerPanelId = playerId + "Panel";
        $(playerPanelId).panel({
            tools: [{
                    iconCls: 'icon-clear',
                    handler: function () {
                        $("#" + playerId).empty();
                    }
                }],
            onResize: function (w, h) {
                var playerId = $(this).attr("id");
                $("#" + playerId + " > object").width($(this).width());
                $("#" + playerId + " > object").height($(this).height());
            }
        });
        $(playerPanelId).parent("div.panel").on("click", function (e) {
            $(playerIds).removeClass("SelIpCAMPlayer");
            $(playerId).addClass("SelIpCAMPlayer");
            setSelIpCAMPlayerId(playerId);
        });
    });
}

function SwitchToSingleView() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER');
    closeAllIpCAMPlayers();
    $("#" + id + "IpCAMView").empty();
    var ipCAMContent = '<div id="' + id + 'IpCAMPlayer1Panel" class="IPCAMPanel" title="IP CAM 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer1" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>';
    $("#" + id + "IpCAMView").html(ipCAMContent);
    loadIpCAMPanelForPlayer("#" + id + "IpCAMPlayer1");
    SelViewArray[buildingName] = 1;
}

function SwitchToFourView() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER');
    closeAllIpCAMPlayers();
    $("#" + id + "IpCAMView").empty();
    var ipCAMContent = '<div id="' + id + 'IpCAMLayout1" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer1Panel" class="IPCAMPanel" title="IP CAM 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer1" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="IPCAMLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer2Panel" class="IPCAMPanel" title="IP CAM 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer2" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="IPCAMLayout" collapsible="false" border="false" style="width:100%;height:50%;padding:1px">' +
        '<div id="' + id + 'IpCAMLayout2" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer3Panel" class="IPCAMPanel" title="IP CAM 3" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer3" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="IPCAMLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer3Panel" class="IPCAMPanel" title="IP CAM 4" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer4" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + id + "IpCAMView").html(ipCAMContent);
    $("#" + id + "IpCAMLayout1,#" + id + "IpCAMLayout2").layout();
    loadIpCAMPanelForPlayer("#" + id + "IpCAMPlayer1,#" + id + "IpCAMPlayer2,#" + id + "IpCAMPlayer3,#" + id + "IpCAMPlayer4");
    SelViewArray[buildingName] = 4;
}

function SwitchToSixView() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER');
    closeAllIpCAMPlayers();
    $("#" + id + "IpCAMView").empty();
    var ipCAMContent = '<div id="' + id + 'IpCAMLayout1" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer1Panel" class="IPCAMPanel" title="IP CAM 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer1" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="IPCAMLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMLayout2" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer2Panel" class="IPCAMPanel" title="IP CAM 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer2" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="IPCAMLayout" collapsible="false" border="false" style="width:100%;height:50%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer3Panel" class="IPCAMPanel" title="IP CAM 3" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer3" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="IPCAMLayout" collapsible="false" border="false" style="width:100%;height:34%;padding:1px">' +
        '<div id="' + id + 'IpCAMLayout3" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="IPCAMLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer4Panel" class="IPCAMPanel" title="IP CAM 4" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer4" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer5Panel" class="IPCAMPanel" title="IP CAM 5" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer5" class="player5 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="IPCAMLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer6Panel" class="IPCAMPanel" title="IP CAM 6" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer6" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + id + "IpCAMView").html(ipCAMContent);
    $("#" + id + "IpCAMLayout1,#" + id + "IpCAMLayout2,#" + id + "IpCAMLayout3").layout();
    loadIpCAMPanelForPlayer("#" + id + "IpCAMPlayer1,#" + id + "IpCAMPlayer2,#" + id + "IpCAMPlayer3,#" + id + "IpCAMPlayer4,#" + id + "IpCAMPlayer5,#" + id + "IpCAMPlayer6");
    SelViewArray[buildingName] = 6;
}

function SwitchToEightView() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER');
    closeAllIpCAMPlayers();
    $("#" + id + "IpCAMView").empty();
    var ipCAMContent = '<div id="' + id + 'IpCAMLayout1" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer1Panel" class="IPCAMPanel" title="IP CAM 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer1" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="IPCAMLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMLayout2" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="north" class="IPCAMLayout" collapsible="false" border="false" style="width:100%;height:33%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer2Panel" class="IPCAMPanel" title="IP CAM 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer2" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer3Panel" class="IPCAMPanel" title="IP CAM 3" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer3" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="IPCAMLayout" collapsible="false" border="false" style="width:100%;height:33%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer4Panel" class="IPCAMPanel" title="IP CAM 4" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer4" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="IPCAMLayout" collapsible="false" border="false" style="width:100%;height:25%;padding:1px">' +
        '<div id="' + id + 'IpCAMLayout3" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="IPCAMLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer5Panel" class="IPCAMPanel" title="IP CAM 5" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer5" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false">' +
        '<div id="' + id + 'IpCAMLayout4" class="IPCAMLayout" data-options="fit:true" border="false">' +
        '<div region="center" class="IPCAMLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer6Panel" class="IPCAMPanel" title="IP CAM 6" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer6" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="IPCAMLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer7Panel" class="IPCAMPanel" title="IP CAM 7" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer7" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="IPCAMLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="' + id + 'IpCAMPlayer8Panel" class="IPCAMPanel" title="IP CAM 8" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="' + id + 'IpCAMPlayer8" class="IPCAMPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + id + "IpCAMView").html(ipCAMContent);
    $("#" + id + "IpCAMLayout1,#" + id + "IpCAMLayout2,#" + id + "IpCAMLayout3,#" + id + "IpCAMLayout4").layout();
    loadIpCAMPanelForPlayer("#" + id + "IpCAMPlayer1,#" + id + "IpCAMPlayer2,#" + id + "IpCAMPlayer3,#" + id + "IpCAMPlayer4,#" + id + "IpCAMPlayer5,#" + id + "IpCAMPlayer6,#" + id + "IpCAMPlayer7,#" + id + "IpCAMPlayer8");
    SelViewArray[buildingName] = 8;
}

function SwitchToNineView() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER');
    closeAllIpCAMPlayers();
    $("#" + id + "IpCAMView").empty();
    var ipCAMContent = '<div id="cctvLayout1" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="north" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:33%;padding:1px">' +
        '<div id="cctvLayout2" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="player1Panel" class="player1Panel cctvPlayer" title="CAM 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player1" class="player1 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player2Panel" class="player2Panel cctvPlayer" title="CAM 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player2" class="player2 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="player3Panel" class="player3Panel cctvPlayer" title="CAM 3" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player3" class="player3 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout3" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="player4Panel" class="player4Panel cctvPlayer" title="CAM 4" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player4" class="player4 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player5Panel" class="player5Panel cctvPlayer" title="CAM 5" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player5" class="player5 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="player6Panel" class="player6Panel cctvPlayer" title="CAM 6" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player6" class="player6 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:33%;padding:1px">' +
        '<div id="cctvLayout4" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="player7Panel" class="player7Panel cctvPlayer" title="CAM 7" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player7" class="player7 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player8Panel" class="player8Panel cctvPlayer" title="CAM 8" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player8" class="player8 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:33%;height:100%;padding:1px">' +
        '<div id="player9Panel" class="player9Panel cctvPlayer" title="CAM 9" style="width:100%;height:100%;padding:1px">' +
        '<div id="player9" class="player9 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + id + "IpCAMView").html(ipCAMContent);
    $("#" + id + "IpCAMLayout1,#" + id + "IpCAMLayout2,#" + id + "IpCAMLayout3,#" + id + "IpCAMLayout4").layout();
    loadIpCAMPanelForPlayer("#" + id + "IpCAMPlayer1,#" + id + "IpCAMPlayer2,#" + id + "IpCAMPlayer3,#" + id + "IpCAMPlayer4,#" + id + "IpCAMPlayer5,#" + id + "IpCAMPlayer6,#" + id + "IpCAMPlayer7,#" + id + "IpCAMPlayer8,#" + id + "IpCAMPlayer9");
    SelViewArray[buildingName] = 9;
}

function SwitchToThirteenView() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER');
    closeAllIpCAMPlayers();
    $("#" + id + "IpCAMView").empty();
    var ipCAMContent = '<div id="cctvLayout1" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="north" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:25%;padding:1px">' +
        '<div id="cctvLayout2" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player1Panel" class="player1Panel cctvPlayer" title="CAM 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player1" class="player1 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout3" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="player2Panel" class="player2Panel cctvPlayer" title="CAM 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player2" class="player2 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player3Panel" class="player3Panel cctvPlayer" title="CAM 3" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player3" class="player3 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player4Panel" class="player4Panel cctvPlayer" title="CAM 4" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player4" class="player4 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout4" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="cctvLayout5" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="north" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:50%;padding:1px">' +
        '<div id="player5Panel" class="player5Panel cctvPlayer" title="CAM 5" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player5" class="player5 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player6Panel" class="player6Panel cctvPlayer" title="CAM 6" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player6" class="player6 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player7Panel" class="player7Panel cctvPlayer" title="CAM 7" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player7" class="player7 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="cctvLayout6" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="north" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:50%;padding:1px">' +
        '<div id="player8Panel" class="player8Panel cctvPlayer" title="CAM 8" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player8" class="player8 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player9Panel" class="player9Panel cctvPlayer" title="CAM 9" style="width:100%;height:100%;padding:1px">' +
        '<div id="player9" class="player9 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:25%;padding:1px">' +
        '<div id="cctvLayout9" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player10Panel" class="player10Panel cctvPlayer" title="CAM 10" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player10" class="player10 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout10" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="player11Panel" class="player11Panel cctvPlayer" title="CAM 11" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player11" class="player11 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player12Panel" class="player12Panel cctvPlayer" title="CAM 12" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player12" class="player12 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player13Panel" class="player13Panel cctvPlayer" title="CAM 13" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player13" class="player13 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + id + "IpCAMView").html(ipCAMContent);
    $("#" + id + "IpCAMLayout1,#" + id + "IpCAMLayout2,#" + id + "IpCAMLayout3,#" + id + "IpCAMLayout4,#" + id + "IpCAMLayout5,#" + id + "IpCAMLayout6,#" + id + "IpCAMLayout7,#" + id + "IpCAMLayout8,#" + id + "IpCAMLayout9,#" + id + "IpCAMLayout10").layout();
    loadIpCAMPanelForPlayer("#" + id + "IpCAMPlayer1,#" + id + "IpCAMPlayer2,#" + id + "IpCAMPlayer3,#" + id + "IpCAMPlayer4,#" + id + "IpCAMPlayer5,#" + id + "IpCAMPlayer6,#" + id + "IpCAMPlayer7,#" + id + "IpCAMPlayer8,#" + id + "IpCAMPlayer9,#" + id + "IpCAMPlayer10,#" + id + "IpCAMPlayer11,#" + id + "IpCAMPlayer12,#" + id + "IpCAMPlayer13");
    SelViewArray[buildingName] = 13;
}

function SwitchToSixteenView() {
    var buildingName = getSelectedBuildingName();
    var id = buildingName.toLowerCase() + $.i18n.prop('NE_DELIMITER');
    closeAllIpCAMPlayers();
    $("#" + id + "IpCAMView").empty();
    var ipCAMContent = '<div id="cctvLayout1" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="north" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:25%;padding:1px">' +
        '<div id="cctvLayout2" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player1Panel" class="player1Panel cctvPlayer" title="CAM 1" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player1" class="player1 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout3" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="player2Panel" class="player2Panel cctvPlayer" title="CAM 2" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player2" class="player2 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player3Panel" class="player3Panel cctvPlayer" title="CAM 3" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player3" class="player3 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player4Panel" class="player4Panel cctvPlayer" title="CAM 4" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player4" class="player4 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout4" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout5" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player5Panel" class="player5Panel cctvPlayer" title="CAM 5" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player5" class="player5 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout6" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="player6Panel" class="player6Panel cctvPlayer" title="CAM 6" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player6" class="player6 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player7Panel" class="player7Panel cctvPlayer" title="CAM 7" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player7" class="player7 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player8Panel" class="player8Panel cctvPlayer" title="CAM 8" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player8" class="player8 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:50%;padding:1px">' +
        '<div id="cctvLayout7" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player9Panel" class="player9Panel cctvPlayer" title="CAM 9" style="width:100%;height:100%;padding:1px">' +
        '<div id="player9" class="player9 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout8" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="player10Panel" class="player10Panel cctvPlayer" title="CAM 10" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player10" class="player10 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player11Panel" class="player11Panel cctvPlayer" title="CAM 11" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player11" class="player11 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player12Panel" class="player12Panel cctvPlayer" title="CAM 12" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player12" class="player12 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="south" class="cctvLayout" collapsible="false" border="false" style="width:100%;height:25%;padding:1px">' +
        '<div id="cctvLayout9" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player13Panel" class="player13Panel cctvPlayer" title="CAM 13" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player13" class="player13 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="cctvLayout10" class="cctvLayout" data-options="fit:true" border="false">' +
        '<div region="west" class="cctvLayout" collapsible="false" border="false" style="width:50%;height:100%;padding:1px">' +
        '<div id="player14Panel" class="player14Panel cctvPlayer" title="CAM 14" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player14" class="player14 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '<div region="center" class="cctvLayout" collapsible="false" border="false" style="padding:1px">' +
        '<div id="player15Panel" class="player15Panel cctvPlayer" title="CAM 15" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player15" class="player15 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div region="east" class="cctvLayout" collapsible="false" border="false" style="width:25%;height:100%;padding:1px">' +
        '<div id="player16Panel" class="player16Panel cctvPlayer" title="CAM 16" style="width:100%;height:100%;padding:1px" border="true">' +
        '<div id="player16" class="player16 cctvPlayer" style="width:99%;height:98%"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';
    $("#" + id + "IpCAMView").html(ipCAMContent);
    $("#" + id + "IpCAMLayout1,#" + id + "IpCAMLayout2,#" + id + "IpCAMLayout3,#" + id + "IpCAMLayout4,#" + id + "IpCAMLayout5,#" + id + "IpCAMLayout6,#" + id + "IpCAMLayout7,#" + id + "IpCAMLayout8,#" + id + "IpCAMLayout9,#" + id + "IpCAMLayout10").layout();
    loadIpCAMPanelForPlayer("#" + id + "IpCAMPlayer1,#" + id + "IpCAMPlayer2,#" + id + "IpCAMPlayer3,#" + id + "IpCAMPlayer4,#" + id + "IpCAMPlayer5,#" + id + "IpCAMPlayer6,#" + id + "IpCAMPlayer7,#" + id + "IpCAMPlayer8,#" + id + "IpCAMPlayer9,#" + id + "IpCAMPlayer10,#" + id + "IpCAMPlayer11,#" + id + "IpCAMPlayer12,#" + id + "IpCAMPlayer13,#" + id + "IpCAMPlayer14,#" + id + "IpCAMPlayer15,#" + id + "IpCAMPlayer16");
    SelViewArray[buildingName] = 16;
}

function playVideoFile() {
    var buildingName = getSelectedBuildingName();
    var playerId = SelPlayerIdArray[buildingName];
    var playerVideoId = playerId + "Video";
    $("#" + playerId).empty();
    var playerContent = '<video id="' + playerVideoId + '" class="video-js vjs-default-skin vjs-big-play-centered" controls preload="auto" data-setup=\'{"example_option": true, "controlBar": { "muteToggle": false }, "autoplay": false, "techOrder": ["flash", "html5"]}\'>' +
        '<source src="' + SelFileURLArray[buildingName] + '">' +
        '</video>';
    $("#" + playerId).append(playerContent);
    videojs.options.flash.swf = $.i18n.prop('CLIENT_URL') + "/videojs/video-js.swf";
    $("#" + playerVideoId).width($("#" + playerId).width());
    $("#" + playerVideoId + " object").width($("#" + playerId).width());
    $("#" + playerVideoId).height($("#" + playerId).height());
    $("#" + playerVideoId + " object").height($("#" + playerId).height());
}

var playSelectedVideoFile = function (event) {
    var URL = window.URL || window.webkitURL;
    var buildingName = getSelectedBuildingName();
    var file = this.files[0];
    var type = file.type;
    var fileURL = URL.createObjectURL(file);
    SelFileURLArray[buildingName] = fileURL;
};